# TandemBench

A joint-corruption benchmark for cross-modal retrieval. Every image–text sample is
evaluated three ways at a common ordinal severity index, image corrupted, text
corrupted, and both corrupted together, so that joint degradation can be compared
directly against the two single-modality effects it is composed of.

19 dual-encoder retrieval models · MS-COCO and Flickr30K · 16 image corruptions ·
12 text perturbations · 5 severity levels · both retrieval directions ·
83,754 evaluation records.

---

## Repository layout

The repository is organised as a pipeline. Each stage produces the input to the next,
and each has its own README with exactly what to download, what to run, and what it
writes.

| Stage | Produces |
|---|---|
| [`1_data_generation/`](1_data_generation/) | corrupted images and perturbed captions |
| [`2_evaluation/`](2_evaluation/) | Recall@1/5/10 for every model × condition |
| [`3_adaptation/`](3_adaptation/) | test-time adaptation and input-restoration records |
| [`4_analysis/`](4_analysis/) | every table and number reported in the paper |

## Reproducing the paper

**You do not need stages 1–3.** Stage 4 ships the complete evaluation records, so the
paper's tables regenerate from them directly:

```bash
pip install -r requirements.txt
cd 4_analysis
python paper_tables.py     # regenerates every table
python audit_claims.py     # checks every reported value
```

This needs only NumPy and SciPy. No GPU, no model weights, no image data. The
generator takes about 90 seconds; the audit runs 215 assertions tying values in the
paper to the regenerated tables and exits non-zero on any mismatch.

Stages 1–3 are what you run to rebuild the records themselves from the public source
datasets — see each stage's README.

## Analysis policy

Two conventions govern every number, and both exist to keep selection off the outcome
variable.

**The primary subset is execution-screened.** A text operator enters the primary
analysis if its severity-averaged fire rate exceeds 55% — that is, if the intervention
actually modifies the caption. Eight of twelve operators qualify. Fire rate is a
property of the operator and the caption distribution, not of the result, which is why
it can define the analysis set without circularity.

A stricter seven-operator subset additionally requires more than 8 pp of text-side
degradation. That is a selection on the outcome, so it is reported separately as a
**high-damage challenge subset** rather than folded into the primary definition.

**The 0.5 pp safeguard applies only to normalized analyses.** Where a marginal appears
in a denominator, conditions whose combined marginal damage is below 0.5 pp are
excluded, because the ratio is unstable there. Non-normalized quantities — δ₁, δ₂, δ₃,
excess over the larger marginal, additive error — use all complete triples.

| Text-operator set | Operators | Complete triples | After 0.5 pp filter |
|---|---|---|---|
| Full benchmark suite | 12 | 71,040 | 69,435 |
| Execution-screened primary | 8 | **47,360** | 46,949 |
| High-damage challenge | 7 | 41,440 | 41,264 |

## Reading the corruption labels

A joint condition has **both** modalities corrupted. Labels take the form
`<image>+<text>`, so `clean+keyboard_typo` and `fog+clean` are single-modality
conditions despite containing a `+`.

## Confidence intervals

Condition-level intervals use a clustered bootstrap whose resampling unit is
model × image-corruption × text-perturbation, with severity, dataset and retrieval
direction preserved within each cluster. Rank correlations resample over models
instead, since the statistic is computed across models. `4_analysis/bootstrap_comparison.py`
reports both the row-wise and clustered interval for every condition-level statistic.
