# Confidence intervals: row-wise vs clustered

The paper reports the CLUSTERED interval for every statistic below; `analysis/paper_tables.py`
emits it directly and this table is the justification. Cluster = model x image-corruption x
text-perturbation, severity / dataset / direction preserved within cluster. 50,000 resamples, seed 123.

Both columns are computed from the same values, so the only thing that differs is the
resampling unit. The data here is rebuilt from the raw run files independently of the
table generator, so agreement between this script's clustered interval and the published
one is a cross-implementation check, not a tautology.


## 4.3 mean excess

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| all severities | +5.07 | [+5.02, +5.11] | [+4.96, +5.17] | 2.43x | 2,432 | no change |
| severity 1 | +1.34 | [+1.32, +1.37] | [+1.30, +1.38] | 1.61x | 2,432 | no change |
| severity 2 | +2.79 | [+2.74, +2.84] | [+2.71, +2.87] | 1.70x | 2,432 | no change |
| severity 3 | +4.95 | [+4.88, +5.02] | [+4.83, +5.07] | 1.69x | 2,432 | no change |
| severity 4 | +7.07 | [+6.97, +7.16] | [+6.92, +7.22] | 1.61x | 2,432 | no change |
| severity 5 | +9.18 | [+9.06, +9.30] | [+9.00, +9.35] | 1.48x | 2,432 | no change |

## 4.4 dataset x direction

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| MS-COCO I2T | +5.48 | [+5.40, +5.56] | [+5.36, +5.60] | 1.49x | 2,432 | no change |
| MS-COCO T2I | +3.12 | [+3.07, +3.17] | [+3.04, +3.20] | 1.62x | 2,432 | no change |
| Flickr30K I2T | +6.44 | [+6.33, +6.55] | [+6.29, +6.59] | 1.31x | 2,304 | no change |
| Flickr30K T2I | +5.31 | [+5.22, +5.39] | [+5.18, +5.43] | 1.49x | 2,304 | no change |

## Table 6 / 5.1 adaptation

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| Tandem-Aug I2T | +0.83 | [+0.78, +0.87] | [+0.74, +0.91] | 2.03x | 1,351 | no change |
| Tandem-Aug T2I | +1.65 | [+1.63, +1.68] | [+1.60, +1.70] | 1.99x | 1,351 | no change |
| QueryExpansion I2T | +3.40 | [+3.32, +3.48] | [+3.24, +3.55] | 1.91x | 1,351 | no change |
| QueryExpansion T2I | -8.72 | [-8.79, -8.65] | [-8.85, -8.60] | 1.83x | 1,351 | no change |
| Tandem-Align I2T | -13.28 | [-13.47, -13.08] | [-13.67, -12.88] | 2.03x | 965 | no change |
| Tandem-Align T2I | -12.70 | [-12.81, -12.58] | [-12.93, -12.46] | 2.03x | 965 | no change |
| FeatureWhitening I2T | -25.75 | [-26.01, -25.50] | [-26.24, -25.27] | 1.93x | 1,351 | no change |
| FeatureWhitening T2I | -24.21 | [-24.39, -24.03] | [-24.54, -23.87] | 1.85x | 1,351 | no change |

## 5.1 TCR regimes

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| query shift I2T | +5.90 | [+5.15, +6.70] | [+5.07, +6.75] | 1.08x | 40 | no change |
| query shift T2I | -0.30 | [-0.62, +0.02] | [-0.82, +0.21] | 1.61x | 30 | no change |
| gallery shift I2T | +1.83 | [+1.57, +2.08] | [+1.40, +2.21] | 1.59x | 30 | no change |
| gallery shift T2I | +0.46 | [+0.25, +0.68] | [+0.11, +0.84] | 1.69x | 40 | no change |
| joint I2T | +4.73 | [+4.45, +5.01] | [+4.36, +5.10] | 1.33x | 120 | no change |
| joint T2I | -0.03 | [-0.16, +0.10] | [-0.23, +0.17] | 1.53x | 120 | no change |

## 5.2 TCR by severity

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| severity 1 (I2T) | +3.17 | [+2.94, +3.41] | [+2.94, +3.41] | 1.00x | 120 | no change |
| severity 3 (I2T) | +4.78 | [+4.33, +5.25] | [+4.33, +5.25] | 0.99x | 120 | no change |
| severity 5 (I2T) | +6.22 | [+5.69, +6.76] | [+5.69, +6.76] | 1.00x | 120 | no change |

## 5.2 restoration

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| restore image | +0.25 | [+0.14, +0.37] | [+0.09, +0.41] | 1.35x | 60 | no change |
| restore caption | +1.72 | [+1.31, +2.17] | [+0.88, +2.62] | 2.02x | 60 | no change |
| restore both | +2.00 | [+1.54, +2.49] | [+1.12, +2.93] | 1.93x | 60 | no change |
| restore interaction | +0.02 | [-0.02, +0.07] | [-0.03, +0.07] | 1.18x | 60 | no change |

## supp. TCR per model

| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x | Clusters | Interpretation |
|---|---|---|---|---|---|---|
| clip_vitb16 I2T | +4.41 | [+3.64, +5.25] | [+3.47, +5.46] | 1.23x | 12 | no change |
| clip_vitb16 T2I | +1.79 | [+1.43, +2.14] | [+1.66, +1.91] | 0.36x | 12 | no change |
| clip_vitb32 I2T | +3.46 | [+2.67, +4.35] | [+2.40, +4.60] | 1.31x | 12 | no change |
| clip_vitb32 T2I | +1.11 | [+0.88, +1.34] | [+0.94, +1.28] | 0.75x | 12 | no change |
| clip_vitl14 I2T | +4.30 | [+3.38, +5.26] | [+3.37, +5.14] | 0.94x | 12 | no change |
| clip_vitl14 T2I | +1.57 | [+1.36, +1.77] | [+1.45, +1.70] | 0.63x | 12 | no change |
| evaclip_vitb16 I2T | +3.22 | [+2.55, +3.90] | [+2.29, +4.16] | 1.39x | 12 | no change |
| evaclip_vitb16 T2I | -0.69 | [-0.81, -0.58] | [-0.82, -0.57] | 1.11x | 12 | no change |
| metaclip_vitb16 I2T | +5.37 | [+4.48, +6.33] | [+4.05, +6.85] | 1.52x | 12 | no change |
| metaclip_vitb16 T2I | -0.47 | [-0.60, -0.34] | [-0.61, -0.35] | 0.99x | 12 | no change |
| metaclip_vitl14 I2T | +5.81 | [+4.85, +6.79] | [+4.69, +6.85] | 1.12x | 12 | no change |
| metaclip_vitl14 T2I | -1.01 | [-1.28, -0.76] | [-1.32, -0.71] | 1.18x | 12 | no change |
| openclip_vitb16 I2T | +5.38 | [+4.69, +6.10] | [+4.39, +6.33] | 1.38x | 12 | no change |
| openclip_vitb16 T2I | -0.28 | [-0.44, -0.12] | [-0.46, -0.11] | 1.09x | 12 | no change |
| openclip_vitb32 I2T | +5.22 | [+4.50, +5.97] | [+4.18, +6.25] | 1.42x | 12 | no change |
| openclip_vitb32 T2I | -0.21 | [-0.36, -0.07] | [-0.36, -0.07] | 1.00x | 12 | no change |
| openclip_vitl14 I2T | +5.27 | [+4.37, +6.23] | [+4.15, +6.44] | 1.23x | 12 | no change |
| openclip_vitl14 T2I | -1.02 | [-1.37, -0.71] | [-1.43, -0.67] | 1.16x | 12 | no change |
| siglip_vitb16 I2T | +4.81 | [+4.01, +5.65] | [+3.79, +5.72] | 1.18x | 12 | no change |
| siglip_vitb16 T2I | -1.10 | [-1.41, -0.85] | [-1.43, -0.83] | 1.07x | 12 | no change |


## Already using an appropriate unit — not clustered

| Result | Section | Unit | Why it is correct |
|---|---|---|---|
| Spearman rank correlations | 4.6 | 20,000 resamples over **models** | the statistic is computed across models, so the model is the sampling unit. These use a dedicated generator so they cannot be perturbed by unrelated changes elsewhere in the script. |
| Estimator-bias correlations | 4.2 | analytic Spearman over the 12 operators | a correlation over operators, not a bootstrap; the operator is the unit |
| Severity-trend permutation test | 4.5 | label permutation over severity | a permutation test, not a bootstrap; exchangeability is over severity labels |


All rebuilt point estimates and clustered intervals matched the published tables.
