"""Row-wise vs clustered confidence intervals, side by side, for the supplement.

paper_tables.py now emits the CLUSTERED interval for every condition-level statistic,
This script serves two purposes:

  1. Produce the methodology comparison table -- what the interval would have been
     under the row-wise iid bootstrap, what it is under clustering, how much wider,
     and whether the statistical interpretation changes.

  2. Act as an independent cross-check. The keyed data below is rebuilt from the raw
     run files by this script, NOT taken from paper_tables.py. If the clustered
     interval computed here disagrees with the one paper_tables.py wrote into
     tables/*.csv, the two implementations disagree and the script reports it.

Both estimators are computed from exactly the same values, so the only difference
between the two columns is the resampling unit.

    python analysis/recompute_cis.py        -> BOOTSTRAP_METHODOLOGY.md
"""
import collections
import contextlib
import csv
import glob
import io
import os
import runpy

import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
NB = int(os.environ.get("TANDEMBENCH_NB", 50000))   # must match NB_C in paper_tables.py
_b = io.StringIO()
with contextlib.redirect_stdout(_b):
    G = runpy.run_path(os.path.join(ROOT, "paper_tables.py"))


def tbl(n):
    return list(csv.DictReader(open(os.path.join(ROOT, "tables", f"{n}.csv"))))


def _boot(groups, nb, seed):
    """Percentile bootstrap over the given groups. groups: list of value arrays."""
    sums = np.array([g.sum() for g in groups])
    cnts = np.array([len(g) for g in groups], float)
    rng = np.random.default_rng(seed)
    n = len(groups)
    out = np.empty(nb)
    step = max(1, 4_000_000 // max(n, 1))
    for i in range(0, nb, step):
        m = min(step, nb - i)
        idx = rng.integers(0, n, (m, n))
        out[i:i + m] = sums[idx].sum(1) / cnts[idx].sum(1)
    return tuple(np.percentile(out, [2.5, 97.5]))


def rowwise(keyed, nb=NB, seed=123):
    """Every row its own group -- the estimator the paper used before clustering."""
    return _boot([np.array([v]) for _, v in keyed], nb, seed)


def clustered(keyed, nb=NB, seed=123):
    """Whole clusters resampled together. Mirrors cci() in paper_tables.py exactly,
    including the sorted key order, so a mismatch means the DATA differs, not the RNG."""
    d = collections.defaultdict(list)
    for k, v in keyed:
        d[k].append(float(v))
    keys = sorted(d, key=repr)
    return _boot([np.array(d[k]) for k in keys], nb, seed), len(keys)


ROWS = []       # (section, label, point, old_ci, new_ci, nclust, verdict)
ISSUES = []


def _parse(ci):
    try:
        a, b = [float(x) for x in str(ci).strip("[] ").replace("+", "").split(",")]
        return a, b
    except Exception:
        return None


def add(section, label, keyed, published_point=None, published_ci=None):
    """Compute both intervals; verify the point estimate and the clustered interval
    against what paper_tables.py published."""
    vals = [v for _, v in keyed]
    point = float(np.mean(vals))
    lo0, hi0 = rowwise(keyed)
    (lo, hi), nc = clustered(keyed)
    if published_point is not None and abs(point - published_point) > 0.011:
        ISSUES.append(f"{label}: rebuilt point {point:+.4f} vs published "
                      f"{published_point:+.4f}")
    if published_ci is not None:
        p = _parse(published_ci)
        if p and (abs(p[0] - lo) > 0.02 or abs(p[1] - hi) > 0.02):
            ISSUES.append(f"{label}: rebuilt clustered CI [{lo:+.2f}, {hi:+.2f}] vs "
                          f"published {published_ci}")
    ROWS.append((section, label, point, (lo0, hi0), (lo, hi), nc))


# ── 1. headline mean excess, section 4.3 ─────────────────────────────────────
T = G["T"]
amp = {r["Group"]: r for r in tbl("amplification")}
for grp in ["all severities"] + [f"severity {s}" for s in range(1, 6)]:
    S = T if grp == "all severities" else [t for t in T if t["sev"] == int(grp.split()[-1])]
    keyed = [((t["model"], t["img"], t["txt"]), t["d3"] - max(t["d1"], t["d2"])) for t in S]
    add("4.3 mean excess", grp, keyed, float(amp[grp]["mean excess (pp)"]),
        amp[grp]["95% CI"])

# ── 2. dataset x direction, section 4.4 (main-paper Table 3) ─────────────────
st = {(r["Dataset"], r["Direction"]): r for r in tbl("strata")}
for ds, dsl in (("coco", "MS-COCO"), ("flickr30k", "Flickr30K")):
    for dr in ("I2T", "T2I"):
        S = [t for t in T if t["ds"] == ds and t["dir"] == dr]
        keyed = [((t["model"], t["img"], t["txt"]), t["d3"] - max(t["d1"], t["d2"]))
                 for t in S]
        add("4.4 dataset x direction", f"{dsl} {dr}", keyed,
            float(st[(dsl, dr)]["mean excess pp"]), st[(dsl, dr)]["95% CI"])

# ── 3. adaptation, Table 6 / section 5.1 ─────────────────────────────────────
per = collections.defaultdict(list)
for f in glob.glob(os.path.join(ROOT, "records", "0[23]_*", "*.csv")):
    R = [r for r in csv.DictReader(open(f)) if r.get("dataset", "coco") == "coco"]
    cell = collections.defaultdict(dict)
    for r in R:
        cell[(r["model"].strip(), r["corruption_type"], r["severity"],
              r["direction"])][r["TTA_method"].strip()] = float(r["R@1"])
    for k, a in cell.items():
        if "none" not in a:
            continue
        for m, v in a.items():
            if m != "none" and abs(v - a["none"]) > 1e-9:
                per[(m, k[3])].append(((k[0], k[1]), v - a["none"]))
_tta = list(csv.reader(open(os.path.join(ROOT, "tables", "tta.csv"))))
TA = {r["Method"]: r for r in tbl("tta")}
# tta.csv carries the paper-facing display names, while the evaluation records and
# the adaptation dispatch keep the original internal IDs. Map between them here
# rather than renaming either side.
DISPLAY = {"TTA-Aug": "Tandem-Aug", "PromptAlign": "Tandem-Align"}
for m in ["TTA-Aug", "QueryExpansion", "PromptAlign", "FeatureWhitening"]:
    disp_m = DISPLAY.get(m, m)
    row = [r for r in _tta if r[0] == disp_m][0]
    for d, col, cicol in (("I2T", "I2T dR@1", 3), ("T2I", "T2I dR@1", 6)):
        add("Table 6 / 5.1 adaptation", f"{disp_m} {d}", per[(m, d)],
            float(TA[disp_m][col]), row[cicol])

# ── 4. TCR regimes, section 5.1 ──────────────────────────────────────────────
def regime(ic, tc, direction):
    if ic == "clean" and tc == "clean":
        return "clean"
    if direction == "I2T":
        return "query_shift" if tc == "clean" else ("gallery_shift" if ic == "clean" else "joint")
    return "query_shift" if ic == "clean" else ("gallery_shift" if tc == "clean" else "joint")


tcr = collections.defaultdict(lambda: collections.defaultdict(list))
tcr_sev = collections.defaultdict(list)
tcr_pm = collections.defaultdict(lambda: collections.defaultdict(list))
for f in sorted(glob.glob(os.path.join(ROOT, "records", "07_tcr", "*.csv"))):
    R = list(csv.DictReader(open(f)))
    if len(R) < 200:
        continue
    cell = collections.defaultdict(dict)
    for r in R:
        cell[(r["corruption_type"], r["severity"], r["direction"],
              r["model"].strip())][r["TTA_method"].strip()] = float(r["R@1"])
    for k, a in cell.items():
        meths = [m for m in a if m != "none"]
        if "none" not in a or not meths:
            continue
        ct = k[0]
        ic, tc = (ct.split("+", 1) if "+" in ct else (ct, "clean")) if ct != "clean" \
            else ("clean", "clean")
        rg = regime(ic, tc, k[2])
        dv = a[meths[0]] - a["none"]
        tcr[rg][k[2]].append(((k[3], ct), dv))
        if rg == "joint" and k[2] == "I2T":
            tcr_sev[int(k[1])].append(((k[3], ct), dv))
        # joint means BOTH sides corrupted. "+" in the label is not that test:
        # clean+keyboard_typo and fog+clean contain one too.
        if rg == "joint" and ic != "clean" and tc != "clean":
            tcr_pm[(k[3], k[2])][ct].append(dv)
TC = list(csv.reader(open(os.path.join(ROOT, "tables", "tcr.csv"))))
for rg, disp in [("query_shift", "query shift"), ("gallery_shift", "gallery shift"),
                 ("joint", "joint")]:
    row = [r for r in TC if r[0] == disp][0]
    for d, vcol, cicol in (("I2T", 1, 2), ("T2I", 4, 5)):
        add("5.1 TCR regimes", f"{disp} {d}", tcr[rg][d], float(row[vcol]), row[cicol])

# ── 5. TCR by severity, section 5.2 ──────────────────────────────────────────
TS = {int(r["Severity"]): r for r in tbl("tcrsev")}
for s in (1, 3, 5):
    add("5.2 TCR by severity", f"severity {s} (I2T)", tcr_sev[s],
        float(TS[s]["dR@1"]), TS[s]["95% CI"])

# ── 6. restoration, section 5.2 ──────────────────────────────────────────────
rest = []
for f in glob.glob(os.path.join(ROOT, "records", "05_restoration", "*.csv")):
    rest += list(csv.DictReader(open(f)))
cell = collections.defaultdict(dict)
for r in rest:
    cell[(r["model"].strip(), r["corruption_type"], int(r["severity"]),
          r["direction"])][r["TTA_method"].strip()] = float(r["R@1"])
arms = collections.defaultdict(list)
for k, a in cell.items():
    if not {"none", "RestoreImg", "RestoreTxt", "RestoreBoth"} <= set(a):
        continue
    key = (k[0], k[1])
    gi, gt, gb = (a["RestoreImg"] - a["none"], a["RestoreTxt"] - a["none"],
                  a["RestoreBoth"] - a["none"])
    arms["image"].append((key, gi)); arms["caption"].append((key, gt))
    arms["both"].append((key, gb)); arms["interaction"].append((key, gb - gi - gt))
# restore.csv has four columns named '95% CI'; read positionally.
_RS = {r[0]: r for r in list(csv.reader(open(os.path.join(ROOT, "tables",
                                                          "restore.csv"))))[1:]}["all"]
for a, vcol, cicol in (("image", 1, 2), ("caption", 3, 4), ("both", 5, 6),
                       ("interaction", 7, 8)):
    add("5.2 restoration", f"restore {a}", arms[a], float(_RS[vcol]), _RS[cicol])

# ── 7. TCR per model, supplement ─────────────────────────────────────────────
_pm = {r[0]: r for r in list(csv.reader(open(os.path.join(ROOT, "tables",
                                                          "tcr_permodel.csv"))))[1:]}
for (mo, d), byct in sorted(tcr_pm.items()):
    if mo not in _pm:
        continue
    keyed = [(ct, v) for ct, vs in byct.items() for v in vs]
    r = _pm[mo]
    add("supp. TCR per model", f"{mo} {d}", keyed,
        float(r[2] if d == "I2T" else r[4]), r[3] if d == "I2T" else r[5])

# ── write ────────────────────────────────────────────────────────────────────
def flips(old, lo, hi):
    """Does the statistical interpretation change: does zero-exclusion status flip?"""
    was = (old[0] > 0) == (old[1] > 0)
    now = (lo > 0) == (hi > 0)
    return "no change" if was == now else ("**NOW SPANS ZERO**" if was else "**NOW EXCLUDES ZERO**")


L = ["# Confidence intervals: row-wise vs clustered\n",
     "The paper reports the CLUSTERED interval for every statistic below; "
     "`analysis/paper_tables.py`",
     "emits it directly and this table is the justification. Cluster = model x "
     "image-corruption x",
     f"text-perturbation, severity / dataset / direction preserved within cluster. "
     f"{NB:,} resamples, seed 123.\n",
     "Both columns are computed from the same values, so the only thing that differs "
     "is the",
     "resampling unit. The data here is rebuilt from the raw run files independently "
     "of the",
     "table generator, so agreement between this script's clustered interval and the "
     "published",
     "one is a cross-implementation check, not a tautology.\n"]
cur = None
for sec, lab, pt, old, (lo, hi), nc in ROWS:
    if sec != cur:
        cur = sec
        L += [f"\n## {sec}\n",
              "| Result | Point | Row-wise iid CI | Clustered CI (published) | Width x "
              "| Clusters | Interpretation |",
              "|---|---|---|---|---|---|---|"]
    ratio = f"{(hi - lo) / (old[1] - old[0]):.2f}x" if old[1] > old[0] else "--"
    L.append(f"| {lab} | {pt:+.2f} | [{old[0]:+.2f}, {old[1]:+.2f}] | "
             f"[{lo:+.2f}, {hi:+.2f}] | {ratio} | {nc:,} | {flips(old, lo, hi)} |")
L += ["\n\n## Already using an appropriate unit — not clustered\n",
      "| Result | Section | Unit | Why it is correct |",
      "|---|---|---|---|",
      "| Spearman rank correlations | 4.6 | 20,000 resamples over **models** |"
      " the statistic is computed across models, so the model is the sampling unit."
      " These use a dedicated generator so they cannot be perturbed by unrelated"
      " changes elsewhere in the script. |",
      "| Estimator-bias correlations | 4.2 | analytic Spearman over the 12 operators |"
      " a correlation over operators, not a bootstrap; the operator is the unit |",
      "| Severity-trend permutation test | 4.5 | label permutation over severity |"
      " a permutation test, not a bootstrap; exchangeability is over severity labels |"]
if ISSUES:
    L += ["\n\n## Verification failures\n"] + [f"- {x}" for x in ISSUES]
else:
    L += ["\n\nAll rebuilt point estimates and clustered intervals matched the "
          "published tables."]
out = os.path.join(ROOT, "BOOTSTRAP_METHODOLOGY.md")
open(out, "w").write("\n".join(L) + "\n")
print(f"wrote BOOTSTRAP_METHODOLOGY.md — {len(ROWS)} intervals, {len(ISSUES)} verification failures")
for x in ISSUES:
    print("  !", x)
