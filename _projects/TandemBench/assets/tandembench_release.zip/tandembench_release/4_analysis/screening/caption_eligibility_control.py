"""CONTROL for the eligibility finding: are the semantic operators broken, or is the
caption source the limit?

COCO gives 5 independent captions per image. Concatenating them yields a
paragraph-length description of the SAME image — same domain, same vocabulary, same
annotators, same everything except length and clause structure. If the operators are
broken, eligibility stays flat. If the caption source is the limit, eligibility jumps.

This is the answer to "why did you use these captions?": we used the field's standard
retrieval benchmark, and the operators are fine on it the moment the text has structure.
"""
import json, os, re, csv, random, collections
import numpy as np
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from text_corruptions.semantic_corruptions import SPATIAL_RELATIONS, _get_nlp
from text_corruptions import corrupt_text

N = 1000
rng = random.Random(123)
REL = re.compile(r"\b(" + "|".join(re.escape(r) for r in
                 sorted(SPATIAL_RELATIONS, key=len, reverse=True)) + r")\b", re.I)

_p = os.path.join(ROOT, os.pardir, "data", "coco", "annotations", "captions_val2017.json")
if not os.path.exists(_p):
    raise SystemExit(
        "\n  This script requires the source caption annotations, which are not\n"
        "  redistributed with the benchmark.\n\n"
        f"  Missing: {_p}\n\n"
        "  Obtain MS-COCO from https://cocodataset.org and place the annotations\n"
        "  under data/coco/annotations/, then re-run.\n\n"
        "  The precomputed output is already shipped at\n"
        "  records/06_screening/caption_eligibility_control.csv\n")
d = json.load(open(_p))
by_img = collections.defaultdict(list)
for a in d["annotations"]:
    by_img[a["image_id"]].append(a["caption"].strip())

singles, paras = [], []
for iid, caps in by_img.items():
    if len(caps) >= 5:
        singles.append(caps[0])
        paras.append(" ".join(c if c.endswith((".", "!", "?")) else c + "." for c in caps[:5]))
idx = rng.sample(range(len(singles)), min(N, len(singles)))
singles = [singles[i] for i in idx]
paras = [paras[i] for i in idx]


def elig(caps, label):
    nlp = _get_nlp()
    n = len(caps)
    s = dict.fromkeys(("sent2", "adj", "rel", "negverb", "noun"), 0)
    ntok = []
    for c in caps:
        sents = re.split(r"(?<=[.!?])\s+", c.strip())
        doc = nlp(c)
        ntok.append(len(doc))
        s["sent2"] += len(sents) >= 2
        s["adj"] += sum(t.pos_ == "ADJ" for t in doc) > 0
        s["noun"] += sum(t.pos_ == "NOUN" for t in doc) > 0
        s["negverb"] += sum(t.pos_ in {"AUX", "VERB"} and t.dep_ in {"aux", "auxpass", "ROOT"}
                            for t in doc) > 0
        s["rel"] += len(REL.findall(c)) > 0
    print(f"\n  [{label}]  n={n}  tokens/caption: mean {np.mean(ntok):.1f} median {np.median(ntok):.0f}")
    return {k: v / n * 100 for k, v in s.items()}, float(np.mean(ntok))


e1, t1 = elig(singles, "single COCO caption  (what the benchmark uses)")
e5, t5 = elig(paras, "5 captions concatenated  (same images, same annotators)")

OPS = [("sentence_shuffle", "sent2"), ("negation_insertion", "negverb"),
       ("attribute_swap", "adj"), ("relation_swap", "rel"),
       ("object_substitution", "noun")]

print("\n" + "=" * 74)
print("ELIGIBILITY: single caption vs paragraph — SAME IMAGES, SAME ANNOTATORS")
print("=" * 74)
print(f"  {'operator':<22}{'single':>10}{'paragraph':>12}{'change':>10}")
rows = []
for op, key in OPS:
    a, b = e1[key], e5[key]
    print(f"  {op:<22}{a:9.1f}%{b:11.1f}%{b-a:+9.1f}")
    rows.append({"operator": op, "eligible_single_pct": round(a, 2),
                 "eligible_paragraph_pct": round(b, 2), "delta_pp": round(b - a, 2)})
print(f"\n  mean tokens: {t1:.1f} -> {t5:.1f}")

# ── does the operator actually MODIFY the text once structure exists? ────────
print("\n" + "=" * 74)
print("ACTUAL FIRE RATE (text changed?) at severity 3 — the operator itself")
print("=" * 74)
print(f"  {'operator':<22}{'single':>10}{'paragraph':>12}{'change':>10}")
for op, _ in OPS:
    f = []
    for caps in (singles, paras):
        hit = 0
        for i, c in enumerate(caps[:400]):
            try:
                if corrupt_text(c, op, 3, seed=123 + i) != c:
                    hit += 1
            except Exception:
                pass
        f.append(hit / len(caps[:400]) * 100)
    print(f"  {op:<22}{f[0]:9.1f}%{f[1]:11.1f}%{f[1]-f[0]:+9.1f}")
    for r in rows:
        if r["operator"] == op:
            r["fire_single_pct"] = round(f[0], 2)
            r["fire_paragraph_pct"] = round(f[1], 2)

out = os.path.join(ROOT, "records", "06_screening", "caption_eligibility_control.csv")
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["operator", "eligible_single_pct", "eligible_paragraph_pct",
                                       "delta_pp", "fire_single_pct", "fire_paragraph_pct"])
    w.writeheader(); w.writerows(rows)
print(f"\n-> {out}")
