"""Why the semantic text corruptions don't fire: an eligibility audit of the captions.

Each semantic operator requires a specific linguistic structure to be present. This
measures, per operator, the fraction of captions that CONTAIN that structure at all
("eligible") — which upper-bounds the fire rate no matter how the severity schedule
is tuned. Distinguishes:

  (a) structure absent from the data   -> operator is INAPPLICABLE to this benchmark
  (b) structure present, rate too low  -> severity SCHEDULE is miscalibrated

Output: analysis/../records/06_screening/caption_eligibility.csv
"""
import json, os, re, csv, random
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys
sys.path.insert(0, ROOT)
from text_corruptions.semantic_corruptions import (
    SPATIAL_RELATIONS, _get_nlp, _token_rate, _sent_rate,
)

N = 2000  # captions sampled per dataset
rng = random.Random(123)



def _require_source_data(path):
    """This script needs the source captions, which the release does not redistribute.
    Fail loudly rather than writing an empty CSV over a good one."""
    if not os.path.exists(path):
        raise SystemExit(
            "\n  This script requires the source caption annotations, which are not\n"
            "  redistributed with the benchmark.\n\n"
            f"  Missing: {path}\n\n"
            "  Obtain MS-COCO from https://cocodataset.org and place the annotations under\n"
            "  data/coco/annotations/, then re-run.\n\n"
            "  The precomputed output is already shipped at\n"
            "  records/06_screening/caption_eligibility.csv\n")

def coco_caps():
    _p = os.path.join(ROOT, os.pardir, "data", "coco", "annotations", "captions_val2017.json")
    _require_source_data(_p)
    d = json.load(open(_p))
    return [a["caption"].strip() for a in d["annotations"]]


def flickr_caps():
    base = os.path.join(ROOT, os.pardir, "data", "flickr30k", "annotations")
    for fn in os.listdir(base):
        p = os.path.join(base, fn)
        if fn.endswith(".json"):
            d = json.load(open(p))
            if isinstance(d, dict) and "annotations" in d:
                return [a["caption"].strip() for a in d["annotations"]]
            if isinstance(d, list):
                out = []
                for r in d:
                    if isinstance(r, dict):
                        for k in ("caption", "raw", "sentence"):
                            if k in r:
                                out.append(str(r[k]).strip())
                                break
                if out:
                    return out
        if fn.endswith((".txt", ".token")):
            out = []
            for line in open(p, encoding="utf-8", errors="ignore"):
                parts = line.rstrip("\n").split("\t")
                if len(parts) == 2:
                    out.append(parts[1].strip())
            if out:
                return out
    return []


REL = re.compile(r"\b(" + "|".join(re.escape(r) for r in
                 sorted(SPATIAL_RELATIONS, key=len, reverse=True)) + r")\b", re.I)


def audit(name, caps):
    caps = [c for c in caps if c]
    if len(caps) > N:
        caps = rng.sample(caps, N)
    nlp = _get_nlp()
    n = len(caps)
    stat = {k: 0 for k in ("sent2", "phrase2", "adj", "rel", "negverb", "noun")}
    ntok, nadj, nrel = [], [], []
    for c in caps:
        sents = re.split(r"(?<=[.!?])\s+", c.strip())
        phr = re.split(r"(?<=[,;])\s+", c.strip())
        stat["sent2"] += len(sents) >= 2
        stat["phrase2"] += (len(sents) >= 2 or len(phr) >= 2)
        doc = nlp(c)
        a = sum(t.pos_ == "ADJ" for t in doc)
        nn = sum(t.pos_ == "NOUN" for t in doc)
        v = sum(t.pos_ in {"AUX", "VERB"} and t.dep_ in {"aux", "auxpass", "ROOT"} for t in doc)
        r = len(REL.findall(c))
        stat["adj"] += a > 0
        stat["noun"] += nn > 0
        stat["negverb"] += v > 0
        stat["rel"] += r > 0
        ntok.append(len(doc)); nadj.append(a); nrel.append(r)
    print(f"\n=== {name}  (n={n} captions) ===")
    print(f"  tokens/caption: mean {np.mean(ntok):.1f}  median {np.median(ntok):.0f}  "
          f"p95 {np.percentile(ntok,95):.0f}")
    print(f"  adjectives/caption: mean {np.mean(nadj):.2f}   spatial relations: mean {np.mean(nrel):.2f}")
    print(f"\n  {'operator':<22}{'eligible':>10}   {'req. structure'}")
    rows = []
    for op, key, req in [
        ("sentence_shuffle", "phrase2", ">=2 sentences or comma-phrases"),
        ("negation_insertion", "negverb", ">=1 aux/root verb"),
        ("attribute_swap", "adj", ">=1 adjective"),
        ("relation_swap", "rel", ">=1 spatial preposition"),
        ("object_substitution", "noun", ">=1 noun  [CONTROL - valid op]"),
    ]:
        e = stat[key] / n
        print(f"  {op:<22}{e*100:9.1f}%   {req}")
        rows.append({"dataset": name, "operator": op, "eligible_pct": round(e * 100, 2),
                     "requires": req})
    print(f"\n  (multi-sentence captions specifically: {stat['sent2']/n*100:.1f}%)")
    return rows, {"dataset": name, "n": n, "mean_tokens": round(float(np.mean(ntok)), 2),
                  "median_tokens": int(np.median(ntok)),
                  "mean_adj": round(float(np.mean(nadj)), 3),
                  "mean_rel": round(float(np.mean(nrel)), 3),
                  "multi_sentence_pct": round(stat["sent2"] / n * 100, 2)}


all_rows, summ = [], []
for name, fn in [("COCO val2017", coco_caps), ("Flickr30k", flickr_caps)]:
    try:
        caps = fn()
    except Exception as e:
        print(f"{name}: could not load ({e})")
        continue
    if not caps:
        print(f"{name}: no captions found")
        continue
    r, s = audit(name, caps)
    all_rows += r; summ.append(s)

# ── eligibility vs observed fire rate ────────────────────────────────────────
OBSERVED = {"sentence_shuffle": 0.0, "negation_insertion": 4.0, "attribute_swap": 18.2,
            "relation_swap": 25.6, "object_substitution": 70.6}
print("\n" + "=" * 72)
print("ELIGIBILITY CEILING vs OBSERVED FIRE RATE  (severity 3, token rate 0.40)")
print("=" * 72)
print(f"  {'operator':<22}{'eligible':>10}{'observed':>10}{'ceiling*rate':>14}   diagnosis")
coco = {r["operator"]: r["eligible_pct"] for r in all_rows if r["dataset"] == "COCO val2017"}
for op, obs in OBSERVED.items():
    e = coco.get(op, float("nan"))
    pred = e * _token_rate(3) if op != "sentence_shuffle" else e * _sent_rate(3)
    if e < 5:
        dx = "DATA LACKS STRUCTURE -> operator inapplicable"
    elif obs < pred * 0.6:
        dx = "structure present, under-fires -> schedule issue"
    else:
        dx = "behaves as designed"
    print(f"  {op:<22}{e:9.1f}%{obs:9.1f}%{pred:13.1f}%   {dx}")

out = os.path.join(ROOT, "records", "06_screening", "caption_eligibility.csv")
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["dataset", "operator", "eligible_pct", "requires"])
    w.writeheader(); w.writerows(all_rows)
print(f"\n-> {out}")
for s in summ:
    print("  ", s)
