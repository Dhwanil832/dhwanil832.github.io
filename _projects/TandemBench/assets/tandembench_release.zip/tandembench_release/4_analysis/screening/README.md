# Screening scripts

These produce the operator-applicability evidence. **Their outputs are already shipped**
in `../records/06_screening/`, so you only need to run them to regenerate that evidence
from source.

| Script | Produces | Needs |
|---|---|---|
| `caption_eligibility.py` | `caption_eligibility.csv` | MS-COCO and Flickr30K annotations |
| `caption_eligibility_control.py` | `caption_eligibility_control.csv` | MS-COCO annotations |
| `external_suite_screen.py` | `external_suite_screen.csv` | the two external suites, see below |

## Dataset annotations

`caption_eligibility*.py` read captions from `<repo root>/data/`, the same location
[stage 1](../../1_data_generation/) writes corrupted images to:

```
data/
├── coco/annotations/captions_val2017.json
└── flickr30k/annotations/
```

Only the annotation files are needed — not the images.

## External perturbation suites

`external_suite_screen.py` applies the execution screen to operators from two published
retrieval-robustness suites, in addition to our own twelve. Those suites are **not
redistributed here**: they are third-party code under their own licenses. Their output
under our screen is shipped as `external_suite_screen.csv`.

To regenerate it, place the two upstream repositories at `<repo root>/external_suites/`:

```
external_suites/
├── mm_robustness/text_perturbation/
└── tcr/
```

The script reads their operator definitions and applies the same fire-rate measurement
used on our own operators — 500 captions per operator per severity, exact string
comparison before and after.

## What the screen is and is not

This is an audit, not an external gold standard. It asks a narrow question: does the
execution screen selectively reject standard published operators while preserving only
our own preferred transformations? It does not. Executed failures concentrate in
structure-dependent semantic transformations, and those are operators we introduced
ourselves, not ones the field relies on.

Generation-based rewrites — back-translation and style transfer — require additional
models and are listed as not run, rather than counted as passes or failures.
