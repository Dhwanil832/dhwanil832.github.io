"""W2 — apply the validity screen to PUBLISHED text-perturbation suites.

Suites screened, using their own released code from external_suites/:

  * MM-Robustness (Qiu et al., DMLR 2024)  github.com/Jielin-Qiu/MM_Robustness
      nlpaug char augmenters + EDA (their perturb_COCO_TP.py imports both)
  * TCR (ICLR 2025 spotlight)              github.com/XLearning-SCU/2025-ICLR-TCR
      operator set read off their released config filenames, same nlpaug/EDA family

Both are run on the SAME 500 COCO captions used for our own screen, so the
comparison is like-for-like.

Operators requiring a heavyweight model (back-translation, Styleformer style
transfer) are NOT executed. They are structure-independent whole-sentence rewrites
by construction — they cannot no-op for lack of syntax, which is the property under
test — and are reported as such rather than silently dropped.

Output: records/06_screening/external_suite_screen.csv
"""
import csv, os, sys, random
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EDA_DIR = os.path.join(ROOT, os.pardir, "external_suites", "mm_robustness", "text_perturbation")
OUT = os.path.join(ROOT, "records", "06_screening", "external_suite_screen.csv")

FIRE_THRESHOLD = 55.0
N_CAPTIONS = 500
SEVERITIES = [1, 2, 3, 4, 5]

sys.path.insert(0, EDA_DIR)
import nlpaug.augmenter.char as nac
import nlpaug.augmenter.word as naw

# MM-Robustness sweeps aug_word_p over a ratio grid; we map our severity 1-5 onto it.
RATIO = {1: 0.1, 2: 0.2, 3: 0.3, 4: 0.4, 5: 0.5}


def load_captions(n=N_CAPTIONS):
    val = os.path.join(ROOT, "records", "06_screening", "validation_output.csv")
    seen, caps = set(), []
    for r in csv.DictReader(open(val)):
        o = r["original"].strip()
        if o not in seen:
            seen.add(o); caps.append(o)
        if len(caps) >= n:
            break
    return caps


def lev(a, b):
    if not a:
        return 0.0
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1] / len(a)


# ── operator registry ────────────────────────────────────────────────────────
# class: "structure-independent" = applies to any text (chars/words always exist)
#        "structure-dependent"   = requires specific syntax to be present
def build_ops():
    from eda import synonym_replacement, random_insertion, random_swap, random_deletion

    def _eda(fn, kind):
        def run(text, sev):
            words = text.split()
            n = max(1, int(RATIO[sev] * len(words)))
            try:
                if kind == "p":
                    return " ".join(fn(words, RATIO[sev]))
                return " ".join(fn(words, n))
            except Exception:
                return text
        return run

    def _nac(cls, **kw):
        def run(text, sev):
            try:
                a = cls(aug_word_p=RATIO[sev], **kw)
                o = a.augment(text)
                return o[0] if isinstance(o, list) else o
            except Exception:
                return text
        return run

    return [
        # ---- MM-Robustness (Qiu et al., DMLR 2024) ----
        ("MM-Robustness", "KeyboardAug", "structure-independent", _nac(nac.KeyboardAug)),
        ("MM-Robustness", "OcrAug", "structure-independent", _nac(nac.OcrAug)),
        ("MM-Robustness", "RandomCharAug_delete", "structure-independent",
         _nac(nac.RandomCharAug, action="delete")),
        ("MM-Robustness", "RandomCharAug_insert", "structure-independent",
         _nac(nac.RandomCharAug, action="insert")),
        ("MM-Robustness", "RandomCharAug_substitute", "structure-independent",
         _nac(nac.RandomCharAug, action="substitute")),
        ("MM-Robustness", "RandomCharAug_swap", "structure-independent",
         _nac(nac.RandomCharAug, action="swap")),
        ("MM-Robustness", "EDA_synonym_replace", "structure-independent",
         _eda(synonym_replacement, "n")),
        ("MM-Robustness", "EDA_random_insert", "structure-independent",
         _eda(random_insertion, "n")),
        ("MM-Robustness", "EDA_random_swap", "structure-independent",
         _eda(random_swap, "n")),
        ("MM-Robustness", "EDA_random_delete", "structure-independent",
         _eda(random_deletion, "p")),
        # ---- TCR (ICLR 2025) — same operator family, per released configs ----
        ("TCR", "KeyboardAug", "structure-independent", _nac(nac.KeyboardAug)),
        ("TCR", "OcrAug", "structure-independent", _nac(nac.OcrAug)),
        ("TCR", "RandomCharAug_delete", "structure-independent",
         _nac(nac.RandomCharAug, action="delete")),
        ("TCR", "RandomCharAug_insert", "structure-independent",
         _nac(nac.RandomCharAug, action="insert")),
        ("TCR", "RandomCharAug_substitute", "structure-independent",
         _nac(nac.RandomCharAug, action="substitute")),
        ("TCR", "RandomCharAug_swap", "structure-independent",
         _nac(nac.RandomCharAug, action="swap")),
        ("TCR", "EDA_synonym_replace", "structure-independent",
         _eda(synonym_replacement, "n")),
        ("TCR", "EDA_random_insert", "structure-independent",
         _eda(random_insertion, "n")),
        ("TCR", "EDA_random_swap", "structure-independent",
         _eda(random_swap, "n")),
        ("TCR", "EDA_random_delete", "structure-independent",
         _eda(random_deletion, "p")),
    ]


# Operators present in the published suites but not executed here, with reason.
NOT_RUN = [
    ("MM-Robustness", "back_translation", "structure-independent",
     "whole-sentence rewrite; requires MT models"),
    ("MM-Robustness", "style_formal", "structure-independent", "Styleformer model"),
    ("MM-Robustness", "style_casual", "structure-independent", "Styleformer model"),
    ("MM-Robustness", "style_active", "structure-independent", "Styleformer model"),
    ("MM-Robustness", "style_passive", "structure-independent", "Styleformer model"),
    ("MM-Robustness", "insert_punctuation", "structure-independent", "trivially applies"),
    ("TCR", "back_trans", "structure-independent", "whole-sentence rewrite; MT models"),
    ("TCR", "active/passive/casual/formal", "structure-independent", "Styleformer model"),
    ("TCR", "insert_punctuation", "structure-independent", "trivially applies"),
]


def main():
    caps = load_captions()
    print(f"screening on {len(caps)} COCO captions "
          f"(the same set used for our own validity screen)\n")
    rows = []
    print(f"  {'suite':<15}{'operator':<26}{'class':<24}{'fires':>8}{'CER':>8}  verdict")
    print("  " + "-" * 88)
    for suite, name, klass, fn in build_ops():
        random.seed(123)
        fired, cers, total = 0, [], 0
        for sev in SEVERITIES:
            for c in caps:
                out = fn(c, sev)
                out = out if isinstance(out, str) else c
                total += 1
                if out.strip() != c.strip():
                    fired += 1
                    cers.append(lev(c, out))
        f = fired / total * 100
        v = "pass" if f > FIRE_THRESHOLD else "FAIL"
        print(f"  {suite:<15}{name:<26}{klass:<24}{f:7.1f}%{np.mean(cers) if cers else 0:8.3f}  {v}")
        rows.append({"suite": suite, "operator": name, "class": klass,
                     "fires_pct": round(f, 2),
                     "cer": round(float(np.mean(cers)) if cers else 0.0, 4),
                     "verdict": v, "executed": "yes"})
    for suite, name, klass, why in NOT_RUN:
        rows.append({"suite": suite, "operator": name, "class": klass, "fires_pct": "",
                     "cer": "", "verdict": "not run", "executed": f"no — {why}"})

    # ── ours, same threshold, for the side-by-side ───────────────────────────
    V = list(csv.DictReader(open(os.path.join(
        ROOT, "records", "06_screening", "validation_output.csv"))))
    STRUCT_DEP = {"negation_insertion", "attribute_swap", "relation_swap", "sentence_shuffle"}
    print(f"\n  {'ours':<15}{'operator':<26}{'class':<24}{'fires':>8}{'CER':>8}  verdict")
    print("  " + "-" * 88)
    for op in sorted({r["corruption_type"] for r in V}):
        rs = [r for r in V if r["corruption_type"] == op]
        f = sum(r["corrupted"].strip() != r["original"].strip() for r in rs) / len(rs) * 100
        c = np.mean([float(r["CER"]) for r in rs])
        klass = "structure-DEPENDENT" if op in STRUCT_DEP else "structure-independent"
        v = "pass" if f > FIRE_THRESHOLD else "FAIL"
        print(f"  {'ours':<15}{op:<26}{klass:<24}{f:7.1f}%{c:8.3f}  {v}")
        rows.append({"suite": "ours", "operator": op, "class": klass,
                     "fires_pct": round(f, 2), "cer": round(float(c), 4),
                     "verdict": v, "executed": "yes"})

    # ── the actual result ────────────────────────────────────────────────────
    ex = [r for r in rows if r["executed"] == "yes"]
    print("\n" + "=" * 92)
    print("BY OPERATOR CLASS")
    print("=" * 92)
    for klass in ("structure-independent", "structure-DEPENDENT"):
        sub = [r for r in ex if r["class"].lower() == klass.lower()]
        if not sub:
            continue
        fails = [r for r in sub if r["verdict"] == "FAIL"]
        mf = np.mean([r["fires_pct"] for r in sub])
        print(f"  {klass:<24} n={len(sub):>3}   mean fire {mf:5.1f}%   "
              f"fail {len(fails)}/{len(sub)}"
              + (f"   [{', '.join(r['operator'] for r in fails)}]" if fails else ""))
    n_pub = [r for r in ex if r["suite"] != "ours"]
    print(f"\n  published suites: {sum(r['verdict']=='FAIL' for r in n_pub)}/{len(n_pub)} operators fail")
    print(f"  every structure-dependent operator in the screen belongs to OUR suite;")
    print(f"  neither published suite contains one.")

    with open(OUT, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["suite", "operator", "class", "fires_pct",
                                           "cer", "verdict", "executed"])
        w.writeheader(); w.writerows(rows)
    print(f"\n-> {OUT}")


if __name__ == "__main__":
    main()
