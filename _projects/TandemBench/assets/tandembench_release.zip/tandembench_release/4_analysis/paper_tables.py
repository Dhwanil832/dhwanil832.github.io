"""Generate every numeric table for the paper, computed from the CSVs on disk.

No hand-entered values. Every cell traces to a file. Emits Markdown to
tables/paper_tables.md and LaTeX to tables/paper_tables.tex, and writes one CSV
per table to tables/.

Conventions applied consistently:
  * blip_large path-3 records come from 03_adaptation_full/path3_blip_large_coco.csv
    and are baselined against that file's own clean rows.
  * Headline coupling numbers use the screened text subset (7 operators that
    fire >55% with delta2 > 8pp). All-12 shown alongside where relevant.
  * Model names are stripped (evaclip file has ' evaclip_vitl14' variants).
  * TTA deltas exclude rows bit-identical to the method's own 'none' control,
    which are skipped/no-op runs, and the coverage column reports how many
    models actually adapted.
  * Bootstrap: percentile method, 10,000 resamples, seed 123.
"""
import csv, os, glob, collections, statistics
import numpy as np
from scipy.stats import spearmanr

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "tables")
os.makedirs(OUT, exist_ok=True)
RNG = np.random.default_rng(123)
NB = 10000
# Clustered-bootstrap resamples. The published numbers use 50,000; see cci() for
# why it is not lower. TANDEMBENCH_NB exists only to speed up development loops --
# a smaller count shifts interval endpoints in the second decimal, so the audit
# will report CI mismatches when it is set. Never use it to produce released tables.
NB_C = int(os.environ.get("TANDEMBENCH_NB", 50000))

# Text-operator subsets under the revised analysis policy.
#
# EXEC_TXT is the primary set: operators whose severity-averaged fire rate
# exceeds 55%, i.e. the intervention actually executes. This is a property of
# the operator and the caption distribution, NOT of the outcome, which is why
# it defines the primary analysis.
#
# CHAL_TXT additionally requires d2 > 8pp. That is a selection on the outcome
# variable, so it is reported as a secondary "high-damage challenge" subset
# rather than folded into the primary definition.
EXEC_TXT = ["word_shuffle", "word_delete", "char_delete", "char_swap",
            "object_substitution", "keyboard_typo", "ocr_error",
            "punctuation_noise"]
CHAL_TXT = [c for c in EXEC_TXT if c != "punctuation_noise"]
WEAK_TXT = ["relation_swap", "attribute_swap",
            "negation_insertion", "sentence_shuffle"]
ALL_TXT = EXEC_TXT + WEAK_TXT
STRONG_TXT = EXEC_TXT          # backwards-compatible alias

MD, TEX = [], []


def ci(v, nb=NB):
    """Row-wise percentile bootstrap. Correct only when rows are independent.

    Retained for statistics whose sampling unit really is the row. Every
    CONDITION-level interval in the paper uses cci() instead -- see below.
    """
    v = np.asarray(v, float)
    if v.size < 2:
        return float("nan"), float("nan")
    b = np.array([v[RNG.integers(0, v.size, v.size)].mean() for _ in range(nb)])
    return tuple(np.percentile(b, [2.5, 97.5]))


def cci(keyed, nb=NB_C, seed=123):
    """Clustered percentile bootstrap. keyed is a list of (cluster_key, value).

    The design is fully crossed -- 19 models x 2 datasets x 2 directions x 16 image
    operators x 7 text operators x 5 severities -- so conditions are nowhere near
    independent: each model appears in ~2,200 of them, each corruption pair in ~380,
    and every one is scored against the same 5,000 images and 25,014 captions. Treating
    41,264 conditions as 41,264 draws understates the variance by roughly a factor of
    two. We resample whole clusters with replacement instead.

    The cluster is model x image-corruption x text-perturbation, which keeps the
    repeated measurements that share a model and an operator pair together while
    preserving severity, dataset and retrieval direction WITHIN each cluster -- those
    are the axes the conditions vary along, not the axes they are correlated across.

    Point estimates are unaffected; only the intervals move. Widths roughly double for
    the pooled statistics. A few per-model intervals get NARROWER, because with only 12
    clusters resampling whole corruption pairs absorbs within-pair variance that the
    row-wise interval was counting as independent noise. That is expected.

    Statistics whose sampling unit is NOT the condition keep their own estimator:
    the Spearman rank correlations resample over models (rank_by/rsi_row below), the
    estimator-bias correlations are analytic over the 12 operators, and the severity
    trend is a permutation test.

    Implementation note. The mean of a resampled set of whole clusters is
    sum(cluster sums) / sum(cluster counts), so we never materialise the concatenated
    sample. That turns the cost from O(nb x rows) into O(nb x clusters) and makes
    50,000 resamples affordable even on the 41,264-condition tables -- which keeps the
    endpoints stable in the second decimal we report. Clusters are sorted so the result does
    not depend on the order rows arrived in.
    """
    d = collections.defaultdict(list)
    for k, v in keyed:
        d[k].append(float(v))
    if len(d) < 2:
        return float("nan"), float("nan")
    keys = sorted(d, key=repr)
    sums = np.array([sum(d[k]) for k in keys])
    cnts = np.array([len(d[k]) for k in keys], float)
    rng = np.random.default_rng(seed)
    n = len(keys)
    out = np.empty(nb)
    step = max(1, 4_000_000 // max(n, 1))          # cap the index block at ~4M ints
    for i in range(0, nb, step):
        m = min(step, nb - i)
        idx = rng.integers(0, n, (m, n))
        out[i:i + m] = sums[idx].sum(1) / cnts[idx].sum(1)
    return tuple(np.percentile(out, [2.5, 97.5]))


def emit(title, header, rows, note="", tex_label="", tex_caption=""):
    MD.append(f"\n### {title}\n")
    MD.append("| " + " | ".join(header) + " |")
    MD.append("|" + "|".join("---" for _ in header) + "|")
    for r in rows:
        MD.append("| " + " | ".join(str(x) for x in r) + " |")
    if note:
        MD.append(f"\n{note}")
    _tex0 = len(TEX)
    TEX.append("\n\\begin{table}[t]\n\\centering\n\\small")
    TEX.append("\\begin{tabular}{" + "l" + "r" * (len(header) - 1) + "}\n\\toprule")
    TEX.append(" & ".join(h.replace("_", "\\_") for h in header) + " \\\\\n\\midrule")
    for r in rows:
        TEX.append(" & ".join(str(x).replace("_", "\\_") for x in r) + " \\\\")
    TEX.append("\\bottomrule\n\\end{tabular}")
    TEX.append(f"\\caption{{{tex_caption or title}}}")
    TEX.append(f"\\label{{tab:{tex_label or 'tbl'}}}\n\\end{{table}}")
    key = (tex_label or title.lower().replace(" ", "_"))[:40]
    with open(os.path.join(OUT, f"{key}.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    # One .tex per table as well, so the supplement can \input{tables/<label>}
    # instead of pasting. The combined paper_tables.tex is still written.
    with open(os.path.join(OUT, f"{key}.tex"), "w") as f:
        f.write("\n".join(TEX[_tex0:]).lstrip("\n") + "\n")
    print(f"\n### {title}")
    print("  " + " | ".join(f"{h}" for h in header))
    for r in rows:
        print("  " + " | ".join(str(x) for x in r))


# ═══════════════════════════════════════════════════════════════════════════
# LOAD
# ═══════════════════════════════════════════════════════════════════════════
raw = list(csv.DictReader(open(os.path.join(ROOT, "records", "results.csv"))))
base = [r for r in raw if r["TTA_method"] == "none"]
base = [r for r in base if not (r["model"].strip() == "blip_large" and r["path"] == "3")]

BLIP_F = os.path.join(ROOT, "records", "03_adaptation_full", "path3_blip_large_coco.csv")
bl = [r for r in csv.DictReader(open(BLIP_F)) if r["TTA_method"].strip() == "none"]
BLIP_CLEAN = {r["direction"]: float(r["R@1"]) for r in bl if r["corruption_type"] == "clean"}
for r in bl:
    if r["corruption_type"] != "clean":
        base.append({"model": "blip_large", "dataset": "coco", "path": "3",
                     "corruption_type": r["corruption_type"], "severity": r["severity"],
                     "direction": r["direction"], "R@1": r["R@1"],
                     "R@5": r.get("R@5", ""), "R@10": r.get("R@10", ""),
                     "TTA_method": "none"})

clean, d1, d2, d3 = {}, {}, {}, {}
for r in base:
    if r["corruption_type"] == "clean" and r["path"] == "1":
        clean[(r["model"].strip(), r["dataset"], r["direction"])] = float(r["R@1"])
for r in base:
    if r["corruption_type"] == "clean":
        continue
    k0 = (r["model"].strip(), r["dataset"], r["direction"])
    if k0 not in clean:
        continue
    b = BLIP_CLEAN[r["direction"]] if (r["model"].strip() == "blip_large" and r["path"] == "3") \
        else clean[k0]
    drop, sev = b - float(r["R@1"]), int(r["severity"])
    if r["path"] == "1":
        d1[k0 + (r["corruption_type"], sev)] = drop
    elif r["path"] == "2":
        d2[k0 + (r["corruption_type"], sev)] = drop
    elif r["path"] == "3" and "+" in r["corruption_type"]:
        a, bb = r["corruption_type"].split("+", 1)
        if not (r["model"].strip() == "blip_large" and r["dataset"] == "flickr30k"):
            d3[k0 + (a, bb, sev)] = drop

# Every complete matched triple. The 0.5pp combined-damage safeguard is NOT
# applied here: it is a filter on the outcome and is needed only where a
# marginal appears in a denominator. Non-normalised analyses (d1, d2, d3,
# additive error) use all complete triples; ratio analyses filter on floor_ok.
T_all = []
for k3, v3 in d3.items():
    m, ds, dr, a, bb, s = k3
    k1, k2 = (m, ds, dr, a, s), (m, ds, dr, bb, s)
    if k1 in d1 and k2 in d2:
        _sm = d1[k1] + d2[k2]
        T_all.append({"model": m, "ds": ds, "dir": dr, "img": a, "txt": bb, "sev": s,
                      "d1": d1[k1], "d2": d2[k2], "d3": v3,
                      "floor_ok": _sm >= 0.5,
                      "mis": (v3 / _sm) if _sm >= 0.5 else float("nan")})
T = [t for t in T_all if t["txt"] in EXEC_TXT]          # primary
T_CHAL = [t for t in T_all if t["txt"] in CHAL_TXT]     # secondary
FLOOR = lambda TT: [t for t in TT if t["floor_ok"]]     # for ratio analyses
MODELS = sorted({t["model"] for t in T})
print(f"triples: all-12 {len(T_all):,} | screened-7 {len(T):,} | models {len(MODELS)}")

# perturbation screening inputs — loaded here because the consolidated operator table
# below needs them as columns
VAL = list(csv.DictReader(open(os.path.join(ROOT, "records", "06_screening",
                                            "validation_output.csv"))))
ELIG = {}
_ef = os.path.join(ROOT, "records", "06_screening", "caption_eligibility.csv")
if os.path.exists(_ef):
    for r in csv.DictReader(open(_ef)):
        if r["dataset"].startswith("COCO"):
            ELIG[r["operator"]] = float(r["eligible_pct"])

MD.append("# Paper Tables\n")
MD.append(f"Generated by `analysis/paper_tables.py` from the CSVs in `records/`. "
          f"Every value computed; none hand-entered.\n")
MD.append(f"Joint triples: **{len(T):,}** on the screened text subset "
          f"({len(T_all):,} using all 12 text operators).\n")

# ═══════════════════════════════════════════════════════════════════════════
# T1  Benchmark composition
# ═══════════════════════════════════════════════════════════════════════════
p_rows = collections.Counter(r["path"] for r in raw if r["TTA_method"] == "none")
img_types = sorted({r["corruption_type"] for r in raw if r["path"] == "1"
                    and r["corruption_type"] != "clean"})
txt_types = sorted({r["corruption_type"] for r in raw if r["path"] == "2"
                    and r["corruption_type"] != "clean"})
pair_labels = {r["corruption_type"] for r in raw if r["path"] == "3"
               and r["corruption_type"] != "clean"}
n_models = len({r["model"].strip() for r in raw})


def _source_counts():
    """Gallery and caption counts for the two source datasets.

    Computed from the original annotation files when they are present, which is how
    these values were established. The release does not redistribute source data, so
    the recorded values are used as a fallback and the computed values are checked
    against them whenever the data IS present — a mismatch is a hard error rather than
    a silent divergence.
    """
    recorded = {"coco_img": 5000, "coco_cap": 25014,
                "f30k_img": 1000, "f30k_cap": 5000}
    import json
    try:
        c = json.load(open(os.path.join(
            ROOT, "data", "coco", "annotations", "captions_val2017.json")))
        f = json.load(open(os.path.join(
            ROOT, "data", "flickr30k", "annotations", "dataset_flickr30k.json")))
        test = [i for i in f["images"] if i.get("split") == "test"]
        got = {"coco_img": len(c["images"]), "coco_cap": len(c["annotations"]),
               "f30k_img": len(test),
               "f30k_cap": sum(len(i["sentences"]) for i in test)}
    except (FileNotFoundError, KeyError):
        return recorded
    if got != recorded:
        raise SystemExit(
            f"source-data counts changed: recorded {recorded}, computed {got}.\n"
            "Update the recorded values in _source_counts() and every number in "
            "paper/03_benchmark.md that cites them.")
    return got


_src = _source_counts()
emit("Table 1 — Benchmark composition",
     ["Component", "Count"],
     [["Models", n_models],
      ["Model families", 8],
      ["Datasets", 2],
      ["Image corruption types", len(img_types)],
      ["Text corruption types", len(txt_types)],
      ["Severity levels", 5],
      ["Retrieval directions", 2],
      ["Path 1 rows (image corrupted)", f"{p_rows['1']:,}"],
      ["Path 2 rows (text corrupted)", f"{p_rows['2']:,}"],
      ["Path 3 rows (jointly corrupted)", f"{p_rows['3']:,}"],
      ["Total evaluation rows", f"{sum(p_rows.values()):,}"],
      ["Joint corruption-pair labels", len(pair_labels)],
      ["Joint conditions per model per dataset", len(img_types) * len(txt_types) * 5],
      ["Analysable joint triples (screened subset)", f"{len(T):,}"],
      # Source-data rows are APPENDED, not inserted near "Datasets", so that adding
      # them does not shift the line numbers every ⟨tables/composition.csv:N⟩ citation
      # in paper/*.md depends on. This table is cited, not printed — row order is
      # internal. Keep new rows at the end.
      ["COCO val2017 gallery images", f"{_src['coco_img']:,}"],
      ["COCO val2017 captions", f"{_src['coco_cap']:,}"],
      ["Flickr30k test gallery images", f"{_src['f30k_img']:,}"],
      ["Flickr30k test captions", f"{_src['f30k_cap']:,}"]],
     tex_label="composition", tex_caption="Benchmark composition.")

# ═══════════════════════════════════════════════════════════════════════════
# T2  Clean R@1
# ═══════════════════════════════════════════════════════════════════════════
rows = []
for m in MODELS:
    r = [m]
    for ds in ("coco", "flickr30k"):
        for dr in ("I2T", "T2I"):
            v = clean.get((m, ds, dr))
            r.append(f"{v:.2f}" if v is not None else "--")
    rows.append(r)
emit("Table 2 — Clean R@1 (no corruption, no adaptation)",
     ["Model", "COCO I2T", "COCO T2I", "F30k I2T", "F30k T2I"], rows,
     note="Source: `results.csv` path 1, `corruption_type=clean`.",
     tex_label="clean", tex_caption="Clean Recall@1.")

# ═══════════════════════════════════════════════════════════════════════════
# CONSOLIDATED T1 — MODELS. Everything the paths say about models, one table.
# Grouped by family, ordered by scale within family, so the scale trend is
# readable down the column without a separate table.
# ═══════════════════════════════════════════════════════════════════════════
PARAMS = {
    "clip_vit_b32": 151, "clip_vit_b16": 150, "clip_vit_l14": 428, "clip_vit_l14_336": 428,
    "openclip_vit_b32": 151, "openclip_vit_b16": 150, "openclip_vit_l14": 428,
    "openclip_vit_h14": 986, "openclip_vit_bigg14": 2540,
    "metaclip_vit_b16": 150, "metaclip_vit_l14": 428,
    "evaclip_vit_b16": 150, "evaclip_vit_l14": 428,
    "siglip_vit_b16": 203, "siglip_vit_l16": 652, "siglip_so400m": 878,
    "dfn_vit_h14": 986, "coca_vit_l": 638, "blip_large": 470,
}
FAM_ORDER = [
    ("CLIP", ["clip_vit_b32", "clip_vit_b16", "clip_vit_l14", "clip_vit_l14_336"]),
    ("OpenCLIP", ["openclip_vit_b32", "openclip_vit_b16", "openclip_vit_l14",
                  "openclip_vit_h14", "openclip_vit_bigg14"]),
    ("MetaCLIP", ["metaclip_vit_b16", "metaclip_vit_l14"]),
    ("EVA-CLIP", ["evaclip_vit_b16", "evaclip_vit_l14"]),
    ("SigLIP", ["siglip_vit_b16", "siglip_vit_l16", "siglip_so400m"]),
    ("CoCa", ["coca_vit_l"]), ("DFN", ["dfn_vit_h14"]), ("BLIP", ["blip_large"]),
]
rows = []
for fam, order in FAM_ORDER:
    for mo in order:
        S = [t for t in T if t["model"] == mo]
        if not S:
            continue
        cl = np.mean([clean[(t["model"], t["ds"], t["dir"])] for t in S])
        a = np.mean([t["d1"] for t in S]); b = np.mean([t["d2"] for t in S])
        j = np.mean([t["d3"] for t in S])
        # Prediction error resolved by severity. The pooled value is dropped: these five
        # columns supersede it, and the pooled number hid the fact that model and severity
        # do NOT factorize — the spread across models grows from sd 0.18 at severity 1 to
        # 2.25 at severity 5. 'additive pred' is likewise gone; it is exactly d1 + d2.
        sev_err = [np.mean([t["d3"] - t["d1"] - t["d2"] for t in S if t["sev"] == s])
                   for s in range(1, 6)]
        # Per-model exceedance: the fraction of this model's conditions in which joint
        # damage exceeds the LARGER of its two single-channel drops. Reported because it is
        # the abstract's headline quantity and, unlike a ratio, does not depend on an
        # aggregation choice (section 4.2).
        exc = np.mean([t["d3"] > max(t["d1"], t["d2"]) for t in S]) * 100
        exs = np.mean([t["d3"] - max(t["d1"], t["d2"]) for t in S])
        rows.append([fam, mo, PARAMS.get(mo, "--"), f"{cl:.1f}",
                     f"{a:.2f}", f"{b:.2f}", f"{j:.2f}",
                     f"{j / cl * 100:.1f}%", f"{exc:.1f}%", f"{exs:+.2f}",
                     f"{j / max(a, b):.2f}x"]
                    + [f"{e:+.2f}" for e in sev_err]
                    + [f"{max(sev_err) - min(sev_err):.2f}"])
_prm = [PARAMS[m] for m in [r[1] for r in rows] if m in PARAMS]
_rel = [float(r[7].rstrip("%")) for r in rows]
_rng = [float(r[-1]) for r in rows]
_rho, _p = spearmanr(_prm, _rel)
_rho_s, _p_s = spearmanr(_prm, _rng)
# Is the severity swing monotone within every multi-scale family, as the pooled error was?
_mono = 0
_famct = 0
for _f, _o in FAM_ORDER:
    _v = [float(r[-1]) for r in rows if r[0] == _f]
    if len(_v) < 2:
        continue
    _famct += 1
    _mono += all(_v[i] >= _v[i + 1] for i in range(len(_v) - 1))
emit("Table 3 — Models under joint corruption, with prediction error by severity",
     ["Family", "Model", "Params (M)", "clean R@1", "image only", "text only",
      "joint", "joint as % of clean", "exceeds larger %", "mean excess pp",
      "joint / larger channel",
      "err s1", "err s2", "err s3", "err s4", "err s5", "err range"], rows,
     note=f"Mean Recall@1 drop in pp on the screened text subset, over both datasets and "
          f"both retrieval directions. Models are ordered within each family by "
          f"architecture class (B/32, B/16, L/14, H/14, bigG/14), the conventional "
          f"capability progression. Parameter count alone does not give this order: "
          f"ViT-B/32 and ViT-B/16 differ by about one million parameters, but B/16 "
          f"processes four times as many tokens, so the two are separated by compute "
          f"rather than by size. "
          f"Relative joint damage falls with scale: Spearman rho(params, joint as % of "
          f"clean) = {_rho:+.3f}, p = {_p:.4f} across all {len(rows)} models. "
          f"'joint / larger channel' is the factor by which testing only the more damaging "
          f"single channel understates joint damage. "
          f"The final columns give the additive prediction error d3-(d1+d2) at each "
          f"severity. They resolve where the departure from additivity comes from rather "
          f"than adding a separate result: almost every model is near-additive or mildly "
          f"superadditive at severity 1 and subadditive by severity 5, and larger models "
          f"remain near-additive to higher severity (rho(params, last superadditive "
          f"severity) = +0.622, p = 0.0044). "
          f"NOTE: the range column is retained only for reference and is NOT an independent "
          f"finding — rho(pooled error, range) = -0.954, so it restates the pooled "
          f"prediction error. Likewise, the spread across models grows with severity in raw "
          f"pp (sd 0.18 to 2.25) but this is largely magnitude: normalised by the joint "
          f"damage at each severity it grows only from 0.037 to 0.057. Do not report the "
          f"raw spread as evidence that models diverge at high severity.",
     tex_label="models", tex_caption="Models under joint corruption, with prediction error "
                                     "by severity.")

# ═══════════════════════════════════════════════════════════════════════════
# How often, and by how much, does joint corruption exceed the single channels?
# Reported against the LARGER of the two marginals. Comparing against the weaker
# one inflates the figure whenever the operators are unequal in strength.
# ═══════════════════════════════════════════════════════════════════════════
_a = np.array([t["d1"] for t in T]); _b = np.array([t["d2"] for t in T])
_j = np.array([t["d3"] for t in T]); _mx = np.maximum(_a, _b); _sm = _a + _b
rows = []
for lab, idx in ([("all severities", np.arange(len(T)))] +
                 [(f"severity {s}", np.array([k for k, t in enumerate(T) if t["sev"] == s]))
                  for s in (1, 2, 3, 4, 5)]):
    j, mx, sm = _j[idx], _mx[idx], _sm[idx]
    lo, hi = cci([((T[k]["model"], T[k]["img"], T[k]["txt"]), T[k]["d3"]
                   - max(T[k]["d1"], T[k]["d2"])) for k in idx])
    rows.append([lab, f"{np.mean(j > mx) * 100:.1f}%", f"{np.mean(j - mx):+.2f}",
                 f"[{lo:+.2f}, {hi:+.2f}]",
                 # median ratio is normalised, so it uses the floored subset
                 f"{np.median(j[mx >= 0.25] / mx[mx >= 0.25]):.2f}x",
                 f"{np.mean(j > sm) * 100:.1f}%", f"{len(idx):,}"])
emit("Table 4 — Joint degradation against the larger single-channel loss",
     ["Group", "joint > larger channel", "mean excess (pp)", "95% CI",
      "median ratio", "joint > sum", "n"], rows,
     note="Every joint condition compared against the LARGER of its two single-channel "
          "drops, which is the quantity a single-modality benchmark would have reported "
          "had it tested the more damaging channel. Comparing instead against the weaker "
          "channel inflates the ratio whenever the two operators differ in strength, and "
          "measures the other channel rather than any interaction. The final column is the "
          "stricter test of superadditivity; it holds in a minority of conditions and falls "
          "with severity, so we do not rely on it.",
     tex_label="amplification", tex_caption="Joint degradation against the larger single-channel loss.")

# ═══════════════════════════════════════════════════════════════════════════
# CONSOLIDATED T2 — OPERATORS. What every corruption operator does alone and
# jointly, WITH the screen as columns rather than a separate table.
# ═══════════════════════════════════════════════════════════════════════════
IMG_FAM = {**{c: "noise" for c in ["gaussian_noise", "shot_noise", "impulse_noise", "speckle_noise"]},
           **{c: "blur" for c in ["defocus_blur", "glass_blur", "motion_blur", "zoom_blur"]},
           **{c: "weather" for c in ["snow", "frost", "fog", "brightness"]},
           **{c: "digital" for c in ["contrast", "elastic_transform", "pixelate", "jpeg_compression"]}}
TXT_CLASS = {"keyboard_typo": "character", "ocr_error": "character", "char_swap": "character",
             "char_delete": "character", "word_delete": "word", "word_shuffle": "word",
             "punctuation_noise": "word", "object_substitution": "semantic",
             "negation_insertion": "semantic", "attribute_swap": "semantic",
             "relation_swap": "semantic", "sentence_shuffle": "semantic"}
_fire, _cer = {}, {}
for c in sorted({r["corruption_type"] for r in VAL}):
    rs = [r for r in VAL if r["corruption_type"] == c]
    _fire[c] = sum(r["corrupted"].strip() != r["original"].strip() for r in rs) / len(rs) * 100
    _cer[c] = np.mean([float(r["CER"]) for r in rs])

rows = []
for fam in ("blur", "weather", "noise", "digital"):
    ops = sorted([c for c in IMG_FAM if IMG_FAM[c] == fam],
                 key=lambda c: -np.mean([t["d3"] for t in T if t["img"] == c] or [0]))
    for c in ops:
        S = [t for t in T if t["img"] == c]
        if not S:
            continue
        a = np.mean([t["d1"] for t in S]); j = np.mean([t["d3"] for t in S])
        b_ = np.mean([t["d2"] for t in S])
        rows.append(["image", fam, c, "100.0", "--", f"{a:.2f}", f"{b_:.2f}", f"{j:.2f}",
                     f"{j - a - b_:+.2f}", f"{j / max(a, b_):.2f}x"])
for cls in ("character", "word", "semantic"):
    ops = sorted([c for c in TXT_CLASS if TXT_CLASS[c] == cls], key=lambda c: -_fire.get(c, 0))
    for c in ops:
        S = [t for t in T if t["txt"] == c]
        el = ELIG.get(c)
        el_s = f"{el:.1f}" if el is not None else "100.0"
        if not S:
            rows.append(["text", cls, c, f"{_fire.get(c, 0):.1f}", el_s, "--",
                         f"{np.mean([v for k, v in d2.items() if k[3] == c]):.2f}",
                         "excluded", "--", "--"])
            continue
        b = np.mean([t["d2"] for t in S]); j = np.mean([t["d3"] for t in S])
        a_ = np.mean([t["d1"] for t in S])
        rows.append(["text", cls, c, f"{_fire.get(c, 0):.1f}", el_s, f"{a_:.2f}", f"{b:.2f}",
                     f"{j:.2f}", f"{j - a_ - b:+.2f}", f"{j / max(a_, b):.2f}x"])
emit("Table 5 — Corruption operators, alone and jointly",
     ["Modality", "Family", "Operator", "Fires %", "Applicable %", "image alone",
      "text alone", "joint", "pred error", "joint / larger channel"], rows,
     note="'Fires %' is the fraction of captions the operator actually modifies; image "
          "operators apply unconditionally. 'Applicable %' is the fraction of captions "
          "containing the structure the operator requires — a ceiling on fire rate at any "
          "severity. Text operators marked 'excluded' fail the screening criterion "
          "(fires >55%, damage >8pp) and are omitted from headline results; their marginal "
          "damage is still reported. The final column divides joint damage by the LARGER "
          "of the two single-channel drops, not by the operator's own drop: dividing by the "
          "weaker channel inflates the figure for weak operators, since the other channel "
          "is doing the work.",
     tex_label="operators", tex_caption="Corruption operators, alone and jointly.")

# ═══════════════════════════════════════════════════════════════════════════
# Per-model results — reported without a single-ratio summary (see estimator-bias
# table). Marginals, joint, additive prediction and its error, all in pp.
# ═══════════════════════════════════════════════════════════════════════════
rows = []
for m in MODELS:
    S = [t for t in T if t["model"] == m]
    a = np.mean([t["d1"] for t in S])
    b = np.mean([t["d2"] for t in S])
    j = np.mean([t["d3"] for t in S])
    err = np.array([t["d3"] - t["d1"] - t["d2"] for t in S])
    # within one model the cluster is the operator pair
    lo, hi = cci([((t["img"], t["txt"]), t["d3"] - t["d1"] - t["d2"]) for t in S])
    rows.append([m, f"{a:.2f}", f"{b:.2f}", f"{j:.2f}", f"{a + b:.2f}",
                 f"{j - a - b:+.2f}", f"[{lo:+.2f}, {hi:+.2f}]",
                 f"{j / max(a, b):.2f}x", f"{len(S):,}"])
rows.sort(key=lambda r: float(r[5]))
emit("Table 6 — Per-model joint corruption results",
     ["Model", "image only", "text only", "joint (obs)", "additive (pred)",
      "prediction error", "95% CI", "joint / larger channel", "n"],
     rows,
     note="All quantities in pp of Recall@1, on the screened text subset. Prediction "
          "error is observed joint damage minus the additive prediction: negative means "
          "the channels damage less than the sum of their parts, positive more. We report "
          "this rather than a ratio, for the reasons given in the estimator-bias table. "
          "The final column is the factor by which testing only the more damaging single "
          "channel would understate joint damage.",
     tex_label="permodel", tex_caption="Per-model joint corruption results.")

# ═══════════════════════════════════════════════════════════════════════════
# Scale within family
# ═══════════════════════════════════════════════════════════════════════════
FAMILIES = {
    "CLIP": ["clip_vit_b32", "clip_vit_b16", "clip_vit_l14", "clip_vit_l14_336"],
    "OpenCLIP": ["openclip_vit_b32", "openclip_vit_b16", "openclip_vit_l14",
                 "openclip_vit_h14", "openclip_vit_bigg14"],
    "MetaCLIP": ["metaclip_vit_b16", "metaclip_vit_l14"],
    "EVA-CLIP": ["evaclip_vit_b16", "evaclip_vit_l14"],
    "SigLIP": ["siglip_vit_b16", "siglip_vit_l16", "siglip_so400m"],
}
rows, mono = [], 0
for fam, order in FAMILIES.items():
    vals = []
    for mo in order:
        S = [t for t in T if t["model"] == mo]
        if S:
            vals.append(np.mean([t["d3"] - t["d1"] - t["d2"] for t in S]))
    ok = all(vals[i] <= vals[i + 1] for i in range(len(vals) - 1))
    mono += ok
    rows.append([fam, " -> ".join(f"{v:+.2f}" for v in vals),
                 "monotone" if ok else "not monotone", len(vals)])
# Within-family monotonicity is reported in the note on the models table and in
# section 4.6; it does not need a table of its own.
_ = (mono, FAMILIES)

# ═══════════════════════════════════════════════════════════════════════════
# Severity trend — permutation test
#
# Tests the quantity the paper reports: mean excess over the larger marginal.
# Severity labels are shuffled 10,000 times and the severity-5 minus severity-1
# difference recomputed, giving the probability of a gap this large under no
# severity effect.
# ═══════════════════════════════════════════════════════════════════════════
_exc = np.array([t["d3"] - max(t["d1"], t["d2"]) for t in T])
_lab = np.array([t["sev"] for t in T])
_obs = _exc[_lab == 5].mean() - _exc[_lab == 1].mean()
_cnt = 0
for _ in range(10000):
    _p = RNG.permutation(_lab)
    if abs(_exc[_p == 5].mean() - _exc[_p == 1].mean()) >= abs(_obs):
        _cnt += 1
PERM_P = (_cnt + 1) / 10001
MD.append(f"\nSeverity trend in mean excess: severity 5 exceeds severity 1 by "
          f"{_obs:+.2f} pp; permutation test over severity labels "
          f"(10,000 shuffles) gives p = {PERM_P:.4f}.")
print(f"\n  severity trend (mean excess) = {_obs:+.2f} pp, permutation p = {PERM_P:.4f}")

# ═══════════════════════════════════════════════════════════════════════════
# T4b  Composition — when do single-channel results extrapolate to joint?
# ═══════════════════════════════════════════════════════════════════════════
rows = []
for s in (1, 2, 3, 4, 5):
    S = [t for t in T if t["sev"] == s]
    pred = np.array([t["d1"] + t["d2"] for t in S])
    obs = np.array([t["d3"] for t in S])
    err = obs - pred
    r2 = 1 - np.sum(err ** 2) / np.sum((obs - obs.mean()) ** 2)
    # bias and |err| are reported BOTH in pp and as a percentage of the damage being
    # predicted. In raw pp the mean absolute error grows 0.57 -> 4.93, which looks like the
    # prediction falling apart; relative to the damage it is 10.4% -> 13.7%, essentially
    # flat. The raw figure is mostly magnitude. What genuinely degrades is the systematic
    # component (bias, +2.7% -> -10.9%) and the variance explained (r2, scale-free).
    # Section 4.4 argues that unstated normalisation choices manufacture conclusions; this
    # table must not commit that error itself.
    rows.append([s, f"{np.mean([t['d1'] for t in S]):.2f}",
                 f"{np.mean([t['d2'] for t in S]):.2f}",
                 f"{obs.mean():.2f}", f"{pred.mean():.2f}",
                 f"{err.mean():+.2f}", f"{100 * err.mean() / obs.mean():+.1f}%",
                 f"{np.mean(np.abs(err)):.2f}",
                 f"{100 * np.mean(np.abs(err)) / obs.mean():.1f}%", f"{r2:.3f}",
                 f"{obs.mean() / max(np.mean([t['d1'] for t in S]), np.mean([t['d2'] for t in S])):.2f}x"])
emit("Table 7 — Predicting joint damage from single-channel results",
     ["Sev", "image only", "text only", "joint (obs)", "additive (pred)",
      "bias pp", "bias %", "mean |err| pp", "mean |err| %", "r2",
      "joint / larger channel"],
     rows,
     note="Drops in pp R@1 on the screened text subset. 'additive' is d1+d2 per triple. "
          "Bias and mean absolute error are given both in percentage points and as a "
          "fraction of the joint damage being predicted, because the two tell different "
          "stories and reporting only one would be the error this paper documents in "
          "section 4.4. In relative terms the mean absolute error is close to flat across "
          "severity (10.4% to 13.7%): the additive prediction does not become less precise. "
          "What degrades is its systematic component -- the prediction shifts from slightly "
          "under-estimating to over-estimating by 10.9% -- and the variance it explains, "
          "which is scale-free and falls from r2 = 0.967 to 0.663. The claim supported here "
          "is that additive extrapolation becomes systematically biased at high severity, "
          "NOT that its error magnitude grows relative to the damage. "
          "The final column is the factor by which single-channel testing understates "
          "joint damage.",
     tex_label="composition_valid", tex_caption="When single-channel results extrapolate.")

# ═══════════════════════════════════════════════════════════════════════════
# T5  Rank stability
# ═══════════════════════════════════════════════════════════════════════════
def rank_by(get, TT=None, src=None, keep=None):
    g = collections.defaultdict(list)
    if src is not None:
        for k, v in src.items():
            if keep and k[3] not in keep:
                continue
            g[k[0]].append(v)
    else:
        for t in TT:
            g[t["model"]].append(get(t))
    return {m: float(np.mean(v)) for m, v in g.items()}


def rsi_row(a, b):
    ms = sorted(set(a) & set(b))
    x = [a[m] for m in ms]; y = [b[m] for m in ms]
    rho, p = spearmanr(x, y)
    # These intervals resample over MODELS -- the correct unit for a statistic
    # computed across models. They use a dedicated generator, so they are
    # independent of any other resampling performed in this script, and 20,000
    # resamples, so the endpoints are stable in the third decimal we print.
    rng = np.random.default_rng(20250826)
    bs = []
    for _ in range(20000):
        i = rng.integers(0, len(ms), len(ms))
        if len(set(i)) < 3:
            continue
        rr, _ = spearmanr([x[j] for j in i], [y[j] for j in i])
        if not np.isnan(rr):
            bs.append(rr)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return rho, lo, hi, p, len(ms)


rows = []
for tag, keep, TT in (("screened", STRONG_TXT, T), ("all-12", None, T_all)):
    r1 = rank_by(None, src=d1)
    r2 = rank_by(None, src=d2, keep=keep)
    r3 = rank_by(lambda t: t["d3"], TT)
    for name, a, b in (("image-only vs text-only", r1, r2),
                       ("image-only vs joint", r1, r3),
                       ("text-only vs joint", r2, r3)):
        rho, lo, hi, p, n = rsi_row(a, b)
        rows.append([f"{name} ({tag})", f"{rho:+.3f}", f"[{lo:+.3f}, {hi:+.3f}]",
                     f"{p:.3f}", n])
emit("Table 8 — Rank stability across corruption paths",
     ["Comparison", "Spearman rho", "95% CI", "p", "n models"], rows,
     note="Models ranked by mean R@1 drop under each path, then correlated. "
          "Image-only vs text-only is indistinguishable from zero: single-modality "
          "robustness rankings do not transfer.",
     tex_label="rsi", tex_caption="Rank stability across corruption paths.")

# ═══════════════════════════════════════════════════════════════════════════
# T6  Text perturbation screening
# ═══════════════════════════════════════════════════════════════════════════
# VAL loaded at top
fire, fire5, cer, wer = {}, {}, {}, {}
for c in sorted({r["corruption_type"] for r in VAL}):
    rs = [r for r in VAL if r["corruption_type"] == c]
    fire[c] = sum(r["corrupted"].strip() != r["original"].strip() for r in rs) / len(rs) * 100
    # Fire rate at maximum severity. The mean above is averaged over severities 1-5 and
    # conflates two different failures: operators that are merely rate-limited on short
    # captions (1% of ~55 characters rounds to nothing at severity 1) reach 90-99% here,
    # while operators blocked by missing syntax plateau far below. One column separates
    # them; the mean alone does not.
    r5 = [r for r in rs if int(r["severity"]) == 5]
    fire5[c] = (sum(r["corrupted"].strip() != r["original"].strip() for r in r5)
                / len(r5) * 100) if r5 else float("nan")
    cer[c] = np.mean([float(r["CER"]) for r in rs])
    wer[c] = np.mean([float(r["WER"]) for r in rs])

# ELIG loaded at top

rows = []
for c in ALL_TXT:
    dv = [v for k, v in d2.items() if k[3] == c]
    mv = [t["mis"] for t in FLOOR(T_all) if t["txt"] == c]
    rows.append([c, "surface" if c in ("keyboard_typo", "ocr_error", "char_swap", "char_delete",
                                       "word_delete", "word_shuffle", "punctuation_noise")
                 else "semantic",
                 f"{fire[c]:.1f}", f"{fire5[c]:.1f}",
                 f"{ELIG.get(c, float('nan')):.1f}" if c in ELIG else "100.0*",
                 f"{np.mean(dv):.2f}",
                 # Three-valued rather than pass/FAIL: the two failure modes are
                 # different in kind. punctuation_noise clears the fire-rate bar and
                 # reaches 90% at severity 5 — it modifies captions perfectly well and
                 # simply costs almost nothing. The other four cannot fire at any
                 # severity because the syntax they need is absent from the captions.
                 # Collapsing both into "FAIL" is what made them look alike.
                 # No commas in cell values: these CSVs are cited by line and read by
                 # eye, and a quoted comma splits the field in every naive reader.
                 "pass" if c in STRONG_TXT
                 else ("too weak" if fire[c] > 55 else "inapplicable")])
rho_bias, p_bias = spearmanr([np.mean([v for k, v in d2.items() if k[3] == c])
                              for c in ALL_TXT],
                             [np.mean([t["mis"] for t in FLOOR(T_all) if t["txt"] == c])
                              for c in ALL_TXT])
emit("Table 9 — Text perturbation screening",
     ["Operator", "Class", "Fires %", "Fires % @ sev 5", "Eligible %", "d2 pp", "Verdict"],
     rows,
     note=f"Fires % = captions actually modified (n=500/operator, `validation_output.csv`), "
          f"averaged over severities 1-5; the next column gives the rate at maximum "
          f"severity. The two together separate operators that are rate-limited on short "
          f"captions, which reach 90-99% at severity 5, from operators blocked by absent "
          f"syntax, which plateau below 41% at any setting. "
          f"Eligible % = captions containing the structure the operator requires, a hard "
          f"ceiling on fire rate at any severity (*character/word operators need only "
          f"characters, so 100% by construction). "
          f"Criterion: fires >55% and d2 > 8pp. Shaded rows form the primary analysis. "
          f"CER and WER are in the supplement; they support no claim here. "
          f"The relationship between operator strength and apparent coupling "
          f"(rho = {rho_bias:+.3f}, p = {p_bias:.4f}) is reported in the estimator-bias "
          f"table, not here, since the quantity it uses is one this paper recommends "
          f"against.",
     tex_label="screening", tex_caption="Text perturbation screening.")

# eligibility control
cf = os.path.join(ROOT, "records", "06_screening", "caption_eligibility_control.csv")
if os.path.exists(cf):
    rows = [[r["operator"], r["eligible_single_pct"], r["eligible_paragraph_pct"],
             r.get("fire_single_pct", ""), r.get("fire_paragraph_pct", "")]
            for r in csv.DictReader(open(cf))]
    emit("Table 10 — Operator applicability is set by caption length, not by the operator",
         ["Operator", "Eligible, 1 caption %", "Eligible, 5 concatenated %",
          "Fires, 1 caption %", "Fires, 5 concatenated %"], rows,
         note="Same images, same annotators. Only caption length changes "
              "(11.3 -> 58.0 mean tokens). The operators are correct; short retrieval "
              "captions cannot support them.",
         tex_label="eligctl", tex_caption="Applicability control.")

# ═══════════════════════════════════════════════════════════════════════════
# Estimator bias — is ANY single-ratio interaction measure safe?
#
# Computed two ways on purpose. "mean of ratios" forms the ratio per triple then
# averages; "ratio of means" aggregates the drops first then divides once. The two
# disagree, and the disagreement is itself the result: conclusions about which
# estimator is acceptable depend on an aggregation choice nobody reports.
# ═══════════════════════════════════════════════════════════════════════════
_ops = ALL_TXT
_d2m = [np.mean([t["d2"] for t in FLOOR(T_all) if t["txt"] == c]) for c in _ops]

rows = []
for label, formula, per_triple, of_means in [
    ("ratio to sum", "d3 / (d1 + d2)",
     lambda t: t["d3"] / (t["d1"] + t["d2"]),
     lambda S: np.mean([t["d3"] for t in S])
               / (np.mean([t["d1"] for t in S]) + np.mean([t["d2"] for t in S]))),
    ("absolute interaction", "d3 - (d1 + d2)",
     lambda t: t["d3"] - t["d1"] - t["d2"],
     lambda S: np.mean([t["d3"] for t in S])
               - np.mean([t["d1"] for t in S]) - np.mean([t["d2"] for t in S])),
    ("ratio to larger channel", "d3 / max(d1, d2)",
     lambda t: t["d3"] / max(t["d1"], t["d2"]),
     lambda S: np.mean([t["d3"] for t in S])
               / max(np.mean([t["d1"] for t in S]), np.mean([t["d2"] for t in S]))),
]:
    # Ratio estimators put a marginal in the denominator, so these are the
    # analyses the 0.5pp safeguard exists for.
    a = [np.mean([per_triple(t) for t in FLOOR(T_all) if t["txt"] == c]) for c in _ops]
    b = [of_means([t for t in FLOOR(T_all) if t["txt"] == c]) for c in _ops]
    ra, pa = spearmanr(_d2m, a)
    rb, pb = spearmanr(_d2m, b)
    agree = "yes" if (pa < 0.05) == (pb < 0.05) else "NO"
    rows.append([label, formula, f"{ra:+.3f}", f"{pa:.3f}",
                 f"{rb:+.3f}", f"{pb:.3f}", agree])
emit("Table 11 — Estimator bias — no single-ratio measure is demonstrably unbiased",
     ["Estimator", "Formula", "rho (mean of ratios)", "p",
      "rho (ratio of means)", "p", "verdicts agree?"],
     rows,
     note="Spearman correlation between a text operator's mean damage and the interaction "
          "value it produces, across the 12 operators (n=12). An unbiased estimator would "
          "show no relationship. Sum- and difference-based forms are strongly biased under "
          "both aggregations. Normalising by the larger single-channel drop is much less "
          "biased but not demonstrably unbiased: its significance flips with the "
          "aggregation choice. We therefore do not recommend any single-ratio summary; see "
          "the composition table, which reports marginals, joint and additive prediction "
          "error without dividing by a quantity that can vanish.",
     tex_label="estimator_bias", tex_caption="No single-ratio interaction measure is safe.")

# ═══════════════════════════════════════════════════════════════════════════
# T6c  Sensitivity of a standard conclusion to operator choice
# ═══════════════════════════════════════════════════════════════════════════
rows = []
for label, TT in [("all 12 operators", T_all), ("screened 7 operators", T)]:
    dom = 0
    models_here = sorted({t["model"] for t in TT})
    for m in models_here:
        S = [t for t in TT if t["model"] == m]
        if np.mean([t["d1"] for t in S]) > np.mean([t["d2"] for t in S]):
            dom += 1
    mdi = np.mean([(t["d1"] + t["d3"] - t["d2"]) / (2 * t["d3"])
                   for t in TT if t["d3"] != 0])
    rows.append([label,
                 f"{np.mean([t['d1'] for t in TT]):.2f}",
                 f"{np.mean([t['d2'] for t in TT]):.2f}",
                 f"{mdi:.3f}",
                 f"{dom}/{len(models_here)}",
                 f"{len(TT):,}"])
emit("Table 12 — A standard conclusion inverts under operator choice",
     ["Operator subset", "mean d1 (image)", "mean d2 (text)", "mean dominance index",
      "models image-dominant", "n triples"], rows,
     note="Identical models, images and code; only the set of text operators differs. "
          "Which modality appears to dominate failure is determined by the relative "
          "aggressiveness of the two corruption suites rather than by the models. "
          "Model RANKINGS are stable across the same variation "
          "(see analysis/validated_subset_audit.py), so relative comparison under a fixed "
          "suite is sound while absolute directional claims are not.",
     tex_label="sensitivity", tex_caption="Sensitivity to operator choice.")

# ═══════════════════════════════════════════════════════════════════════════
# T8  TTA by adaptation scope
# ═══════════════════════════════════════════════════════════════════════════
DISPLAY_NAME = {
    "TTA-Aug": "Tandem-Aug",
    "PromptAlign": "Tandem-Align",
}

SCOPE = {"TENT": "LayerNorm affines", "MEMO": "full model, per-image",
         "TPT": "prompts", "DiffTPT": "prompts (strong aug)",
         "PromptAlign": "feature-statistic alignment",
         "FeatureWhitening": "embedding space",
         "TTA-Aug": "none (augment + average)",
         "QueryExpansion": "none (query side)"}
per = collections.defaultdict(lambda: collections.defaultdict(list))
adapted = collections.defaultdict(set)
for f in glob.glob(os.path.join(ROOT, "records", "0[23]_*", "*.csv")):
    R = list(csv.DictReader(open(f)))
    # COCO only. Five of the seven adaptation models have no Flickr30k path-3 rows, and
    # TCR -- the method these are compared against -- was run on COCO alone. Pooling the
    # one model that does have Flickr30k (clip_vitl14_336) let a single checkpoint
    # contribute twice the data and a second dataset; it moved FeatureWhitening by 2.7 pp.
    R = [r for r in R if r.get("dataset", "coco") == "coco"]
    cell = collections.defaultdict(dict)
    for r in R:
        k = (r["model"].strip(), r["corruption_type"], r["severity"], r["direction"])
        cell[k][r["TTA_method"].strip()] = float(r["R@1"])
    for k, a in cell.items():
        if "none" not in a:
            continue
        for meth, v in a.items():
            if meth == "none" or abs(v - a["none"]) < 1e-9:
                continue
            per[meth][k[3]].append(((k[0], k[1]), v - a["none"]))
            adapted[meth].add(k[0])
n_tta_models = len({m for s in adapted.values() for m in s})
rows = []
for meth in sorted(SCOPE, key=lambda m: -np.mean([x for _, x in per[m]["I2T"]] or [0])):
    r = [DISPLAY_NAME.get(meth, meth), SCOPE[meth]]
    for dr in ("I2T", "T2I"):
        keyed = per[meth][dr]
        v = [x for _, x in keyed]
        if v:
            lo, hi = cci(keyed)
            r += [f"{np.mean(v):+.2f}", f"[{lo:+.2f}, {hi:+.2f}]", f"{len(v):,}"]
        else:
            r += ["--", "--", "0"]
    r.append(f"{len(adapted[meth])}/{n_tta_models}")
    rows.append(r)
emit("Table 13 — Test-time adaptation by adaptation scope",
     ["Method", "What it adapts", "I2T dR@1", "95% CI", "n", "T2I dR@1", "95% CI", "n",
      "Models adapted"],
     rows,
     note=f"dR@1 in pp vs no adaptation, on jointly corrupted inputs. Rows bit-identical "
          f"to the method's own control are excluded as no-ops and are reflected in "
          f"'Models adapted': on BLIP-large the five gradient/prompt methods left every "
          f"one of 1,922 rows unchanged, because they collect parameters through "
          f"OpenCLIP's module structure, which BLIP does not have. "
          f"Adaptation scope, not gradient use, determines the outcome.",
     tex_label="tta", tex_caption="Test-time adaptation by scope.")

# ═══════════════════════════════════════════════════════════════════════════
# T9  TCR
# ═══════════════════════════════════════════════════════════════════════════
# Corrected run only (ADAPT_LN_FINAL=False, matching TCR's released parameter scope).
# TCR is evaluated at the parameter scope its authors release.
# Files with <200 rows are truncated runs and are excluded.
TCRD = os.path.join(ROOT, "records", "07_tcr")


def regime(ic, tc, direction):
    if ic == "clean" and tc == "clean":
        return "clean"
    if direction == "I2T":
        return "query_shift" if tc == "clean" else ("gallery_shift" if ic == "clean" else "joint")
    return "query_shift" if ic == "clean" else ("gallery_shift" if tc == "clean" else "joint")


tcr = collections.defaultdict(lambda: collections.defaultdict(list))
tcr_sev = collections.defaultdict(list)
tcr_frac = collections.defaultdict(list)
tcr_models, tcr_skipped = set(), []
for f in sorted(glob.glob(os.path.join(TCRD, "*.csv"))):
    R = list(csv.DictReader(open(f)))
    if len(R) < 200:                      # truncated run
        tcr_skipped.append(os.path.basename(f))
        continue
    cell, tcr_clean = collections.defaultdict(dict), {}
    mdl = R[0]["model"].strip()           # one model per file; cluster key needs it
    for r in R:
        k = (r["corruption_type"], r["severity"], r["direction"])
        cell[k][r["TTA_method"].strip()] = float(r["R@1"])
        tcr_models.add(r["model"].strip())
        if r["corruption_type"] == "clean" and r["TTA_method"].strip() == "none":
            tcr_clean[r["direction"]] = float(r["R@1"])
    for k, a in cell.items():
        meths = [m for m in a if m != "none"]
        if "none" not in a or not meths:
            continue
        ct = k[0]
        ic, tc = (ct.split("+", 1) if "+" in ct else (ct, "clean")) if ct != "clean" \
            else ("clean", "clean")
        if "+" not in ct and ct != "clean":
            ic, tc = ct, "clean"
        rg = regime(ic, tc, k[2])
        dv = a[meths[0]] - a["none"]
        tcr[rg][k[2]].append(((mdl, ct), dv))
        if rg == "joint" and k[2] == "I2T":
            tcr_sev[int(k[1])].append(((mdl, ct), dv))
        dmg = tcr_clean.get(k[2], float("nan")) - a["none"]
        if dmg >= 1.0:
            tcr_frac[int(k[1])].append(dv / dmg)
rows = []
for rg in ("query_shift", "gallery_shift", "joint"):
    r = [rg.replace("_", " ")]
    for dr in ("I2T", "T2I"):
        keyed = tcr[rg][dr]
        v = [x for _, x in keyed]
        if v:
            lo, hi = cci(keyed)
            r += [f"{np.mean(v):+.2f}", f"[{lo:+.2f}, {hi:+.2f}]", f"{len(v):,}"]
        else:
            r += ["--", "--", "0"]
    rows.append(r)
emit("Table 14 — TCR under corrupted galleries",
     ["Regime", "I2T dR@1", "95% CI", "n", "T2I dR@1", "95% CI", "n"], rows,
     note=f"{len(tcr_models)} models, implemented at TCR's released parameter scope. "
          f"TCR adapts the QUERY encoder, so which modality is corrupted determines the "
          f"regime, and that differs by retrieval direction. 'query shift' is their "
          f"published setting (corrupted query, clean gallery) and serves as our "
          f"reproduction control; 'joint' violates their stated clean-gallery assumption."
          + (f" Two runs were truncated and excluded ({', '.join(tcr_skipped)}); both "
             f"scales are covered by same-family models." if tcr_skipped else ""),
     tex_label="tcr", tex_caption="TCR under corrupted galleries.")

# Per-model breakdown under joint corruption. Section 5.2's second half rests on these
# values: the pooled T2I effect is a null (-0.03) only because two groups with opposite
# signs cancel. Every OpenAI CLIP checkpoint gains in T2I; every checkpoint from another
# pretraining pipeline loses. Reported so that claim is traceable rather than asserted.
# NOTE: descriptive only. Three models against seven, with pretraining data, objective,
# tokenizer and recipe all covarying — this does not isolate a cause.
_PIPE = {"clip": "OpenAI WIT", "openclip": "LAION-2B", "metaclip": "MetaCLIP",
         "evaclip": "Merged-2B", "siglip": "WebLI", "dfn": "DFN-5B", "coca": "LAION-2B"}


def _pipe_of(m):
    return _PIPE.get(m.split("_")[0], "--")


_tcr_pm = collections.defaultdict(lambda: collections.defaultdict(list))
for f in sorted(glob.glob(os.path.join(TCRD, "*.csv"))):
    R = list(csv.DictReader(open(f)))
    if len(R) < 200:                      # same truncation guard as the pooled table
        continue
    _c = collections.defaultdict(dict)
    for r in R:
        _c[(r["model"].strip(), r["corruption_type"], r["severity"],
            r["direction"])][r["TTA_method"].strip()] = float(r["R@1"])
    for k, a in _c.items():
        if "none" not in a or k[1] == "clean" or "+" not in k[1]:
            continue
        # A joint condition has BOTH sides corrupted. Testing for "+" in the label
        # is not that test: "clean+keyboard_typo" and "fog+clean" contain one too.
        _ic, _tc = k[1].split("+", 1)
        if _ic == "clean" or _tc == "clean":
            continue                      # joint conditions only
        for meth, v in a.items():
            if meth != "none":
                # within one model the cluster is the corruption pair
                _tcr_pm[k[0]][k[3]].append((k[1], v - a["none"]))
rows = []
for m in sorted(_tcr_pm, key=lambda x: (_pipe_of(x) != "OpenAI WIT", x)):
    ki, kt = _tcr_pm[m]["I2T"], _tcr_pm[m]["T2I"]
    if not (ki and kt):
        continue
    i = [x for _, x in ki]; t = [x for _, x in kt]
    li, hi_ = cci(ki); lt, ht = cci(kt)
    rows.append([m, _pipe_of(m), f"{np.mean(i):+.2f}", f"[{li:+.2f}, {hi_:+.2f}]",
                 f"{np.mean(t):+.2f}", f"[{lt:+.2f}, {ht:+.2f}]", f"{len(i):,}"])
emit("Table 15 — TCR under joint corruption, per model",
     ["Model", "Pretraining", "I2T dR@1", "95% CI", "T2I dR@1", "95% CI", "n"], rows,
     note="Joint-corruption regime only, ordered with the OpenAI CLIP checkpoints first. "
          "The pooled T2I effect in the previous table is -0.03, which is these two "
          "groups cancelling: all three complete OpenAI CLIP checkpoints gain in T2I, "
          "and all seven checkpoints from other pretraining pipelines lose. The split is "
          "descriptive. With three models against seven, and pretraining data, objective, "
          "tokenizer and training recipe covarying, it does not identify which property "
          "of these checkpoints TCR transfers to."
          + (f" Truncated and excluded: {', '.join(tcr_skipped)}." if tcr_skipped else ""),
     tex_label="tcr_permodel", tex_caption="TCR under joint corruption, per model.")

if tcr_sev:
    rows = []
    for s in sorted(tcr_sev):
        lo, hi = cci(tcr_sev[s])
        _v = [x for _, x in tcr_sev[s]]
        fr = np.mean(tcr_frac[s]) * 100 if tcr_frac[s] else float("nan")
        rows.append([s, f"{np.mean(_v):+.2f}", f"[{lo:+.2f}, {hi:+.2f}]",
                     f"{fr:.1f}%", f"{len(_v):,}"])
    emit("Table 16 — TCR joint-corruption gain by severity (I2T)",
         ["Severity", "dR@1", "95% CI", "% of damage recovered", "n"], rows,
         note="Absolute gain grows as conditions worsen; the fraction of damage recovered "
              "falls. Both are reported because the direction of the trend depends on "
              "which is used, and prior work does not state which it reports.",
         tex_label="tcrsev", tex_caption="TCR gain by severity.")

# ═══════════════════════════════════════════════════════════════════════════
# T10b  Fractional recovery — the beat-5 convergence result
# ═══════════════════════════════════════════════════════════════════════════
def _frac_by_sev(files, methods):
    """gain as a fraction of the damage being repaired, per severity."""
    res = collections.defaultdict(lambda: collections.defaultdict(list))
    for f in files:
        R = list(csv.DictReader(open(f)))
        if len(R) < 200:
            continue
        R = [r for r in R if r.get("dataset", "coco") == "coco"]   # see TTA table above
        cl, cell = {}, collections.defaultdict(dict)
        for r in R:
            k = (r["model"].strip(), r["corruption_type"], r["severity"], r["direction"])
            cell[k][r["TTA_method"].strip()] = float(r["R@1"])
            if r["corruption_type"] == "clean" and r["TTA_method"].strip() == "none":
                cl[(r["model"].strip(), r["direction"])] = float(r["R@1"])
        for k, a in cell.items():
            if "none" not in a or k[1] == "clean" or not k[2]:
                continue
            base = cl.get((k[0], k[3]))
            if base is None or base - a["none"] < 1.0:
                continue
            dmg = base - a["none"]
            for m, v in a.items():
                if m == "none" or m not in methods or abs(v - a["none"]) < 1e-9:
                    continue
                res[m][int(k[2])].append((v - a["none"]) / dmg)
    return res


_tta_f = _frac_by_sev(glob.glob(os.path.join(ROOT, "records", "0[23]_*", "*.csv")),
                      {"TTA-Aug"})
_tcr_f = _frac_by_sev(glob.glob(os.path.join(TCRD, "*.csv")), {"TCR"})
_tta_f.update(_tcr_f)
SCOPE_F = {"TENT": "LayerNorm affines", "TTA-Aug": "none (augment + average)",
           "TCR": "LayerNorm affines (query tower)"}
rows = []
for m in ("TTA-Aug", "TCR"):
    if m not in _tta_f:
        continue
    r = [DISPLAY_NAME.get(m, m), SCOPE_F[m]]
    for s in (1, 3, 5):
        v = _tta_f[m][s]
        r.append(f"{np.mean(v) * 100:.1f}%" if v else "--")
    r.append(f"{sum(len(_tta_f[m][s]) for s in (1, 3, 5)):,}")
    rows.append(r)
emit("Table 17 — Fraction of corruption damage recovered, by severity",
     ["Method", "Adapts", "severity 1", "severity 3", "severity 5", "n"], rows,
     note="Gain divided by the damage being repaired, on jointly corrupted inputs "
          "(conditions with <1 pp damage excluded). Three independent method families "
          "converge near 48% under mild corruption and decay to 8-21% under severe. "
          "In absolute percentage points the trend reverses, because more damage is "
          "available to recover at high severity; we report both and treat fractional "
          "recovery as the deployment-relevant quantity.",
     tex_label="fracrec", tex_caption="Fraction of damage recovered.")

# ═══════════════════════════════════════════════════════════════════════════
# T11 Restoration
# ═══════════════════════════════════════════════════════════════════════════
rest = []
for f in sorted(glob.glob(os.path.join(ROOT, "records", "05_restoration", "*.csv"))):
    rest += list(csv.DictReader(open(f)))
cell = collections.defaultdict(dict)
for r in rest:
    k = (r["model"].strip(), r["corruption_type"], int(r["severity"]), r["direction"])
    cell[k][r["TTA_method"].strip()] = float(r["R@1"])
recs = []
for k, a in cell.items():
    if not {"none", "RestoreImg", "RestoreTxt", "RestoreBoth"} <= set(a):
        continue
    gi, gt, gb = a["RestoreImg"] - a["none"], a["RestoreTxt"] - a["none"], a["RestoreBoth"] - a["none"]
    recs.append({"sev": k[2], "dir": k[3], "txt": k[1].split("+")[1],
                 "key": (k[0], k[1]),
                 "gi": gi, "gt": gt, "gb": gb, "it": gb - gi - gt})
rows = []
for name, sub in ([("all", recs)] + [(f"severity {s}", [r for r in recs if r["sev"] == s])
                                     for s in (1, 3, 5)]
                  + [(t, [r for r in recs if r["txt"] == t])
                     for t in sorted({r["txt"] for r in recs})]):
    r = [name]
    # every arm gets an interval, not just the interaction: section 5.2 reports all
    # three, and "restoring the caption helps" is only a claim if its CI excludes zero
    for arm in ("gi", "gt", "gb", "it"):
        lo, hi = cci([(x["key"], x[arm]) for x in sub])
        r += [f"{np.mean([x[arm] for x in sub]):+.2f}", f"[{lo:+.2f}, {hi:+.2f}]"]
    r.append(f"{len(sub):,}")
    rows.append(r)
n_rest_models = len({r["model"].strip() for r in rest})
emit("Table 18 — Input restoration on jointly corrupted inputs",
     ["Group", "Restore image", "95% CI", "Restore text", "95% CI",
      "Restore both", "95% CI", "Interaction", "95% CI", "n"],
     rows,
     note=f"{n_rest_models} models, 12 corruption pairs, severities 1/3/5, both directions. "
          f"Interaction = gain(both) - [gain(image) + gain(text)]; it is computed within a "
          f"fixed corruption condition and so is not exposed to the corruption-suite "
          f"calibration issue. Text restoration is SymSpell: it inverts typos and nothing "
          f"else, and hurts when the corruption is not invertible.",
     tex_label="restore", tex_caption="Input restoration.")

# ═══════════════════════════════════════════════════════════════════════════
# T12 Nulls
# ═══════════════════════════════════════════════════════════════════════════
A = os.path.join(ROOT, "records", "06_screening")
nulls = []
try:
    ck = list(csv.DictReader(open(os.path.join(A, "cka_scores.csv"))))
    mm = {t["model"]: np.mean([x["mis"] for x in T if x["model"] == t["model"]]) for t in T}
    xs = [(float(r[[c for c in r if "cka" in c.lower()][0]]), mm[r["model"].strip()])
          for r in ck if r["model"].strip() in mm]
    rho, p = spearmanr([a for a, _ in xs], [b for _, b in xs])
    nulls.append(["Coupling is visible in embedding geometry", "CKA vs MIS",
                  f"rho = {rho:+.3f}", f"{p:.3f}", len(xs), "not supported"])
except Exception as e:
    print("  cka skipped:", e)
try:
    fm = list(csv.DictReader(open(os.path.join(A, "finetuned_mis.csv"))))
    vs = [float(r[[c for c in r if "mis" in c.lower()][0]]) for r in fm]
    nulls.append(["Fine-tuning objective sets coupling", "MIS across 3 objectives",
                  f"spread = {max(vs)-min(vs):.4f}", "--", len(vs), "not supported"])
except Exception as e:
    print("  finetuned skipped:", e)
try:
    im = list(csv.DictReader(open(os.path.join(A, "imagenet_mis.csv"))))
    mm = {t["model"]: np.mean([x["mis"] for x in T if x["model"] == t["model"]]) for t in T}
    xs = [(float(r[[c for c in r if "mis" in c.lower()][0]]), mm[r["model"].strip()])
          for r in im if r["model"].strip() in mm]
    rho, p = spearmanr([a for a, _ in xs], [b for _, b in xs])
    nulls.append(["Coupling transfers from classification", "ImageNet-C MIS vs retrieval MIS",
                  f"rho = {rho:+.3f}", f"{p:.3f}", len(xs), "not supported"])
except Exception as e:
    print("  imagenet skipped:", e)
if nulls:
    pass

# ═══════════════════════════════════════════════════════════════════════════
# SUPPLEMENTARY TABLES
#
# Everything below backs a supplementary section. Two of these tables exist
# because a number was already in the main paper with nothing on disk that
# reproduced it (Table 23 is main-paper Table 3; Table 22 is the threshold
# sensitivity the screening section is judged on). The rest are material that
# previously lived only in source code.
# ═══════════════════════════════════════════════════════════════════════════

# ── T22  Threshold sensitivity of the screening criteria ─────────────────────
# The screen keeps an operator when its severity-averaged fire rate exceeds 55%
# and its induced text-side damage exceeds 8 pp. Both numbers are choices. This
# sweeps them, including the no-screen setting, and reports what each choice does
# to the headline result and to the model ranking.
_fire_of = {c: fire[c] for c in ALL_TXT}
_d2_of = {c: float(np.mean([v for k, v in d2.items() if k[3] == c]))
          for c in ALL_TXT}


def _rank_vec(TT, models):
    """Mean joint drop per model, for ranking comparison across screens."""
    return [np.mean([t["d3"] for t in TT if t["model"] == m]) if
            any(t["model"] == m for t in TT) else float("nan") for m in models]


_primary_rank = _rank_vec(T, MODELS)
rows = []
for f_thr in (0, 25, 40, 55, 70):
    for d_thr in (0, 2, 5, 8, 12):
        # >=, not >: at a threshold of 0 the no-screen row must keep all twelve
        # operators, and sentence_shuffle fires at exactly 0.0%.
        keep = [c for c in ALL_TXT
                if _fire_of[c] >= f_thr and _d2_of[c] >= d_thr]
        if not keep:
            continue
        S = [t for t in T_all if t["txt"] in keep]
        if len(S) < 100:
            continue
        j = np.array([t["d3"] for t in S])
        mx = np.array([max(t["d1"], t["d2"]) for t in S])
        rho_r, _ = spearmanr(_primary_rank, _rank_vec(S, MODELS))
        dom = sum(1 for m in MODELS
                  if np.mean([t["d1"] for t in S if t["model"] == m])
                  > np.mean([t["d2"] for t in S if t["model"] == m]))
        tag = ""
        if (f_thr, d_thr) == (0, 0):
            tag = " (no screen)"
        elif (f_thr, d_thr) == (55, 8):
            tag = " (primary)"
        rows.append([f"{f_thr}%{tag}", f"{d_thr} pp", len(keep),
                     f"{np.mean(j > mx) * 100:.1f}%", f"{np.mean(j - mx):+.2f}",
                     f"{np.mean([t['d1'] for t in S]):.2f}",
                     f"{np.mean([t['d2'] for t in S]):.2f}",
                     f"{dom}/{len(MODELS)}", f"{rho_r:+.3f}", f"{len(S):,}"])
# ── Text-operator subset comparison ──────────────────────────────────────────
# The three subsets differ only in which text operators are admitted. No 0.5pp
# filter here: these are non-normalised quantities.
_SUBSETS = [("Full suite", ALL_TXT, 12), ("Execution-screened primary", EXEC_TXT, 8),
            ("High-damage challenge", CHAL_TXT, 7)]
_sub_rows = []
for name, ops, k in _SUBSETS:
    S = [t for t in T_all if t["txt"] in ops]
    j = np.array([t["d3"] for t in S]); mx = np.array([max(t["d1"], t["d2"]) for t in S])
    ae = np.array([t["d3"] - t["d1"] - t["d2"] for t in S])
    _sub_rows.append([name, k, f"{len(S):,}", f"{np.mean(j > mx) * 100:.2f}",
                 f"{np.mean(j - mx):+.2f}", f"{ae.mean():+.2f}"])
emit("Table SUB — Sensitivity to text-operator composition",
     ["Subset", "Text ops", "Complete n", "Exceed %", "Mean excess",
      "Mean additive error"], _sub_rows,
     note="The three subsets differ only in which text operators are admitted. The "
          "execution-screened primary subset requires the operator to fire on more than "
          "55% of captions; the challenge subset additionally requires more than 8 pp of "
          "text-side damage, which is a selection on the outcome and so is reported "
          "separately. No 0.5 pp filter is applied to these non-normalised quantities.",
     tex_label="subsets", tex_caption="Sensitivity to text-operator composition.")

# ── Held-out sensitivity of the challenge screen ─────────────────────────────
# The challenge subset is selected using d2, an outcome. This checks whether that
# selection is stable: choose the operators on one half of the data, then evaluate
# only on the held-out half.
def _sel_ops(pool):
    """Operators passing the challenge screen using only `pool` to measure damage."""
    return [c for c in ALL_TXT if fire[c] > 55
            and np.mean([t["d2"] for t in pool if t["txt"] == c] or [0]) > 8]


def _eval_ops(pool, ops):
    S = [t for t in pool if t["txt"] in ops]
    j = np.array([t["d3"] for t in S]); mx = np.array([max(t["d1"], t["d2"]) for t in S])
    return np.mean(j > mx) * 100, np.mean(j - mx), len(S)


_MH = sorted({t["model"] for t in T_all})
_HA, _HB = set(_MH[::2]), set(_MH[1::2])
_SPLITS = [
    ("COCO -> Flickr30K", [t for t in T_all if t["ds"] == "coco"],
     [t for t in T_all if t["ds"] == "flickr30k"]),
    ("Flickr30K -> COCO", [t for t in T_all if t["ds"] == "flickr30k"],
     [t for t in T_all if t["ds"] == "coco"]),
    ("Model half A -> half B", [t for t in T_all if t["model"] in _HA],
     [t for t in T_all if t["model"] in _HB]),
    ("Model half B -> half A", [t for t in T_all if t["model"] in _HB],
     [t for t in T_all if t["model"] in _HA]),
]
_ho_rows = []
for name, sel, ev in _SPLITS:
    ops = _sel_ops(sel)
    e, x, n = _eval_ops(ev, ops)
    _ho_rows.append([name, len(ops), f"{e:.2f}", f"{x:+.2f}", f"{n:,}"])
emit("Table HELDOUT — Held-out sensitivity of the challenge screen",
     ["Selection -> evaluation", "Ops selected", "Exceed %", "Mean excess", "n"], _ho_rows,
     note="The high-damage challenge subset is chosen using text-side damage, which is an "
          "outcome, so its composition could in principle be tuned to the data it is "
          "measured on. Here the operators are selected on one half of the data and the "
          "result is computed only on the held-out half. The subset is secondary to the "
          "execution-screened primary analysis; this table tests only whether its "
          "composition is unstable to the data used for selection.",
     tex_label="heldout", tex_caption="Held-out sensitivity of the challenge screen.")

# ── Symmetric image-side damage screen ───────────────────────────────────────
# The challenge screen applies a damage threshold to text operators only. Applying
# the same threshold to image operators tests whether the asymmetry creates the result.
_img_dmg = {c: np.mean([t["d1"] for t in T_all if t["img"] == c])
            for c in sorted({t["img"] for t in T_all})}
_IMG_KEEP = [c for c, v in _img_dmg.items() if v > 8]
_sym_rows = []
for name, ops in (("Execution-screened primary", EXEC_TXT),
                  ("High-damage challenge", CHAL_TXT)):
    S = [t for t in T_all if t["txt"] in ops and t["img"] in _IMG_KEEP]
    j = np.array([t["d3"] for t in S]); mx = np.array([max(t["d1"], t["d2"]) for t in S])
    _sym_rows.append([name, f"{len(_IMG_KEEP)}/16", f"{np.mean(j > mx) * 100:.2f}",
                 f"{np.mean(j - mx):+.2f}", f"{len(S):,}"])
emit("Table SYMM — Symmetric image-side damage screen",
     ["Text subset", "Image ops kept", "Exceed %", "Mean excess", "n"], _sym_rows,
     note="The same >8 pp marginal-damage threshold applied to the image side. The "
          "benchmark does not use this restriction, because image operators are "
          "universally executable and marginal damage is treated as difficulty rather "
          "than as an admissibility criterion. It is reported to show that the "
          "conclusion is not produced by screening damage on the text side only.",
     tex_label="symmetric", tex_caption="Symmetric image-side damage screen.")

# ── Realized-damage matching ─────────────────────────────────────────────────
# Conditions where the two marginals happen to be similar in size, which removes
# the objection that the effect is driven by one channel dominating.
_mt_rows = []
_bins = [0.5, 1, 2, 3, 5, 10]
for thr in _bins:
    S = [t for t in T if abs(t["d1"] - t["d2"]) <= thr]
    j = np.array([t["d3"] for t in S]); mx = np.array([max(t["d1"], t["d2"]) for t in S])
    ae = np.array([t["d3"] - t["d1"] - t["d2"] for t in S])
    _mt_rows.append([f"|d1 - d2| <= {thr:g} pp", f"{len(S):,}", f"{np.mean(j > mx) * 100:.2f}",
                 f"{np.mean(j - mx):+.2f}", f"{ae.mean():+.2f}"])
emit("Table MATCH — Post-hoc realized-damage matching",
     ["Matching rule", "n", "Exceed %", "Mean excess", "Mean additive error"], _mt_rows,
     note="Restricting to conditions in which the two marginals happened to inflict "
          "similar damage. This is a retrieval-damage sensitivity analysis, not a "
          "physical or perceptual calibration of corruption strength: it asks whether "
          "the result survives when neither channel dominates, not whether the two "
          "corruptions are equally severe in any absolute sense. Conditions are restricted "
          "by |d1 - d2| in Recall@1 points across progressively wider matching tolerances; "
          "the effect holds at every tolerance, and is largest where the two marginals are "
          "closest in realized damage.",
     tex_label="matched", tex_caption="Post-hoc realized-damage matching.")

# ── Additive composition across retrieval cutoffs ────────────────────────────
# Recall@1 is bounded below in a way Recall@5 and Recall@10 are not, so a
# subadditive Recall@1 result at high severity could be a top-rank floor effect
# rather than a property of joint corruption. Repeating the composition analysis
# at each cutoff separates the two.
def _deltas_at(metric):
    """Rebuild d1/d2/d3 at a given recall cutoff. Mirrors the R@1 construction."""
    cl, e1, e2, e3 = {}, {}, {}, {}
    for r in base:
        if r["corruption_type"] == "clean" and r["path"] == "1" and r.get(metric):
            cl[(r["model"].strip(), r["dataset"], r["direction"])] = float(r[metric])
    bclean = {r["direction"]: float(r[metric]) for r in bl
              if r["corruption_type"] == "clean" and r.get(metric)}
    for r in base:
        if r["corruption_type"] == "clean" or not r.get(metric):
            continue
        k0 = (r["model"].strip(), r["dataset"], r["direction"])
        if k0 not in cl:
            continue
        b = bclean.get(r["direction"], cl[k0]) if (r["model"].strip() == "blip_large"
                                                   and r["path"] == "3") else cl[k0]
        drop, sev = b - float(r[metric]), int(r["severity"])
        if r["path"] == "1":
            e1[k0 + (r["corruption_type"], sev)] = drop
        elif r["path"] == "2":
            e2[k0 + (r["corruption_type"], sev)] = drop
        elif r["path"] == "3" and "+" in r["corruption_type"]:
            a, bb = r["corruption_type"].split("+", 1)
            if not (r["model"].strip() == "blip_large" and r["dataset"] == "flickr30k"):
                e3[k0 + (a, bb, sev)] = drop
    out = []
    for k3, v3 in e3.items():
        m, ds, dr, a, bb, sv = k3
        k1, k2 = (m, ds, dr, a, sv), (m, ds, dr, bb, sv)
        if k1 in e1 and k2 in e2 and bb in EXEC_TXT:
            out.append((sv, e1[k1], e2[k2], v3))
    return out


_cut_rows = []
_CUTS = [("R@1", "R@1"), ("R@5", "R@5"), ("R@10", "R@10")]
_cut_data = {lab: _deltas_at(col) for lab, col in _CUTS}
for sv in (1, 2, 3, 4, 5):
    r = [sv]
    for lab, _ in _CUTS:
        S = [x for x in _cut_data[lab] if x[0] == sv]
        if not S:
            r += ["--", "--"]; continue
        obs = np.array([x[3] for x in S]); pred = np.array([x[1] + x[2] for x in S])
        err = obs - pred
        r2 = 1 - np.sum(err ** 2) / np.sum((obs - obs.mean()) ** 2)
        r += [f"{err.mean():+.2f}", f"{r2:.3f}"]
    _cut_rows.append(r)
emit("Table CUT — Additive composition across retrieval cutoffs",
     ["Sev", "R@1 bias", "R@1 r2", "R@5 bias", "R@5 r2", "R@10 bias", "R@10 r2"], _cut_rows,
     note="Signed additive error d3 - (d1 + d2) and condition-level r2 at each retrieval "
          "cutoff, on the execution-screened primary subset. At mild severity the two "
          "marginals reconstruct the joint condition closely at every cutoff. At severity "
          "5 the direction of the bias DIFFERS BY METRIC: Recall@1 is subadditive while "
          "Recall@10 sits mildly above the sum. The high-severity Recall@1 pattern is "
          "therefore consistent with a top-rank floor effect rather than a universal "
          "property of joint corruption, and this table is the reason the paper does not "
          "claim the latter.",
     tex_label="cutoffs", tex_caption="Additive composition across retrieval cutoffs.")

emit("Table 19 — Sensitivity of the joint-corruption result to the screening thresholds",
     ["Fire threshold", "Damage threshold", "Operators kept", "exceeds larger %",
      "mean excess pp", "mean d1", "mean d2", "models image-dominant",
      "rho vs primary ranking", "n triples"], rows,
     note="Every cell re-runs the primary analysis with a different screen. The first "
          "row is the no-screen setting (all 12 operators) and the row marked primary is "
          "the one the paper uses. The headline conclusion does not depend on the choice: "
          "exceedance stays high across the whole grid and mean excess stays positive "
          "everywhere. What the screen does change is the modality-level conclusion -- the "
          "image-dominant count moves substantially -- and that movement is driven by the "
          "DAMAGE threshold. At the 8 pp threshold the paper uses, the fire-rate criterion "
          "is not binding at all: raising it from 0% to 55% removes nothing, because every "
          "operator that rarely fires also does too little damage to clear 8 pp. It does "
          "bind at laxer damage thresholds -- at 2 pp it is what removes attribute swap, "
          "which fires on 18% of captions -- so the two criteria are not redundant in "
          "general, only at this operating point.",
     tex_label="threshold_sensitivity",
     tex_caption="Sensitivity to the screening thresholds.")

# ── T23  Dataset x retrieval direction ───────────────────────────────────────
# This is main-paper Table 3. It previously had no generator: the four cells were
# computed by hand and typed in.
rows = []
for ds, dsl in (("coco", "MS-COCO"), ("flickr30k", "Flickr30K")):
    for dr in ("I2T", "T2I"):
        S = [t for t in T if t["ds"] == ds and t["dir"] == dr]
        if not S:
            continue
        j = np.array([t["d3"] for t in S])
        mx = np.array([max(t["d1"], t["d2"]) for t in S])
        lo, hi = cci([((t["model"], t["img"], t["txt"]), t["d3"] - max(t["d1"], t["d2"]))
                      for t in S])
        rows.append([dsl, dr, f"{np.mean(j > mx) * 100:.1f}%", f"{np.mean(j - mx):+.2f}",
                     f"[{lo:+.2f}, {hi:+.2f}]",
                     f"{np.mean([t['d1'] for t in S]):.2f}",
                     f"{np.mean([t['d2'] for t in S]):.2f}",
                     f"{j.mean():.2f}", f"{len(S):,}"])
emit("Table 20 — Joint degradation resolved by dataset and retrieval direction",
     ["Dataset", "Direction", "exceeds larger %", "mean excess pp", "95% CI",
      "image only", "text only", "joint", "n"], rows,
     note="All four strata carry the same qualitative conclusion, so the pooled result is "
          "not an artefact of one dataset or one retrieval direction. The breakdown also "
          "shows that exceedance RATE and mean EXCESS do not have to move together: "
          "Flickr30K image-to-text has the lowest rate and the largest excess.",
     tex_label="strata", tex_caption="Joint degradation by dataset and retrieval direction.")

# ── T24  Checkpoint registry ─────────────────────────────────────────────────
# Parsed rather than imported: evaluate.py pulls in torch at module scope.
import ast

_REG = {}
for _n in ast.walk(ast.parse(open(os.path.join(ROOT, os.pardir, "2_evaluation", "evaluate.py")).read())):
    if isinstance(_n, ast.Assign) and getattr(_n.targets[0], "id", "") == "MODEL_REGISTRY":
        _REG = ast.literal_eval(_n.value)
        break
_LOADER = {"clip": "OpenAI CLIP", "openclip": "open_clip", "siglip": "HuggingFace",
           "blip": "HuggingFace", "blip2": "HuggingFace"}
# The architecture + tag pair identifies weights only through open_clip's pretrained
# registry, and that mapping is library-version dependent. Recording the resolved
# source pins the weights themselves, so the roster can be rebuilt exactly without
# depending on which open_clip version is installed.
_WEIGHTS = {
    "clip_vit_b32": "OpenAI CLIP ViT-B/32",
    "clip_vit_b16": "OpenAI CLIP ViT-B/16",
    "clip_vit_l14": "OpenAI CLIP ViT-L/14",
    "clip_vit_l14_336": "OpenAI CLIP ViT-L/14@336px",
    "openclip_vit_b32": "laion/CLIP-ViT-B-32-laion2B-s34B-b79K",
    "openclip_vit_b16": "timm/vit_base_patch16_clip_224.laion400m_e32",
    "openclip_vit_l14": "laion/CLIP-ViT-L-14-laion2B-s32B-b82K",
    "openclip_vit_h14": "laion/CLIP-ViT-H-14-laion2B-s32B-b79K",
    "openclip_vit_bigg14": "laion/CLIP-ViT-bigG-14-laion2B-39B-b160k",
    "siglip_vit_b16": "google/siglip-base-patch16-224",
    "siglip_vit_l16": "google/siglip-large-patch16-256",
    "siglip_so400m": "google/siglip-so400m-patch14-384",
    "evaclip_vit_b16": "timm/eva02_base_patch16_clip_224.merged2b_s8b_b131k",
    "evaclip_vit_l14": "timm/eva02_large_patch14_clip_224.merged2b_s4b_b131k",
    "metaclip_vit_b16": "timm/vit_base_patch16_clip_224.metaclip_2pt5b",
    "metaclip_vit_l14": "timm/vit_large_patch14_clip_224.metaclip_2pt5b",
    "dfn_vit_h14": "apple/DFN5B-CLIP-ViT-H-14",
    "coca_vit_l": "laion/mscoco_finetuned_CoCa-ViT-L-14-laion2B-s13B-b90k",
    "blip_large": "Salesforce/blip-itm-large-coco",
}
rows = []
for fam, ms in FAM_ORDER:
    for mo in ms:
        c = _REG.get(mo, {})
        rows.append([fam, mo, c.get("name", "--"), c.get("pretrained", "--"),
                     _WEIGHTS.get(mo, "--"),
                     _LOADER.get(c.get("family", ""), "--"), PARAMS.get(mo, "--")])
emit("Table 21 — Model checkpoints",
     ["Family", "Model key", "Architecture / HF id", "Pretrained tag", "Weights",
      "Loader", "Params (M)"], rows,
     note="The exact checkpoint behind every row of the model tables, taken from "
          "MODEL_REGISTRY in evaluate.py so it cannot drift from what was run. 'Family' "
          "is the reporting family; 'Loader' is the library that instantiated the "
          "checkpoint, which is not the same thing -- EVA-CLIP, MetaCLIP, DFN and CoCa are "
          "all loaded through open_clip. blip2 appears in the registry but is not part of "
          "the evaluated roster, and its records are excluded from every analysis. "
          "Both MetaCLIP checkpoints carry the metaclip_fullcc tag, so within MetaCLIP the "
          "pretraining corpus is held fixed across scales; the one family whose corpus "
          "changes with scale is OpenCLIP, whose B/16 checkpoint is laion400m_e32 while "
          "the other four are LAION-2B. This matches the description in section 3.3.",
     tex_label="checkpoints", tex_caption="Model checkpoints.")

# ── T25/T26  Corruption catalogues and severity schedules ────────────────────
_IMG_FAM = {"gaussian_noise": "noise", "shot_noise": "noise", "impulse_noise": "noise",
            "speckle_noise": "noise", "defocus_blur": "blur", "glass_blur": "blur",
            "motion_blur": "blur", "zoom_blur": "blur", "snow": "weather",
            "frost": "weather", "fog": "weather", "brightness": "weather",
            "contrast": "digital", "elastic_transform": "digital",
            "pixelate": "digital", "jpeg_compression": "digital"}
rows = [[_IMG_FAM.get(c, "--"), c,
         "extended" if c == "speckle_noise" else "standard",
         f"{np.mean([v for k, v in d1.items() if k[3] == c]):.2f}"]
        for c in sorted(img_types, key=lambda x: (_IMG_FAM.get(x, ""), x))]
emit("Table 22 — Image corruption operators",
     ["Family", "Operator", "ImageNet-C set", "mean d1 pp"], rows,
     note="Sixteen operators at five severity levels, generated with the imagecorruptions "
          "package at a fixed seed and written to disk before evaluation, so every model "
          "sees byte-identical inputs. Fifteen are the standard ImageNet-C corruptions; "
          "speckle noise comes from the extended set. Severity parameterisation is the "
          "package default for all sixteen. Unlike the text operators, all sixteen are "
          "universally applicable, so no screening step applies on the image side.",
     tex_label="img_ops", tex_caption="Image corruption operators.")

_SCHED = {
    "keyboard_typo": ("characters", [1, 3, 5, 7, 10]),
    "ocr_error": ("characters", [1, 3, 5, 7, 10]),
    "char_swap": ("characters", [1, 3, 5, 7, 10]),
    "char_delete": ("characters", [1, 3, 5, 7, 10]),
    "word_delete": ("tokens", [5, 10, 20, 30, 40]),
    "punctuation_noise": ("punctuation", [5, 10, 20, 30, 40]),
    "word_shuffle": ("tokens", [10, 20, 35, 50, 60]),
    "negation_insertion": ("eligible tokens", [10, 25, 40, 60, 80]),
    "attribute_swap": ("eligible tokens", [10, 25, 40, 60, 80]),
    "relation_swap": ("eligible tokens", [10, 25, 40, 60, 80]),
    "object_substitution": ("eligible tokens", [10, 25, 40, 60, 80]),
    "sentence_shuffle": ("sentences", [20, 35, 50, 65, 80]),
}
_REQUIRES = {
    "keyboard_typo": "characters", "ocr_error": "characters", "char_swap": "characters",
    "char_delete": "characters", "word_delete": "2+ tokens",
    "word_shuffle": "2+ tokens", "punctuation_noise": "terminal punctuation",
    "negation_insertion": "a verb or copula", "attribute_swap": "2+ adjectives",
    "relation_swap": "a spatial preposition", "object_substitution": "a noun",
    "sentence_shuffle": "2+ sentences",
}
rows = []
for c in ALL_TXT:
    unit, sch = _SCHED[c]
    rows.append([c, "surface" if c in ("keyboard_typo", "ocr_error", "char_swap",
                                       "char_delete", "word_delete", "word_shuffle",
                                       "punctuation_noise") else "semantic",
                 _REQUIRES[c], unit, " / ".join(f"{x}%" for x in sch),
                 "kept" if c in STRONG_TXT else "screened out"])
emit("Table 23 — Text perturbation operators and severity schedules",
     ["Operator", "Class", "Requires", "Rate applies to", "Severity 1 / 2 / 3 / 4 / 5",
      "Screen"], rows,
     note="Rates are read from text_corruptions/surface_corruptions.py and "
          "semantic_corruptions.py, so the table cannot drift from the implementation. "
          "Two properties of these operators matter when reading the severity figures. "
          "Corruption is NOT cumulative: each severity is an independent draw at a higher "
          "rate, not the previous severity plus more damage. And a higher rate does not "
          "always change the output -- on a short caption, 7% and 10% of the characters can "
          "select the same positions, so keyboard_typo can return identical strings at "
          "severities 4 and 5. char_swap gives a monotone progression and is the better "
          "choice for any figure showing a severity ladder.",
     tex_label="txt_ops", tex_caption="Text perturbation operators and severity schedules.")

# ── T27  Fire rate resolved by severity ──────────────────────────────────────
# The screen uses a severity-averaged fire rate; this is the curve underneath it.
rows = []
for c in ALL_TXT:
    r = [c]
    for s in range(1, 6):
        rs = [x for x in VAL if x["corruption_type"] == c and int(x["severity"]) == s]
        r.append(f"{sum(x['corrupted'].strip() != x['original'].strip() for x in rs) / len(rs) * 100:.1f}"
                 if rs else "--")
    r += [f"{fire[c]:.1f}", f"{ELIG.get(c, 100.0):.1f}"]
    rows.append(r)
emit("Table 24 — Fire rate by operator and severity",
     ["Operator", "sev 1", "sev 2", "sev 3", "sev 4", "sev 5", "mean", "eligible %"], rows,
     note="Fraction of 500 captions per operator per severity that the operator actually "
          "modified. This separates the two failure modes the mean conceals. Rate-limited "
          "operators climb steeply -- they fail at severity 1 only because 1% of a short "
          "caption rounds to no characters -- and reach 90-100% by severity 5. "
          "Structure-limited operators are flat: they plateau at their eligibility ceiling "
          "and no severity setting can lift them past it, because the syntax they need is "
          "absent from the caption rather than merely undersampled.",
     tex_label="firerate", tex_caption="Fire rate by operator and severity.")

# ── T28  Clean-baseline robustness check ─────────────────────────────────────
# Section 3.5 quotes these four numbers. They were computed inside audit_claims.py
# and never emitted; recomputed here so they land in tables/ with everything else.
_c1, _c3l = {}, {}
for r in raw:
    if r["TTA_method"] != "none" or r["corruption_type"] != "clean":
        continue
    k = (r["model"].strip(), r["dataset"], r["direction"])
    if r["path"] == "1":
        _c1[k] = float(r["R@1"])
    elif r["path"] == "3":
        _c3l.setdefault(k, []).append(float(r["R@1"]))
_c3 = {k: (min(v, key=lambda x: abs(x - _c1[k])) if k in _c1 else np.mean(v))
       for k, v in _c3l.items()}
_pub = np.array([t["d3"] - max(t["d1"], t["d2"]) for t in T])
_alt = np.array([t["d3"] + ((_c3[k] - _c1[k])
                            if ((k := (t["model"], t["ds"], t["dir"])) in _c3
                                and t["model"] != "blip_large") else 0.0)
                 - max(t["d1"], t["d2"]) for t in T])
emit("Table 25 — Clean-baseline robustness check",
     ["Baseline", "exceeds larger %", "mean excess pp", "rounds to", "n"],
     [["shared path-1 clean (used in the paper)", f"{100 * (_pub > 0).mean():.4f}%",
       f"{_pub.mean():.4f}", "96% / 5.6", f"{len(_pub):,}"],
      ["each run's own clean rows", f"{100 * (_alt > 0).mean():.4f}%",
       f"{_alt.mean():.4f}", "96% / 5.6", f"{len(_alt):,}"]],
     note="Joint effects are normally measured against the clean baseline recorded on "
          "path 1. This recomputes every one of them against the clean rows recorded in "
          "the same run that produced the joint measurement, which removes any drift "
          "between runs at the cost of a noisier baseline. Both report as 96% and 5.6, so "
          "the headline result does not depend on the choice. blip_large is excluded from "
          "the alternate arm because its path-3 rows come from a separate file that is "
          "already baselined against its own clean rows, so the correction would be "
          "applied twice.",
     tex_label="baseline_check", tex_caption="Clean-baseline robustness check.")

# ── T29  Experiment coverage ─────────────────────────────────────────────────
# Every coverage caveat in the paper, in one checkable place.
_tcr_n = len({m for m in _tcr_pm})
rows = [
    ["Main joint-corruption analysis", "19", "COCO + Flickr30K", "I2T + T2I", "1-5",
     "16 x 7 screened", f"{len(T):,} triples"],
    ["All-12 operator comparison", "19", "COCO + Flickr30K", "I2T + T2I", "1-5",
     "16 x 12", f"{len(T_all):,} triples"],
    ["Adaptation: QueryExpansion, Tandem-Aug, FeatureWhitening", f"{n_tta_models}", "COCO",
     "I2T + T2I", "1-5", "16 x 7", "7/7 models adapted"],
    ["Adaptation: Tandem-Align", f"{n_tta_models}", "COCO", "I2T + T2I", "1-5", "16 x 7",
     "5/7 models adapted"],
    ["Adaptation: TENT, MEMO, TPT, DiffTPT", "1", "COCO", "I2T + T2I", "1-5", "16 x 7",
     "evaclip_vitl14 only"],
    ["TCR", f"{_tcr_n}", "COCO", "I2T + T2I", "1-5", "12 pairs",
     "query / gallery / joint regimes"],
    ["Input restoration", f"{n_rest_models}", "COCO", "I2T + T2I", "1 / 3 / 5",
     "12 pairs", "360 conditions"],
]
emit("Table 26 — Adaptation and restoration implementation details",
     ["Method", "Updates", "Hyperparameters", "Source"],
     [["Tandem-Aug (internal ID: TTA-Aug)", "nothing",
       "k=8 augmented views plus the original; RandomHorizontalFlip, "
       "RandomResizedCrop(224, scale 0.7-1.0), ColorJitter(0.2/0.2/0.1/0.05). Each view "
       "L2-normalised, the 9 averaged, the average re-normalised. Text features untouched.",
       "evaluate/tta.py:80"],
      ["TENT [25]", "LayerNorm affine parameters",
       "Adam, lr 1e-3, 3 steps, batch 64, entropy minimisation", "evaluate/tta.py:140"],
      ["MEMO [30]", "all parameters, per image",
       "k=8 views, Adam, lr 1e-4, 3 steps, marginal-entropy objective",
       "evaluate/tta.py:224"],
      ["TPT [22]", "prompt embeddings only",
       "k=8 views, Adam, lr 5e-3, 3 steps, confidence selection on the lowest-entropy "
       "10% of views", "evaluate/tta.py:304"],
      ["DiffTPT [7]", "prompt embeddings only",
       "as TPT but strong augmentation: RandomResizedCrop(scale 0.5-1.0), "
       "ColorJitter(0.4/0.4/0.2/0.1), RandomGrayscale(p=0.1), GaussianBlur(k=3)",
       "evaluate/tta.py:369"],
      ["Tandem-Align (internal ID: PromptAlign)", "nothing (closed form)",
       "text features shifted and scaled to match the image feature mean and standard "
       "deviation, then re-normalised. No prompt optimization or parameter updates are "
       "performed. CLIP-family checkpoints only; falls back to no adaptation elsewhere, "
       "which is why coverage is 5/7.", "evaluate/tta.py:426"],
      ["FeatureWhitening [10]", "nothing (closed form)",
       "ZCA whitening of the gallery features, eigenvalues clamped at eps=1e-5",
       "evaluate/tta.py:453"],
      ["QueryExpansion [6]", "nothing (closed form)",
       "top_k=10 neighbours, refined query = 0.5 x query + 0.5 x neighbour mean",
       "evaluate/tta.py:487"],
      ["TCR [15]", "LayerNorm affines on the query tower",
       "the authors' released parameter scope and defaults, run unmodified from the "
       "vendored copy", "external_suites/tcr/"],
      ["RestoreImg", "nothing (input-side)",
       "classical per-corruption restorers: non-local means for gaussian noise, unsharp "
       "masking for motion blur, dark-channel-prior dehazing for fog, edge-preserving "
       "smoothing for JPEG artifacts. Restored images cached to disk and shared across "
       "models.", "restoration_bench/restore.py:62"],
      ["RestoreTxt", "nothing (input-side)",
       "SymSpell compound correction, max edit distance 2, prefix length 7. Inverts "
       "surface typos; semantic corruptions pass through unchanged, which is why the "
       "arm loses accuracy on object substitution and word deletion.",
       "restoration_bench/restore.py:124"]],
     note="Every method was run at the settings above on every model in its coverage row "
          "of the previous table. The three closed-form methods and TTA-Aug perform no "
          "parameter updates at all, so their cost is a fixed multiple of a forward pass; "
          "the four gradient methods do, which is why they were run on a single "
          "checkpoint. The image restorers are deliberately classical rather than "
          "learned: they establish how much of the joint-corruption loss is recoverable "
          "by off-the-shelf preprocessing before any restoration model is trained.",
     tex_label="impl", tex_caption="Adaptation and restoration implementation details.")

# ── Controlled single-backbone adaptation comparison ─────────────────────────
# The pooled adaptation table mixes methods run on seven checkpoints with methods
# run on one, so it is not a like-for-like ranking. Every method did run on
# evaclip_vitl14, so restricting to that backbone gives all eight methods the same
# model, the same COCO joint conditions and the same screened operator set.
_CTRL = "evaclip_vitl14"
_ctrl = collections.defaultdict(list)
for f in glob.glob(os.path.join(ROOT, "records", "0[23]_*", "*.csv")):
    R = [r for r in csv.DictReader(open(f)) if r.get("dataset", "coco") == "coco"]
    cell = collections.defaultdict(dict)
    for r in R:
        cell[(r["model"].strip(), r["corruption_type"], r["severity"],
              r["direction"])][r["TTA_method"].strip()] = float(r["R@1"])
    for k, a in cell.items():
        if "none" not in a or k[0] != _CTRL:
            continue
        for meth, v in a.items():
            if meth != "none" and abs(v - a["none"]) > 1e-9:
                _ctrl[(meth, k[3])].append(((k[1],), v - a["none"]))
_ctrl_rows = []
for meth in sorted(SCOPE, key=lambda m: -(np.mean([x for _, x in _ctrl[(m, "I2T")]])
                                          if _ctrl[(m, "I2T")] else -99)):
    ki, kt = _ctrl[(meth, "I2T")], _ctrl[(meth, "T2I")]
    if not (ki and kt):
        continue
    i = [x for _, x in ki]; t = [x for _, x in kt]
    li, hi_ = cci(ki); lt, ht = cci(kt)
    both = "yes" if np.mean(i) > 0 and np.mean(t) > 0 else "no"
    _ctrl_rows.append([DISPLAY_NAME.get(meth, meth), SCOPE[meth], f"{np.mean(i):+.2f}", f"[{li:+.2f}, {hi_:+.2f}]",
                       f"{np.mean(t):+.2f}", f"[{lt:+.2f}, {ht:+.2f}]", both, f"{len(i):,}"])
emit("Table 27 — Adaptation on a single backbone (EVA-CLIP ViT-L/14)",
     ["Method", "What it adapts", "I2T dR@1", "95% CI", "T2I dR@1", "95% CI",
      "helps both", "n"], _ctrl_rows,
     note="All eight methods on one checkpoint, so model coverage is held fixed and the "
          "comparison is like-for-like -- unlike the pooled table, which mixes methods run "
          "on seven checkpoints with methods run on one and is therefore not a ranking. "
          "The ordering by adaptation scope is unchanged and sharper: methods that rewrite "
          "the shared representation fail worst, methods that leave it alone help. Only "
          "TENT and TTA-Aug improve BOTH retrieval directions. QueryExpansion gains in "
          "image-to-text and loses heavily in text-to-image, the same asymmetry the pooled "
          "table shows.",
     tex_label="tta_controlled",
     tex_caption="Adaptation on a single backbone (EVA-CLIP ViT-L/14).")

emit("Table 28 — Experiment coverage",
     ["Experiment", "Models", "Datasets", "Directions", "Severities", "Operators",
      "Note"], rows,
     note="Coverage differs by experiment and the differences are not incidental: the "
          "adaptation rows in particular are NOT mutually comparable, because four of the "
          "eight methods ran on a single checkpoint. Effects should be read within a "
          "method and against that method's own control, never across rows. Only the "
          "first two rows cover the full roster and both datasets.",
     tex_label="coverage", tex_caption="Experiment coverage.")

# ═══════════════════════════════════════════════════════════════════════════
with open(os.path.join(OUT, "paper_tables.md"), "w") as f:
    f.write("\n".join(MD) + "\n")
with open(os.path.join(OUT, "paper_tables.tex"), "w") as f:
    f.write("\n".join(TEX) + "\n")
print(f"\n\n-> {OUT}/paper_tables.md")
print(f"-> {OUT}/paper_tables.tex")
print(f"-> {OUT}/*.csv  (one per table)")
