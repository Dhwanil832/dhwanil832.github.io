"""Independent audit: every number claimed in the paper, checked against the tables.

Nothing here reads the prose automatically. Each expectation is transcribed by hand
from the submitted PDFs (TandemBench_WACV_977 and its supplementary material) and
compared with what the generator produces, so a mismatch means the paper and the
data have diverged. Values that sit in no table are recomputed from the triples.

Expectations follow the revised analysis policy:
  * the PRIMARY subset is execution-screened (fire rate > 55%), eight operators
  * the 0.5 pp combined-damage safeguard applies ONLY to normalised ratio analyses
  * the seven-operator high-damage set is a secondary "challenge" subset

    python analysis/audit_claims.py

Exits non-zero if any check fails.
"""
import contextlib
import csv
import io
import os
import runpy
import sys

import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
T_DIR = os.path.join(ROOT, "tables")

_buf = io.StringIO()
with contextlib.redirect_stdout(_buf):
    G = runpy.run_path(os.path.join(ROOT, "paper_tables.py"))
T, T_all, T_CHAL = G["T"], G["T_all"], G["T_CHAL"]

PASS = FAIL = 0


def tbl(name):
    with open(os.path.join(T_DIR, name)) as fh:
        return list(csv.DictReader(fh))


def raw(name):
    with open(os.path.join(T_DIR, name)) as fh:
        return list(csv.reader(fh))


def sect(s):
    print(f"\n{'=' * 78}\n{s}\n{'=' * 78}")


def num(x):
    return float(str(x).replace("%", "").replace("+", "").replace("x", "")
                 .replace(",", "").replace("−", "-").strip())


def chk(label, claimed, actual, tol=0.005):
    """Compare a claimed value with the generated one. Strings must match exactly."""
    global PASS, FAIL
    if isinstance(claimed, str):
        ok = str(actual).strip() == claimed.strip()
        shown = f"{actual}"
    else:
        a = num(actual)
        ok = abs(a - claimed) <= tol
        shown = f"{a:g}"
    if ok:
        PASS += 1
        print(f"  ok    {label:52} {shown}")
    else:
        FAIL += 1
        print(f"  FAIL  {label:52} claimed {claimed}  actual {shown}")


# ── 1. benchmark composition ─────────────────────────────────────────────────
sect("1. Benchmark composition and record counts")
comp = {r["Component"]: r["Count"] for r in tbl("composition.csv")}
for label, key, claimed in [
        ("COCO val2017 gallery images", "COCO val2017 gallery images", 5000),
        ("COCO val2017 captions", "COCO val2017 captions", 25014),
        ("Flickr30k gallery images", "Flickr30k test gallery images", 1000),
        ("Flickr30k captions", "Flickr30k test captions", 5000),
        ("total evaluation records", "Total evaluation rows", 83754),
        ("path 1 (image corrupted)", "Path 1 rows (image corrupted)", 6156),
        ("path 2 (text corrupted)", "Path 2 rows (text corrupted)", 4560),
        ("path 3 (jointly corrupted)", "Path 3 rows (jointly corrupted)", 73038),
        ("models", "Models", 19),
        ("image operators", "Image corruption types", 16),
        ("text operators", "Text corruption types", 12)]:
    chk(label, claimed, comp[key])

# Matched-condition accounting, supplement Table S4.
sect("2. Matched-condition accounting (supp. Table S4)")
SUB = {r["Subset"]: r for r in tbl("subsets.csv")}
for name, ops, complete in [("Full suite", 12, 71040),
                            ("Execution-screened primary", 8, 47360),
                            ("High-damage challenge", 7, 41440)]:
    chk(f"{name}: operators", ops, SUB[name]["Text ops"])
    chk(f"{name}: complete triples", complete, SUB[name]["Complete n"], tol=1)
# the floored counts, which only the ratio analyses use
chk("full suite after 0.5pp floor", 69435, len([t for t in T_all if t["floor_ok"]]), tol=1)
chk("primary after 0.5pp floor", 46949, len([t for t in T if t["floor_ok"]]), tol=1)
chk("challenge after 0.5pp floor", 41264, len([t for t in T_CHAL if t["floor_ok"]]), tol=1)

# ── 3. screening ─────────────────────────────────────────────────────────────
sect("3. Text-perturbation screening")
V = {r["Operator"]: r for r in tbl("screening.csv")}
CLAIM = {  # operator: (fires, fires@5, eligible, d2)
    "word_shuffle":        (99.6, 100.0, 100.0, 8.82),
    "word_delete":         (75.0, 99.0, 100.0, 11.69),
    "char_delete":         (74.4, 98.0, 100.0, 11.68),
    "char_swap":           (74.0, 98.0, 100.0, 14.55),
    "object_substitution": (70.6, 98.0, 100.0, 12.57),
    "keyboard_typo":       (69.8, 97.0, 100.0, 12.01),
    "ocr_error":           (59.8, 90.0, 100.0, 8.67),
    "punctuation_noise":   (56.0, 90.0, 100.0, 1.25),
    "relation_swap":       (25.6, 41.0, 53.4, 0.32),
    "attribute_swap":      (18.2, 30.0, 50.9, 3.89),
    "negation_insertion":  (4.0, 9.0, 41.3, 0.65),
    "sentence_shuffle":    (0.0, 0.0, 5.2, 0.26),
}
for op, (f, f5, el, d2) in CLAIM.items():
    r = V[op]
    chk(f"{op} fires %", f, r["Fires %"])
    chk(f"{op} fires @ sev 5", f5, r["Fires % @ sev 5"])
    chk(f"{op} eligible %", el, r["Eligible %"].replace("*", ""))
    chk(f"{op} d2 pp", d2, r["d2 pp"])
# The execution screen is fire rate only. punctuation_noise must be IN it despite
# doing almost nothing -- that separation is the point of the section.
chk("operators passing the execution screen", 8, len(G["EXEC_TXT"]))
chk("punctuation_noise is execution-screened in", "yes",
    "yes" if "punctuation_noise" in G["EXEC_TXT"] else "no")
chk("punctuation_noise is NOT in the challenge set", "yes",
    "yes" if "punctuation_noise" not in G["CHAL_TXT"] else "no")
chk("operators in the challenge set", 7, len(G["CHAL_TXT"]))

# caption-length control
E = {r["Operator"]: r for r in tbl("eligctl.csv")}
for op, e1, e5 in [("sentence_shuffle", 0.2, 100.0), ("negation_insertion", 35.9, 93.4),
                   ("attribute_swap", 52.3, 93.9), ("relation_swap", 54.5, 90.7)]:
    chk(f"{op} eligible, 1 caption", e1, E[op]["Eligible, 1 caption %"])
    chk(f"{op} eligible, 5 concatenated", e5, E[op]["Eligible, 5 concatenated %"])

# ── 4. main joint-corruption result ──────────────────────────────────────────
sect("4. Main joint result (execution-screened primary)")
A = {r["Group"]: r for r in tbl("amplification.csv")}
chk("exceedance, all severities", 95.15, A["all severities"]["joint > larger channel"],
    tol=0.05)
chk("mean excess, all severities", 5.07, A["all severities"]["mean excess (pp)"])
chk("n, all severities", 47360, A["all severities"]["n"], tol=1)
for s, exc, exs in [(1, 88.6, 1.34), (2, 92.7, 2.79), (3, 96.6, 4.95),
                    (4, 98.5, 7.07), (5, 99.3, 9.18)]:
    chk(f"severity {s} exceedance", exc, A[f"severity {s}"]["joint > larger channel"],
        tol=0.05)
    chk(f"severity {s} mean excess", exs, A[f"severity {s}"]["mean excess (pp)"])

# subset comparison, supplement Table S9
for name, exc, exs, ae in [("Full suite", 91.84, 3.79, -0.62),
                           ("Execution-screened primary", 95.15, 5.07, -0.99),
                           ("High-damage challenge", 96.15, 5.63, -1.13)]:
    chk(f"{name}: exceed %", exc, SUB[name]["Exceed %"])
    chk(f"{name}: mean excess", exs, SUB[name]["Mean excess"])
    chk(f"{name}: mean additive error", ae, SUB[name]["Mean additive error"])

# dataset x direction, main paper Table 3
sect("5. Dataset x retrieval direction")
ST = {(r["Dataset"], r["Direction"]): r for r in tbl("strata.csv")}
for ds, dr, exc, exs in [("MS-COCO", "I2T", 96.49, 5.48), ("MS-COCO", "T2I", 96.04, 3.12),
                         ("Flickr30K", "I2T", 91.27, 6.44), ("Flickr30K", "T2I", 96.69, 5.31)]:
    chk(f"{ds} {dr} exceedance", exc, ST[(ds, dr)]["exceeds larger %"], tol=0.05)
    chk(f"{ds} {dr} mean excess", exs, ST[(ds, dr)]["mean excess pp"])
_e = [num(r["exceeds larger %"]) for r in tbl("strata.csv")]
_x = [num(r["mean excess pp"]) for r in tbl("strata.csv")]
chk("strata exceedance range, min", 91.27, min(_e), tol=0.05)
chk("strata exceedance range, max", 96.69, max(_e), tol=0.05)
chk("strata mean excess, min", 3.12, min(_x))
chk("strata mean excess, max", 6.44, max(_x))

# ── 6. screen sensitivity ────────────────────────────────────────────────────
sect("6. Screen sensitivity")
HO = {r["Selection -> evaluation"]: r for r in tbl("heldout.csv")}
for k, exc, exs in [("COCO -> Flickr30K", 95.29, 6.52), ("Flickr30K -> COCO", 96.95, 4.77),
                    ("Model half A -> half B", 96.02, 5.84),
                    ("Model half B -> half A", 96.26, 5.42)]:
    chk(f"held-out {k}: exceed %", exc, HO[k]["Exceed %"])
    chk(f"held-out {k}: mean excess", exs, HO[k]["Mean excess"])
    chk(f"held-out {k}: ops selected", 7, HO[k]["Ops selected"])

SY = {r["Text subset"]: r for r in tbl("symmetric.csv")}
chk("symmetric screen keeps image ops", "10/16", SY["Execution-screened primary"]["Image ops kept"])
chk("symmetric, primary: exceed %", 97.46, SY["Execution-screened primary"]["Exceed %"])
chk("symmetric, primary: mean excess", 6.23, SY["Execution-screened primary"]["Mean excess"])
chk("symmetric, challenge: exceed %", 98.60, SY["High-damage challenge"]["Exceed %"])
chk("symmetric, challenge: mean excess", 6.95, SY["High-damage challenge"]["Mean excess"])

MT = {r["Matching rule"]: r for r in tbl("matched.csv")}
# Table S15 reports tolerance bands only; the binning row was withdrawn.
chk("matched-table rows", 6, len(MT))
for rule, n, exc, exs, ae in [
        ("|d1 - d2| <= 0.5 pp", 3229, 96.97, 4.61, -0.18),
        ("|d1 - d2| <= 1 pp", 6302, 96.45, 4.55, -0.21),
        ("|d1 - d2| <= 2 pp", 11855, 95.39, 4.44, -0.26),
        ("|d1 - d2| <= 3 pp", 16370, 94.47, 4.51, -0.34),
        ("|d1 - d2| <= 5 pp", 23261, 94.23, 4.79, -0.48),
        ("|d1 - d2| <= 10 pp", 35014, 94.77, 5.04, -0.69)]:
    chk(f"matched {rule}: n", n, MT[rule]["n"], tol=1)
    chk(f"matched {rule}: exceed %", exc, MT[rule]["Exceed %"], tol=0.01)
    chk(f"matched {rule}: mean excess", exs, MT[rule]["Mean excess"])
    chk(f"matched {rule}: additive error", ae, MT[rule]["Mean additive error"])

# threshold grid
TS = tbl("threshold_sensitivity.csv")
_exc = [num(r["exceeds larger %"]) for r in TS]
chk("threshold grid rows", 25, len(TS))
chk("every grid cell positive excess", "yes",
    "yes" if all(num(r["mean excess pp"]) > 0 for r in TS) else "NO")
chk("grid exceedance stays high", "yes", "yes" if min(_exc) > 90 else "NO")

# ── 7. additive composition ──────────────────────────────────────────────────
sect("7. Additive composition")
CU = {int(r["Sev"]): r for r in tbl("cutoffs.csv")}
for s, b1, r1, b5, r5, b10, r10 in [
        (1, +0.15, 0.968, +0.10, 0.980, +0.12, 0.980),
        (2, +0.03, 0.970, +0.25, 0.980, +0.33, 0.982),
        (3, -0.28, 0.948, +0.52, 0.969, +0.67, 0.973),
        (4, -1.38, 0.887, +0.52, 0.950, +1.06, 0.956),
        (5, -3.46, 0.759, +0.11, 0.895, +1.34, 0.918)]:
    chk(f"sev {s} R@1 bias", b1, CU[s]["R@1 bias"])
    chk(f"sev {s} R@1 r2", r1, CU[s]["R@1 r2"])
    chk(f"sev {s} R@5 bias", b5, CU[s]["R@5 bias"])
    chk(f"sev {s} R@10 bias", b10, CU[s]["R@10 bias"])
    chk(f"sev {s} R@10 r2", r10, CU[s]["R@10 r2"])
# The load-bearing claim: the sign of the bias differs by cutoff at severity 5,
# which is why the paper reads it as a top-rank floor effect.
chk("severity 5 R@1 is subadditive", "yes",
    "yes" if num(CU[5]["R@1 bias"]) < 0 else "NO")
chk("severity 5 R@10 is superadditive", "yes",
    "yes" if num(CU[5]["R@10 bias"]) > 0 else "NO")

# ── 8. estimator bias ────────────────────────────────────────────────────────
sect("8. Estimator bias")
EB = {r[0]: r for r in raw("estimator_bias.csv")[1:]}
chk("strongest bias correlation", -0.951, EB["absolute interaction"][4])
chk("ratio-to-sum, ratio of means", -0.951, EB["ratio to sum"][4])
chk("larger-marginal, mean of ratios", 0.434, EB["ratio to larger channel"][2])
chk("larger-marginal, ratio of means", 0.622, EB["ratio to larger channel"][4])
chk("larger-marginal p, mean of ratios", 0.159, EB["ratio to larger channel"][3], tol=0.001)
chk("larger-marginal p, ratio of means", 0.031, EB["ratio to larger channel"][5], tol=0.001)
chk("the two aggregations disagree", "NO", EB["ratio to larger channel"][6])

# ── 9. adaptation ────────────────────────────────────────────────────────────
sect("9. Adaptation")
CT = {r["Method"]: r for r in tbl("tta_controlled.csv")}
chk("controlled-backbone methods", 8, len(CT))
chk("methods helping both directions", "TENT,Tandem-Aug",
    ",".join(sorted(m for m, r in CT.items() if r["helps both"] == "yes")))
TC = {r["Regime"]: r for r in tbl("tcr.csv")}
for reg in ("query shift", "gallery shift", "joint"):
    chk(f"TCR {reg} present", "yes", "yes" if reg in TC else "no")
PM = tbl("tcr_permodel.csv")
chk("TCR per-model rows", 10, len(PM))
_oa = [num(r["T2I dR@1"]) for r in PM if r["Pretraining"] == "OpenAI WIT"]
_ot = [num(r["T2I dR@1"]) for r in PM if r["Pretraining"] != "OpenAI WIT"]
chk("all OpenAI CLIP gain in T2I", "yes", "yes" if all(v > 0 for v in _oa) else "NO")
chk("all other pipelines lose in T2I", "yes", "yes" if all(v < 0 for v in _ot) else "NO")
RS = raw("restore.csv")[1]
chk("restore image", 0.25, RS[1])
chk("restore caption", 1.72, RS[3])
chk("restore both", 2.00, RS[5])
chk("restore interaction", 0.02, RS[7])

# ── 10. structural ───────────────────────────────────────────────────────────
sect("10. Structural")
for name, n in [("checkpoints.csv", 19), ("img_ops.csv", 16), ("txt_ops.csv", 12),
                ("firerate.csv", 12), ("coverage.csv", 7), ("subsets.csv", 3),
                ("heldout.csv", 4), ("symmetric.csv", 2), ("cutoffs.csv", 5)]:
    chk(f"{name} rows", n, len(tbl(name)))
_ss = [r for r in tbl("firerate.csv") if r["Operator"] == "sentence_shuffle"][0]
chk("sentence_shuffle never fires", 0.0, _ss["sev 5"])

print(f"\n{'=' * 78}\n{PASS} passed, {FAIL} failed\n{'=' * 78}")
sys.exit(1 if FAIL else 0)
