# Stage 4 — Analysis

Turns the evaluation records into every table and number reported in the paper.

**This stage is standalone.** It ships the complete evaluation records, needs only
NumPy and SciPy, and requires no GPU, model weights, or image data.

```bash
python paper_tables.py     # regenerates every table  (~90 s)
python audit_claims.py     # 215 checks; exits non-zero on any mismatch
```

`paper_tables.py` writes one CSV and one LaTeX fragment per table into `tables/`, plus
combined Markdown and LaTeX renderings. No value in the paper is entered by hand; all
are computed from the records here, and `audit_claims.py` checks each against the
regenerated tables.

## Layout

| Path | Contents |
|---|---|
| `records/` | evaluation records behind every reported number, 91 CSV files |
| `records/results.csv` | merged baseline record used by the analysis |
| `paper_tables.py` | generates every table |
| `audit_claims.py` | ties reported values to the tables |
| `bootstrap_comparison.py` | row-wise vs clustered intervals |
| `screening/` | operator applicability, caption-length control, broader-pool audit |
| `figures/` | figure generation |
| `tables/` | generated output |

### Records

| Directory | Contents |
|---|---|
| `01_baseline_paths123/` | image-only, text-only and joint conditions, all 19 models, both datasets |
| `02_adaptation_subset/`, `03_adaptation_full/` | test-time adaptation |
| `05_restoration/` | input restoration |
| `06_screening/` | screening validation and the caption-length control |
| `07_tcr/` | TCR under all three corruption regimes |

Each row is one (model, dataset, path, corruption, severity, direction, method)
condition with Recall@1, @5 and @10.

## What the audit checks

215 assertions transcribed by hand from the paper, grouped by section: record counts
and matched-condition accounting, the screening table for all twelve operators, the
main joint result and its severity series, the dataset × direction strata, screen
sensitivity (held-out selection, symmetric image-side screen, realized-damage
matching), additive composition across retrieval cutoffs, estimator bias, and the
adaptation results.

It is written to catch the failure that matters: prose and tables drifting apart after
an analysis change. Several checks are structural rather than numeric — that
`punctuation_noise` is inside the execution-screened set despite doing almost nothing,
that it is outside the challenge set, that exactly TENT and TTA-Aug improve both
retrieval directions on a fixed backbone.

## Confidence intervals

Condition-level intervals use a clustered bootstrap over model × image-corruption ×
text-perturbation groups, preserving severity, dataset and retrieval direction within
each cluster. The design is heavily crossed — each model appears in thousands of
conditions and each operator pair in hundreds — so treating conditions as independent
draws understates the variance by roughly a factor of two.

Rank correlations resample over **models** instead, since the statistic is computed
across models.

```bash
python bootstrap_comparison.py    # writes BOOTSTRAP_METHODOLOGY.md
```

This reports both estimators side by side for every condition-level statistic and
rebuilds each one from the raw records independently of the table generator, so
agreement is a cross-implementation check rather than a restatement.
