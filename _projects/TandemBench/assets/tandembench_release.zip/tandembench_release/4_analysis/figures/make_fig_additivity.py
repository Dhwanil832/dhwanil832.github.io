"""F4 — additivity, in two panels.

Replaces the single-panel scatter. The single panel could not carry section 4.4's claim:
in raw Recall@1 points the severity-5 cloud is both lower AND wider than the severity-1
cloud, and a reader cannot tell which part is bias and which is loss of precision. It is
in fact almost entirely bias -- relative absolute error is 10.4% at severity 1 and 13.7%
at severity 5, essentially flat -- while the signed bias moves from +2.7% to -10.9%.

  (a) observed vs additive prediction, with the identity line and per-severity r2.
      Shows the systematic downward shift.
  (b) relative error (d3 - (d1+d2)) / d3 by severity, as box plots.
      The box CENTRES move down monotonically, +1.9% to -10.1%. That is the bias, and it
      is the robust part of this panel.

      Do NOT read panel (b) as a precision comparison. The IQR is 16.5, 11.6, 11.0, 12.0,
      16.6 -- comparable at the two ends but U-shaped, not flat. Severity 1's wide box is
      partly an artefact of dividing by a small d3 (mean 5.47 pp): relative error is
      itself unstable at low damage, which is the near-zero-denominator problem section
      4.2 documents. The flat-relative-precision claim in the text rests on the mean
      ABSOLUTE relative error in Table 4 (10.4% -> 13.7%), not on these box widths.

Run from repo root:  python analysis/make_fig_additivity.py
"""
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "analysis"))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)
RNG = np.random.default_rng(123)

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.5,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 200, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
TEAL, CORAL, PURPLE, GREY = "#2f9e8f", "#d96f5c", "#7c5cbf", "#898781"
SEV_COL = {1: TEAL, 2: "#4a9fb5", 3: PURPLE, 4: "#b86a8a", 5: CORAL}


def load():
    """Reuse paper_tables.py's triple construction so the figure and the tables can
    never disagree about what a triple is."""
    import runpy, io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        g = runpy.run_path(os.path.join(ROOT, "paper_tables.py"))
    return g["T"]


T = load()
print(f"{len(T):,} triples")

fig, (axA, axB) = plt.subplots(1, 2, figsize=(6.9, 2.9),
                               gridspec_kw={"width_ratios": [1.0, 1.05], "wspace": 0.28})

# ── (a) observed vs predicted ────────────────────────────────────────────────
for s in (5, 3, 1):
    idx = [i for i, t in enumerate(T) if t["sev"] == s]
    if len(idx) > 5000:
        idx = list(RNG.choice(idx, 5000, replace=False))
    x = np.array([T[i]["d1"] + T[i]["d2"] for i in idx])
    y = np.array([T[i]["d3"] for i in idx])
    S = [t for t in T if t["sev"] == s]
    pred = np.array([t["d1"] + t["d2"] for t in S])
    obs = np.array([t["d3"] for t in S])
    r2 = 1 - np.sum((obs - pred) ** 2) / np.sum((obs - obs.mean()) ** 2)
    axA.scatter(x, y, s=2.0, c=SEV_COL[s], marker="o", alpha=0.18, linewidths=0,
                rasterized=True, label=f"severity {s}   $r^2$ = {r2:.3f}")

lim = 62
axA.plot([0, lim], [0, lim], color="black", linestyle=(0, (5, 4)), linewidth=1.4, zorder=6)
axA.text(lim * 0.60, lim * 0.68, "$\\delta_3=\\delta_1{+}\\delta_2$", fontsize=7, rotation=41)
axA.set_xlabel("additive prediction  $\\delta_1+\\delta_2$  (pp R@1)")
axA.set_ylabel("observed joint drop  $\\delta_3$  (pp R@1)")
axA.set_xlim(0, lim); axA.set_ylim(0, lim); axA.set_aspect("equal")
lg = axA.legend(frameon=False, loc="upper left", markerscale=4, handletextpad=0.2,
                borderpad=0.1, labelspacing=0.25)
for h in lg.legend_handles:
    h.set_alpha(1.0)
axA.grid(color=GREY, alpha=0.15, linewidth=0.5)
axA.set_title("(a) observed against additive prediction", fontsize=8, loc="left")

# ── (b) relative error by severity ───────────────────────────────────────────
data, means = [], []
for s in range(1, 6):
    S = [t for t in T if t["sev"] == s]
    rel = np.array([(t["d3"] - t["d1"] - t["d2"]) / t["d3"] * 100
                    for t in S if t["d3"] > 0.5])
    data.append(rel)
    means.append(rel.mean())

bp = axB.boxplot(data, positions=range(1, 6), widths=0.6, showfliers=False,
                 patch_artist=True, medianprops=dict(color="black", linewidth=1.1),
                 whiskerprops=dict(color=GREY, linewidth=0.8),
                 capprops=dict(color=GREY, linewidth=0.8))
for patch, s in zip(bp["boxes"], range(1, 6)):
    patch.set_facecolor(SEV_COL[s]); patch.set_alpha(0.55); patch.set_edgecolor(GREY)
axB.axhline(0, color="black", linestyle=(0, (5, 4)), linewidth=1.4, zorder=1)
axB.plot(range(1, 6), means, color="black", marker="D", markersize=3.2,
         linewidth=1.0, zorder=5, label="mean")
axB.set_xlabel("severity")
axB.set_ylabel("relative prediction error  (%)")
axB.legend(frameon=False, loc="lower left")
axB.grid(color=GREY, alpha=0.15, linewidth=0.5, axis="y")
axB.set_title("(b) relative prediction error by severity", fontsize=8, loc="left")

for ext in ("pdf", "png"):
    fig.savefig(os.path.join(FIG, f"F4_additivity.{ext}"), dpi=400)
plt.close(fig)
print("   -> figures/F4_additivity.pdf/.png")

print("\n           mean rel err    IQR width")
for s, d in zip(range(1, 6), data):
    q1, q3 = np.percentile(d, [25, 75])
    print(f"severity {s}   {d.mean():+7.1f}%     {q3 - q1:6.1f} pts")
