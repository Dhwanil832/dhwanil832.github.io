"""Generate F2 (corruption gallery), F3 (severity curves), F4 (additivity scatter).

Outputs vector PDF + PNG preview to figures/.
WACV: single-column 3.25in, double-column 6.9in, >=8pt fonts.
"""
import csv, os, collections
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)
RNG = np.random.default_rng(123)

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 200, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
TEAL, CORAL, PURPLE, GREY = "#2f9e8f", "#d96f5c", "#7c5cbf", "#898781"


# ── Load triples ─────────────────────────────────────────────────────────────
def load_triples():
    rows = [r for r in csv.DictReader(open(os.path.join(ROOT, "records", "results.csv"))) if r["TTA_method"] == "none"]
    rows = [r for r in rows if not (r["model"] == "blip_large" and r["path"] == "3")]
    bl = [r for r in csv.DictReader(open(os.path.join(ROOT, "records", "03_adaptation_full", "path3_blip_large_coco.csv")))
          if r["TTA_method"] == "none"]
    bc = {r["direction"]: float(r["R@1"]) for r in bl if r["corruption_type"] == "clean"}
    for r in bl:
        if r["corruption_type"] != "clean":
            rows.append({"model": "blip_large", "dataset": "coco", "path": "3",
                         "corruption_type": r["corruption_type"], "severity": r["severity"],
                         "direction": r["direction"], "R@1": r["R@1"], "TTA_method": "none"})
    cl, d1, d2, d3 = {}, {}, {}, {}
    for r in rows:
        if r["corruption_type"] == "clean" and r["path"] == "1":
            cl[(r["model"], r["dataset"], r["direction"])] = float(r["R@1"])
    for r in rows:
        if r["corruption_type"] == "clean":
            continue
        k0 = (r["model"].strip(), r["dataset"], r["direction"])
        if k0 not in cl:
            continue
        base = bc[r["direction"]] if (r["model"] == "blip_large" and r["path"] == "3") else cl[k0]
        drop, sev = base - float(r["R@1"]), int(r["severity"])
        if r["path"] == "1":   d1[k0 + (r["corruption_type"], sev)] = drop
        elif r["path"] == "2": d2[k0 + (r["corruption_type"], sev)] = drop
        elif r["path"] == "3" and "+" in r["corruption_type"]:
            a, b = r["corruption_type"].split("+", 1)
            if not (r["model"] == "blip_large" and r["dataset"] == "flickr30k"):
                d3[k0 + (a, b, sev)] = drop
    T = []
    for k3, v3 in d3.items():
        m, ds, dr, a, b, s = k3
        k1, k2 = (m, ds, dr, a, s), (m, ds, dr, b, s)
        if k1 in d1 and k2 in d2 and d1[k1] + d2[k2] >= 0.5:
            T.append((m, ds, dr, a, b, s, d1[k1], d2[k2], v3, v3 / (d1[k1] + d2[k2])))
    return T


# Validated text corruptions only — see PAPER_FACTS.md §9b.
# sentence_shuffle fires on 0% of captions; relation_swap 25.6%, negation_insertion 4.0%,
# attribute_swap 18.2%, punctuation_noise delivers only 1.25pp damage. Weak perturbations
# inflate MIS = d3/(d1+d2) because the denominator collapses (rho(d2, MIS) = -0.888).
STRONG_TXT = {"word_shuffle", "word_delete", "char_delete", "char_swap",
              "object_substitution", "keyboard_typo", "ocr_error"}


def main():
    pass


T_all = load_triples()
T = [t for t in T_all if t[4] in STRONG_TXT]
print(f"triples: {len(T):,} validated  (of {len(T_all):,} total)")


def ci(v, nb=4000):
    v = np.asarray(v, float)
    b = np.array([v[RNG.integers(0, v.size, v.size)].mean() for _ in range(nb)])
    return np.percentile(b, [2.5, 97.5])


# ── F3: severity curves, per dataset ─────────────────────────────────────────
print("F3 severity curves...")
fig, ax = plt.subplots(figsize=(3.25, 2.5))
sevs = [1, 2, 3, 4, 5]
for ds, label, colour, marker in [("flickr30k", "Flickr30k (1k gallery)", TEAL, "o"),
                                  ("coco", "COCO (5k gallery)", CORAL, "s")]:
    mu, lo, hi = [], [], []
    for s in sevs:
        v = np.array([t[9] for t in T if t[1] == ds and t[5] == s])
        mu.append(v.mean()); l, h = ci(v); lo.append(l); hi.append(h)
    ax.fill_between(sevs, lo, hi, color=colour, alpha=0.18, linewidth=0)
    ax.plot(sevs, mu, color=colour, marker=marker, markersize=4, linewidth=1.6,
            label=label, zorder=3)
    print(f"   {ds:<10} " + "  ".join(f"s{s}={m:.4f}[{l:.4f},{h:.4f}]"
                                      for s, m, l, h in zip(sevs, mu, lo, hi)))
ax.axhline(1.0, color=GREY, linestyle=(0, (5, 4)), linewidth=1.0, zorder=1)
ax.text(2.6, 1.006, "additive", fontsize=6.5, color=GREY, va="bottom", ha="center",
        bbox=dict(fc="white", ec="none", pad=0.6))
ax.set_xlabel("corruption severity"); ax.set_ylabel("coupling  $\\delta_3/(\\delta_1+\\delta_2)$")
ax.set_xticks(sevs); ax.set_xlim(0.8, 5.2)
ax.legend(frameon=False, loc="lower left", borderaxespad=0.3)
ax.grid(axis="y", color=GREY, alpha=0.15, linewidth=0.5)
for ext in ("pdf", "png"):
    fig.savefig(os.path.join(FIG, f"F3_severity.{ext}"))
plt.close(fig)
print("   -> F3_severity.pdf/.png")

# ── F4: additivity scatter ───────────────────────────────────────────────────
print("F4 additivity scatter...")
fig, ax = plt.subplots(figsize=(3.25, 3.0))
style = {1: (TEAL, "o", "severity 1"), 3: (PURPLE, "^", "severity 3"), 5: (CORAL, "s", "severity 5")}
for s in (5, 3, 1):
    idx = [i for i, t in enumerate(T) if t[5] == s]
    if len(idx) > 5000:
        idx = list(RNG.choice(idx, 5000, replace=False))
    x = np.array([T[i][6] + T[i][7] for i in idx]); y = np.array([T[i][8] for i in idx])
    c, mk, lab = style[s]
    ax.scatter(x, y, s=2.0, c=c, marker=mk, alpha=0.20, linewidths=0, label=lab, rasterized=True)
lim = 62
ax.plot([0, lim], [0, lim], color="black", linestyle=(0, (5, 4)), linewidth=1.0, zorder=5)
ax.text(lim * 0.66, lim * 0.72, "$\\delta_3=\\delta_1{+}\\delta_2$", fontsize=7, rotation=41)
ax.set_xlabel("predicted additive drop  $\\delta_1+\\delta_2$  (pp R@1)")
ax.set_ylabel("observed joint drop  $\\delta_3$  (pp R@1)")
ax.set_xlim(0, lim); ax.set_ylim(0, lim); ax.set_aspect("equal")
lg = ax.legend(frameon=False, loc="upper left", markerscale=4, handletextpad=0.2)
for h in lg.legend_handles:
    h.set_alpha(1.0)
ax.grid(color=GREY, alpha=0.15, linewidth=0.5)
for ext in ("pdf", "png"):
    fig.savefig(os.path.join(FIG, f"F4_scatter.{ext}"), dpi=400)
plt.close(fig)
print("   -> F4_scatter.pdf/.png")

# ── F2: corruption gallery ───────────────────────────────────────────────────
print("F2 corruption gallery...")
IMG_CORR = ["gaussian_noise", "shot_noise", "impulse_noise", "speckle_noise",
            "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",
            "snow", "frost", "fog", "brightness",
            "contrast", "elastic_transform", "pixelate", "jpeg_compression"]
SAMPLE = "000000000632.jpg"
CELL, PAD, LABEL_H, SEV = 150, 3, 15, 3
cols, rowsn = 4, 4
W = cols * CELL + (cols + 1) * PAD
H = rowsn * (CELL + LABEL_H) + (rowsn + 1) * PAD
canvas = Image.new("RGB", (W, H), "white")
draw = ImageDraw.Draw(canvas)
try:
    font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 10)
except Exception:
    font = ImageFont.load_default()
missing = []
for i, c in enumerate(IMG_CORR):
    r, col = divmod(i, cols)
    p = os.path.join(ROOT, os.pardir, "data", "coco_c", c, f"severity_{SEV}", SAMPLE)
    x = PAD + col * (CELL + PAD)
    y = PAD + r * (CELL + LABEL_H + PAD)
    if os.path.exists(p):
        im = Image.open(p).convert("RGB")
        s = min(im.size); im = im.crop(((im.width - s) // 2, (im.height - s) // 2,
                                        (im.width + s) // 2, (im.height + s) // 2))
        canvas.paste(im.resize((CELL, CELL), Image.LANCZOS), (x, y))
    else:
        missing.append(c); draw.rectangle([x, y, x + CELL, y + CELL], outline="#cccccc")
    draw.text((x + 1, y + CELL + 2), c.replace("_", " "), fill="black", font=font)
canvas.save(os.path.join(FIG, "F2_gallery_images.png"))
print(f"   -> F2_gallery_images.png  (missing: {missing if missing else 'none'})")

# text corruption panel
try:
    import sys
    sys.path.insert(0, ROOT)
    from text_corruptions import corrupt_text, ALL_CORRUPTION_TYPES
    base = "A man riding a bicycle down a busy city street"
    lines = [("clean", base)]
    for c in ALL_CORRUPTION_TYPES:
        try:
            lines.append((c, corrupt_text(base, c, SEV, seed=123 + SEV)))
        except Exception as e:
            lines.append((c, f"<error: {e}>"))
    LH, TW = 20, 620
    tc = Image.new("RGB", (TW, LH * len(lines) + 8), "white")
    td = ImageDraw.Draw(tc)
    for i, (c, s) in enumerate(lines):
        td.text((4, 4 + i * LH), f"{c:<22}", fill="#666666", font=font)
        td.text((150, 4 + i * LH), s, fill="black", font=font)
    tc.save(os.path.join(FIG, "F2_gallery_text.png"))
    print("   -> F2_gallery_text.png")
    for c, s in lines:
        print(f"      {c:<22}{s}")
except Exception as e:
    print(f"   text panel skipped: {e}")

print("\nDONE ->", FIG)
