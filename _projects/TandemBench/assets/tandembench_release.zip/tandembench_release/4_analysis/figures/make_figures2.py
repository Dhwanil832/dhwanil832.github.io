"""Second figure batch. All from data on disk, all on the VALIDATED text-corruption subset.

  M1_bias.pdf         fire-rate/d2 vs MIS, rho = -0.888   [MAIN - methodological contribution]
  M2_forest.pdf       per-model MIS + MDI forest           [MAIN candidate]
  S1_heatmap.pdf      16 image x 7 text corruption-pair MIS
  S2_direction.pdf    I2T vs T2I severity curves
  S3_scale.pdf        MIS by scale within family
  S4_recovery.pdf     fix-image vs fix-text per model
  S5_tta.pdf          TTA effects grouped by adaptation scope
  S6_tta_scatter.pdf  TTA I2T vs T2I asymmetry
  S7_bias_cost.pdf    all-12 vs validated-7 severity curves
  S8_firerate.pdf     corruption fire rates
"""
import csv, os, sys, collections
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures"); os.makedirs(FIG, exist_ok=True)
sys.path.insert(0, os.path.join(ROOT, "analysis"))
RNG = np.random.default_rng(123)

plt.rcParams.update({"font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "figure.dpi": 200, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
TEAL, CORAL, PURPLE, GREY, BLUE = "#2f9e8f", "#d96f5c", "#7c5cbf", "#898781", "#3266ad"
STRONG = {"word_shuffle", "word_delete", "char_delete", "char_swap",
          "object_substitution", "keyboard_typo", "ocr_error"}
FAMILY = {"clip": "CLIP", "openclip": "OpenCLIP", "metaclip": "MetaCLIP",
          "evaclip": "EVA-CLIP", "siglip": "SigLIP", "dfn": "DFN", "coca": "CoCa", "blip": "BLIP"}
FAM_COL = {"CLIP": CORAL, "OpenCLIP": TEAL, "MetaCLIP": PURPLE, "EVA-CLIP": BLUE,
           "SigLIP": "#c98a1b", "DFN": "#7a7a7a", "CoCa": "#b5559b", "BLIP": "#4a4a4a"}
IMG_ORDER = ["gaussian_noise", "shot_noise", "impulse_noise", "speckle_noise",
             "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",
             "snow", "frost", "fog", "brightness",
             "contrast", "elastic_transform", "pixelate", "jpeg_compression"]
TXT_ORDER = ["keyboard_typo", "ocr_error", "char_swap", "char_delete",
             "word_delete", "word_shuffle", "object_substitution"]
SCALE_POS = {"b32": 0, "b16": 1, "l14": 2, "l16": 2, "l14_336": 2.4, "h14": 3,
             "so400m": 3.3, "bigg14": 4, "vitl": 2, "large": 2}


def fam(m):
    for k, v in FAMILY.items():
        if m.startswith(k):
            return v
    return "other"


def scale_of(m):
    for k in sorted(SCALE_POS, key=len, reverse=True):
        if m.endswith(k) or k in m:
            return SCALE_POS[k]
    return 2


def ci(v, nb=3000):
    v = np.asarray(v, float)
    if v.size < 3:
        return (np.nan, np.nan)
    b = np.array([v[RNG.integers(0, v.size, v.size)].mean() for _ in range(nb)])
    return np.percentile(b, [2.5, 97.5])


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"))
    plt.close(fig); print(f"   -> {name}.pdf/.png")


from make_figures import load_triples
T_all = load_triples()
T = [t for t in T_all if t[4] in STRONG]
print(f"validated triples {len(T):,} / {len(T_all):,}\n")
models = sorted(set(t[0] for t in T))

# ── M1: the metric-bias figure ───────────────────────────────────────────────
print("M1 metric bias")
fire = collections.defaultdict(lambda: [0, 0])
for r in csv.DictReader(open(os.path.join(ROOT, "validation_output.csv"))):
    c = r["corruption_type"]
    fire[c][0] += (0 if r["original"].strip() == r["corrupted"].strip() else 1); fire[c][1] += 1
rr = [r for r in csv.DictReader(open(os.path.join(ROOT, "records", "results.csv"))) if r["TTA_method"] == "none"]
cl = {(r["model"], r["dataset"], r["direction"]): float(r["R@1"])
      for r in rr if r["corruption_type"] == "clean" and r["path"] == "1"}
d2m = collections.defaultdict(list)
for r in rr:
    if r["path"] == "2" and r["corruption_type"] != "clean":
        k = (r["model"], r["dataset"], r["direction"])
        if k in cl:
            d2m[r["corruption_type"]].append(cl[k] - float(r["R@1"]))
mis_t = collections.defaultdict(list)
for t in T_all:
    mis_t[t[4]].append(t[9])
cs = sorted(mis_t)
X = np.array([np.mean(d2m[c]) for c in cs]); Y = np.array([np.mean(mis_t[c]) for c in cs])
rho = np.corrcoef(np.argsort(np.argsort(X)), np.argsort(np.argsort(Y)))[0, 1]
fig, ax = plt.subplots(figsize=(3.25, 2.7))
for c, x, y in zip(cs, X, Y):
    ok = c in STRONG
    ax.scatter(x, y, s=34 if ok else 30, c=TEAL if ok else CORAL,
               marker="o" if ok else "X", zorder=3, linewidths=0)
    dy = 0.004 if c not in ("ocr_error", "char_delete") else -0.010
    ax.annotate(c.replace("_", " "), (x, y), fontsize=5.6, color="#333333",
                xytext=(0, 5 if dy > 0 else -9), textcoords="offset points", ha="center")
b, a = np.polyfit(X, Y, 1)
xs = np.linspace(-0.5, 16, 50); ax.plot(xs, a + b * xs, color=GREY, lw=1.0, ls=(0, (4, 3)), zorder=1)
ax.axhline(1.0, color=GREY, lw=0.7, alpha=0.5)
ax.set_xlabel("text-corruption strength   mean $\\delta_2$  (pp R@1)")
ax.set_ylabel("apparent coupling  MIS")
ax.set_title(f"Weak perturbations inflate the metric  ($\\rho$ = {rho:+.3f})", fontsize=8)
ax.set_xlim(-0.8, 16.5)
ax.scatter([], [], c=TEAL, s=30, label="validated (fires >55%)")
ax.scatter([], [], c=CORAL, marker="X", s=30, label="weak / no-op")
ax.legend(frameon=False, loc="upper right")
save(fig, "M1_bias")

# ── M2: per-model forest ─────────────────────────────────────────────────────
print("M2 forest")
rowsf = []
for m in models:
    v = np.array([t[9] for t in T if t[0] == m]); lo, hi = ci(v)
    md = np.array([(t[6] + t[8] - t[7]) / (2 * t[8]) for t in T if t[0] == m and t[8] > 0.5])
    rowsf.append((m, v.mean(), lo, hi, md.mean()))
rowsf.sort(key=lambda r: r[1])
fig, axes = plt.subplots(1, 2, figsize=(6.9, 3.4), gridspec_kw={"width_ratios": [1.7, 1]})
ax = axes[0]; ypos = np.arange(len(rowsf))
for i, (m, mu, lo, hi, _) in enumerate(rowsf):
    c = FAM_COL.get(fam(m), GREY)
    ax.plot([lo, hi], [i, i], color=c, lw=1.4, solid_capstyle="round")
    ax.plot(mu, i, "o", color=c, ms=4)
ax.axvline(1.0, color=GREY, ls=(0, (5, 4)), lw=1.0)
ax.set_yticks(ypos); ax.set_yticklabels([r[0] for r in rowsf], fontsize=6)
ax.set_xlabel("coupling  $\\delta_3/(\\delta_1+\\delta_2)$"); ax.set_ylim(-0.8, len(rowsf) - 0.2)
ax.set_title("(a) coupling per model, 95% CI", loc="left")
# Panel (b): MDI is only interpretable RELATIVE to other models -- the absolute
# 0.5 threshold is an artifact of corruption-suite calibration (17/19 image-dominant
# on all-12 text corruptions vs 0/19 on the validated subset). Centre on the
# cross-model mean and label the axis as relative sensitivity.
ax2 = axes[1]
mdis = np.array([r[4] for r in rowsf]); centre = mdis.mean()
for i, (m, _, _, _, md) in enumerate(rowsf):
    ax2.barh(i, md - centre, left=centre, color=FAM_COL.get(fam(m), GREY), height=0.6)
ax2.axvline(centre, color=GREY, ls=(0, (5, 4)), lw=1.0)
ax2.set_yticks(ypos); ax2.set_yticklabels([]); ax2.set_ylim(-0.8, len(rowsf) - 0.2)
ax2.set_xlabel("MDI, relative to cohort mean\n$\\leftarrow$ more text-sensitive | more image-sensitive $\\rightarrow$",
               fontsize=6.5)
ax2.set_title("(b) relative modality sensitivity", loc="left")
seen = []
for m, *_ in rowsf:
    f = fam(m)
    if f not in seen:
        seen.append(f); ax.scatter([], [], c=FAM_COL.get(f, GREY), s=18, label=f)
ax.legend(frameon=False, fontsize=6, loc="lower right", ncol=2)
save(fig, "M2_forest")

# ── S1: corruption-pair heatmap ──────────────────────────────────────────────
print("S1 heatmap")
M = np.full((len(IMG_ORDER), len(TXT_ORDER)), np.nan)
for i, ic in enumerate(IMG_ORDER):
    for j, tc in enumerate(TXT_ORDER):
        v = [t[9] for t in T if t[3] == ic and t[4] == tc]
        if v:
            M[i, j] = np.mean(v)
fig, ax = plt.subplots(figsize=(3.9, 4.4))
lim = np.nanmax(np.abs(M - 1.0))
im = ax.imshow(M, cmap="RdBu_r", vmin=1 - lim, vmax=1 + lim, aspect="auto")
ax.set_xticks(range(len(TXT_ORDER)))
ax.set_xticklabels([c.replace("_", "\n") for c in TXT_ORDER], fontsize=5.5)
ax.set_yticks(range(len(IMG_ORDER)))
ax.set_yticklabels([c.replace("_", " ") for c in IMG_ORDER], fontsize=6)
for i in range(len(IMG_ORDER)):
    for j in range(len(TXT_ORDER)):
        if not np.isnan(M[i, j]):
            ax.text(j, i, f"{M[i,j]:.2f}", ha="center", va="center", fontsize=4.8,
                    color="white" if abs(M[i, j] - 1) > lim * 0.55 else "#222222")
ax.axhline(3.5, color="white", lw=1.2); ax.axhline(7.5, color="white", lw=1.2)
ax.axhline(11.5, color="white", lw=1.2)
cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.03); cb.set_label("MIS", fontsize=7)
cb.ax.tick_params(labelsize=6)
ax.set_title("coupling by corruption pair", fontsize=8)
save(fig, "S1_heatmap")

# ── S2: direction ────────────────────────────────────────────────────────────
print("S2 direction")
fig, ax = plt.subplots(figsize=(3.25, 2.4))
for dr, c, mk in [("I2T", TEAL, "o"), ("T2I", PURPLE, "s")]:
    mu, lo, hi = [], [], []
    for s in range(1, 6):
        v = np.array([t[9] for t in T if t[2] == dr and t[5] == s])
        mu.append(v.mean()); l, h = ci(v); lo.append(l); hi.append(h)
    ax.fill_between(range(1, 6), lo, hi, color=c, alpha=0.18, lw=0)
    ax.plot(range(1, 6), mu, color=c, marker=mk, ms=4, lw=1.6, label=dr)
ax.axhline(1.0, color=GREY, ls=(0, (5, 4)), lw=1.0)
ax.set_xlabel("corruption severity"); ax.set_ylabel("coupling"); ax.set_xticks(range(1, 6))
ax.legend(frameon=False); save(fig, "S2_direction")

# ── S3: scale ────────────────────────────────────────────────────────────────
print("S3 scale")
fig, ax = plt.subplots(figsize=(3.25, 2.6))
byfam = collections.defaultdict(list)
for m in models:
    v = np.mean([t[9] for t in T if t[0] == m])
    byfam[fam(m)].append((scale_of(m), v, m))
for f, pts in byfam.items():
    pts.sort()
    if len(pts) > 1:
        ax.plot([p[0] for p in pts], [p[1] for p in pts], "-o", color=FAM_COL.get(f, GREY),
                ms=3.5, lw=1.3, label=f)
    else:
        ax.plot(pts[0][0], pts[0][1], "o", color=FAM_COL.get(f, GREY), ms=4, label=f)
ax.axhline(1.0, color=GREY, ls=(0, (5, 4)), lw=1.0)
ax.set_xticks([0, 1, 2, 3, 4]); ax.set_xticklabels(["B/32", "B/16", "L", "H/SO400M", "bigG"], fontsize=6.5)
ax.set_xlabel("model scale"); ax.set_ylabel("coupling")
ax.legend(frameon=False, fontsize=6, ncol=2); save(fig, "S3_scale")

# ── S4: recovery ─────────────────────────────────────────────────────────────
print("S4 recovery")
rec = []
for m in models:
    fi = np.mean([t[8] - t[7] for t in T if t[0] == m])
    ft = np.mean([t[8] - t[6] for t in T if t[0] == m])
    rec.append((m, fi, ft))
rec.sort(key=lambda r: r[1] - r[2])
fig, ax = plt.subplots(figsize=(3.4, 3.6))
y = np.arange(len(rec))
ax.barh(y - 0.2, [r[1] for r in rec], height=0.38, color=TEAL, label="restore image")
ax.barh(y + 0.2, [r[2] for r in rec], height=0.38, color=PURPLE, label="restore text")
ax.set_yticks(y); ax.set_yticklabels([r[0] for r in rec], fontsize=6)
ax.set_xlabel("R@1 recovered (pp)"); ax.legend(frameon=False, loc="lower right")
ax.set_ylim(-0.7, len(rec) - 0.3); save(fig, "S4_recovery")

# ── S5 / S6: TTA ─────────────────────────────────────────────────────────────
print("S5/S6 TTA")
try:
    te = list(csv.DictReader(open(os.path.join(ROOT, "records", "06_screening",
                                               "tta_effects_ci.csv"))))
    SCOPE = {"TENT": "LayerNorm only", "TTA-Aug": "no adaptation",
             "QueryExpansion": "no adaptation", "MEMO": "full model, per-image",
             "TPT": "prompt", "DiffTPT": "prompt", "PromptAlign": "prompt",
             "FeatureWhitening": "embedding space"}
    SC_ORDER = ["LayerNorm only", "no adaptation", "full model, per-image", "prompt", "embedding space"]
    SC_COL = {"LayerNorm only": TEAL, "no adaptation": "#7fb6ae",
              "full model, per-image": "#c9a227", "prompt": PURPLE, "embedding space": CORAL}
    d = {(r["method"], r["direction"]): (float(r["delta_pp"]), float(r["ci_lo"]), float(r["ci_hi"]))
         for r in te}
    meths = sorted({r["method"] for r in te},
                   key=lambda m: (SC_ORDER.index(SCOPE.get(m, "prompt")),
                                  -d.get((m, "I2T"), (0,))[0]))
    fig, ax = plt.subplots(figsize=(3.6, 3.2)); y = np.arange(len(meths))
    for i, m in enumerate(meths):
        c = SC_COL[SCOPE.get(m, "prompt")]
        for off, alpha, dr in [(-0.2, 1.0, "I2T"), (0.2, 0.55, "T2I")]:
            if (m, dr) in d:
                v, lo, hi = d[(m, dr)]
                ax.barh(i + off, v, height=0.36, color=c, alpha=alpha)
                ax.plot([lo, hi], [i + off, i + off], color="#333333", lw=0.8)
    ax.axvline(0, color="#333333", lw=0.9)
    ax.set_yticks(y); ax.set_yticklabels(meths, fontsize=6.5); ax.set_ylim(-0.7, len(meths) - 0.3)
    ax.set_xlabel("$\\Delta$ R@1 vs no adaptation (pp)")
    for sc in SC_ORDER:
        ax.barh([], [], color=SC_COL[sc], label=sc)
    ax.legend(frameon=False, fontsize=5.8, loc="lower left", title="adaptation scope",
              title_fontsize=6)
    save(fig, "S5_tta")

    fig, ax = plt.subplots(figsize=(3.0, 3.0))
    for m in meths:
        if (m, "I2T") in d and (m, "T2I") in d:
            x, yv = d[(m, "I2T")][0], d[(m, "T2I")][0]
            ax.scatter(x, yv, s=30, color=SC_COL[SCOPE.get(m, "prompt")], zorder=3)
            ax.annotate(m, (x, yv), fontsize=5.5, xytext=(3, 3), textcoords="offset points")
    lim = 32
    ax.plot([-lim, lim], [-lim, lim], color=GREY, ls=(0, (4, 3)), lw=0.9)
    ax.axhline(0, color="#333333", lw=0.7); ax.axvline(0, color="#333333", lw=0.7)
    ax.set_xlim(-lim, 8); ax.set_ylim(-lim, 8)
    ax.set_xlabel("$\\Delta$ R@1  image$\\rightarrow$text"); ax.set_ylabel("$\\Delta$ R@1  text$\\rightarrow$image")
    save(fig, "S6_tta_scatter")
except Exception as e:
    print("   TTA figures skipped:", e)

# ── S7: what the bias costs ──────────────────────────────────────────────────
print("S7 bias cost")
fig, ax = plt.subplots(figsize=(3.25, 2.4))
for name, TT, c, ls in [("all 12 text corruptions", T_all, CORAL, (0, (4, 3))),
                        ("validated 7", T, TEAL, "-")]:
    mu = [np.mean([t[9] for t in TT if t[5] == s]) for s in range(1, 6)]
    ax.plot(range(1, 6), mu, color=c, marker="o", ms=3.5, lw=1.6, ls=ls, label=name)
ax.axhline(1.0, color=GREY, ls=(0, (5, 4)), lw=1.0)
ax.set_xlabel("corruption severity"); ax.set_ylabel("coupling"); ax.set_xticks(range(1, 6))
ax.legend(frameon=False); save(fig, "S7_bias_cost")

# ── S8: fire rates ───────────────────────────────────────────────────────────
print("S8 fire rates")
fr = sorted(((c, v[0] / max(v[1], 1)) for c, v in fire.items()), key=lambda x: x[1])
fig, ax = plt.subplots(figsize=(3.25, 2.6))
ax.barh(range(len(fr)), [f[1] * 100 for f in fr],
        color=[TEAL if f[0] in STRONG else CORAL for f in fr], height=0.62)
ax.set_yticks(range(len(fr))); ax.set_yticklabels([f[0].replace("_", " ") for f in fr], fontsize=6.5)
ax.axvline(55, color=GREY, ls=(0, (4, 3)), lw=1.0)
ax.text(56, 0.2, "validity\nthreshold", fontsize=5.8, color=GREY)
ax.set_xlabel("% of captions actually modified"); ax.set_xlim(0, 105)
save(fig, "S8_firerate")

print("\nDONE ->", FIG)
