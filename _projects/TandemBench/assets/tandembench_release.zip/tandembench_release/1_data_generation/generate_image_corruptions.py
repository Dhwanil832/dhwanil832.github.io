#!/usr/bin/env python3
"""
generate_image_corruptions.py

Generates all 15 standard Hendrycks image corruptions x 5 severity levels
for COCO val2017 (5,000 images) and Flickr30k test split (1,000 images).

Usage:
    python generate_image_corruptions.py --dataset coco --seed 42
    python generate_image_corruptions.py --dataset flickr30k --seed 42
    python generate_image_corruptions.py --dataset both --seed 42

Seeds:
    Main researcher  : --seed 42   (default)
    Collaborator     : --seed 123

Output structure:
    data/coco_c/<corruption_type>/severity_<k>/<filename>.jpg
    data/flickr30k_c/<corruption_type>/severity_<k>/<filename>.jpg
"""

import argparse
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image
from tqdm import tqdm

try:
    from imagecorruptions import corrupt
except ImportError:
    print("ERROR: imagecorruptions not installed.")
    print("Run: pip install imagecorruptions")
    sys.exit(1)

# ── Standard 15 Hendrycks corruptions ─────────────────────────────────────────
CORRUPTION_TYPES = [
    # Noise (4)
    "gaussian_noise",
    "shot_noise",
    "impulse_noise",
    "speckle_noise",
    # Blur (4)
    "defocus_blur",
    "glass_blur",
    "motion_blur",
    "zoom_blur",
    # Weather (4)
    "snow",
    "frost",
    "fog",
    "brightness",
    # Digital (3)
    "contrast",
    "elastic_transform",
    "pixelate",
    "jpeg_compression",
]

SEVERITIES = [1, 2, 3, 4, 5]

# ── Helpers ────────────────────────────────────────────────────────────────────

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)


def get_coco_image_paths(base_dir: Path):
    """All 5,000 COCO val2017 images."""
    img_dir = base_dir / "data" / "coco" / "images" / "val2017"
    if not img_dir.exists():
        print(f"ERROR: COCO images not found at {img_dir}")
        sys.exit(1)
    paths = sorted(img_dir.glob("*.jpg"))
    print(f"COCO: found {len(paths)} images in val2017/")
    return paths


def get_flickr30k_image_paths(base_dir: Path):
    """Only the 1,000 Flickr30k test split images."""
    ann_path = base_dir / "data" / "flickr30k" / "annotations" / "dataset_flickr30k.json"
    img_dir  = base_dir / "data" / "flickr30k" / "images" / "flickr30k-images"

    if not ann_path.exists():
        print(f"ERROR: Flickr30k annotations not found at {ann_path}")
        sys.exit(1)
    if not img_dir.exists():
        print(f"ERROR: Flickr30k images not found at {img_dir}")
        sys.exit(1)

    with open(ann_path) as f:
        data = json.load(f)

    test_filenames = [img["filename"] for img in data["images"] if img["split"] == "test"]
    paths = sorted([img_dir / fn for fn in test_filenames if (img_dir / fn).exists()])
    print(f"Flickr30k: found {len(paths)} test-split images (expected 1,000)")
    return paths


def corrupt_single(img_path: Path, out_path: Path, corruption: str, severity: int) -> str:
    """
    Corrupt one image and save. Returns 'ok', 'skipped', or 'error: <msg>'.
    """
    if out_path.exists():
        return "skipped"

    try:
        img_np = np.array(Image.open(img_path).convert("RGB"))

        # Some corruptions need minimum image size — pad if necessary
        h, w = img_np.shape[:2]
        pad_h = max(0, 32 - h)
        pad_w = max(0, 32 - w)
        if pad_h > 0 or pad_w > 0:
            img_np = np.pad(img_np, ((0, pad_h), (0, pad_w), (0, 0)), mode="reflect")

        corrupted = corrupt(img_np, corruption_name=corruption, severity=severity)
        Image.fromarray(corrupted.astype(np.uint8)).save(out_path, format="JPEG", quality=95)
        return "ok"

    except Exception as e:
        return f"error: {e}"


def generate_for_dataset(dataset: str, base_dir: Path, seed: int, corruptions_to_run: list = None):
    if corruptions_to_run is None:
        corruptions_to_run = CORRUPTION_TYPES

    print(f"\n{'=' * 64}")
    print(f"  Dataset : {dataset.upper()}")
    print(f"  Seed    : {seed}")
    print(f"  Types   : {len(corruptions_to_run)}  |  Severities : {len(SEVERITIES)}")
    print(f"  Total   : {len(corruptions_to_run) * len(SEVERITIES)} (corruption × severity) combinations")
    print(f"{'=' * 64}")

    set_seed(seed)

    # ── Image paths ────────────────────────────────────────────────────────────
    if dataset == "coco":
        image_paths = get_coco_image_paths(base_dir)
        out_root    = base_dir / "data" / "coco_c"
    else:
        image_paths = get_flickr30k_image_paths(base_dir)
        out_root    = base_dir / "data" / "flickr30k_c"

    if not image_paths:
        print(f"ERROR: No images found for {dataset}. Aborting.")
        return

    # ── Notes on slow / special corruptions ───────────────────────────────────
    print("\nNotes:")
    print("  • glass_blur   : very slow (O(n²) per pixel) — expected, not frozen")
    print("  • frost        : downloads texture on first run (needs internet once)")
    print("  • Total runtime: ~30-90 min for COCO on MacBook\n")

    stats      = {"ok": 0, "skipped": 0, "error": 0}
    error_log  = []
    start_time = time.time()

    combo_pbar = tqdm(
        total=len(corruptions_to_run) * len(SEVERITIES),
        desc="Combinations",
        unit="combo",
        position=0,
    )

    for corruption in corruptions_to_run:
        for severity in SEVERITIES:
            out_dir = out_root / corruption / f"severity_{severity}"
            out_dir.mkdir(parents=True, exist_ok=True)

            combo_pbar.set_description(f"{corruption:<22} | sev {severity}")

            img_pbar = tqdm(image_paths, desc="images", unit="img", position=1, leave=False)
            for img_path in img_pbar:
                out_path = out_dir / img_path.name
                result   = corrupt_single(img_path, out_path, corruption, severity)
                key      = result.split(":")[0]
                stats[key] += 1
                if key == "error":
                    error_log.append({"file": img_path.name, "corruption": corruption,
                                       "severity": severity, "msg": result})

            combo_pbar.update(1)

    combo_pbar.close()
    elapsed = time.time() - start_time

    # ── Manifest ───────────────────────────────────────────────────────────────
    manifest = {
        "dataset":          dataset,
        "seed":             seed,
        "corruption_types": corruptions_to_run,
        "severities":       SEVERITIES,
        "num_images":       len(image_paths),
        "stats":            stats,
        "errors":           error_log,
        "elapsed_seconds":  round(elapsed, 1),
        "generated_at":     time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    manifest_path = out_root / "manifest.json"
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    # ── Summary ────────────────────────────────────────────────────────────────
    print(f"\n{'─' * 64}")
    print(f"  Dataset  : {dataset.upper()}")
    print(f"  Time     : {elapsed / 60:.1f} min")
    print(f"  Generated: {stats['ok']}")
    print(f"  Skipped  : {stats['skipped']}  (already existed)")
    print(f"  Errors   : {stats['error']}")
    if error_log:
        print(f"\n  Error details saved in manifest: {manifest_path}")
    print(f"{'─' * 64}\n")


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Generate 15 Hendrycks image corruptions × 5 severities",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate_image_corruptions.py --dataset coco --seed 42
  python generate_image_corruptions.py --dataset flickr30k --seed 42
  python generate_image_corruptions.py --dataset both --seed 42

Collaborator: use --seed 123 instead of 42
        """
    )
    parser.add_argument(
        "--dataset", choices=["coco", "flickr30k", "both"], default="both",
        help="Which dataset to generate corruptions for (default: both)"
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed. Main researcher=42, Collaborator=123 (default: 42)"
    )
    parser.add_argument(
        "--base-dir", type=str, default=None,
        help="Project root directory (default: directory containing this script)"
    )
    parser.add_argument(
        "--corruption", type=str, default=None,
        help="Run a single corruption type only (for debugging/resuming)"
    )
    args = parser.parse_args()

    base_dir = Path(args.base_dir) if args.base_dir else Path(__file__).parent

    # Override corruption list if single corruption requested
    if args.corruption:
        if args.corruption not in CORRUPTION_TYPES:
            print(f"ERROR: Unknown corruption '{args.corruption}'")
            print(f"Valid options: {CORRUPTION_TYPES}")
            sys.exit(1)
        corruptions_to_run = [args.corruption]
        print(f"Running single corruption: {args.corruption}")
    else:
        corruptions_to_run = CORRUPTION_TYPES

    print(f"\nProject root : {base_dir}")
    print(f"Seed         : {args.seed}")
    print(f"Dataset(s)   : {args.dataset}")

    datasets = ["coco", "flickr30k"] if args.dataset == "both" else [args.dataset]

    for dataset in datasets:
        generate_for_dataset(dataset, base_dir, args.seed, corruptions_to_run)

    print("All done.")


if __name__ == "__main__":
    main()
