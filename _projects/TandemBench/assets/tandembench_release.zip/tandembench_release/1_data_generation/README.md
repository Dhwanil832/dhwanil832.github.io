# Stage 1 — Data generation

Produces the corrupted inputs the benchmark evaluates. Run this only if you are
rebuilding the evaluation records from scratch; [stage 4](../4_analysis/) ships the
records already.

## What to download

| Dataset | Split | Contents |
|---|---|---|
| MS-COCO | `val2017` | 5,000 images, 25,014 captions |
| Flickr30K | standard test | 1,000 images, 5,000 captions |

Both are publicly available from their original sources. Place them so that the
directory looks like:

```
data/
├── coco/images/val2017/          # 5,000 .jpg
├── coco/annotations/             # captions_val2017.json
├── flickr30k/images/             # 1,000 .jpg
└── flickr30k/annotations/
```

## Image corruptions

```bash
python generate_image_corruptions.py --dataset coco
python generate_image_corruptions.py --dataset flickr30k
```

Writes `data/<dataset>_c/<operator>/severity_<n>/`, one directory per operator per
severity — 16 operators × 5 severities. Fifteen are the standard ImageNet-C
corruptions; speckle noise comes from the extended set. Severity parameterisation is
the unmodified `imagecorruptions` default, so severity 1–5 carries its established
meaning.

**Corruption is deterministic and written to disk before any model runs.** The seed is
recorded in the generated `manifest.json`. Every model therefore sees byte-identical
inputs, and image corruption never repeats per-model.

Expect roughly 250 seconds per operator per dataset for all five severities over the
5,000-image COCO gallery, and about 8 GB for the full corrupted COCO set.

## Text perturbations

Text is perturbed at evaluation time rather than written to disk, since captions are
cheap to transform. The twelve operators live in `text_corruptions/`:

```python
from text_corruptions import corrupt_text
corrupt_text("A gray cat standing on top of a black car.", "char_swap", 5, seed=123)
```

Two properties matter when reading any severity-resolved result.

**Severity is not cumulative.** Each level is an independent draw at a higher rate, not
the previous level plus further edits. Severity 3 output does not contain severity 2's
edits.

**A higher rate need not change the output.** On a short caption two adjacent rates can
select the same positions — for a 42-character caption, `keyboard_typo` at 7% and 10%
can return identical strings. This is correct behaviour given the rate schedule, and it
is the same short-caption property that drives the screening results. For any figure
showing a severity ladder, `char_swap` gives a strictly monotone progression.
