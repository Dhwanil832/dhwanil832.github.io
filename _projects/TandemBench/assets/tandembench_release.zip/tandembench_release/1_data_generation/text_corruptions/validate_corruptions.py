"""
Validate the text corruption module.

- 100 hardcoded COCO-style captions
- Every corruption type × every severity (12 × 5 = 60 combinations)
- Outputs: validation_output.csv, summary table to stdout
- Metrics: CER (Character Error Rate), WER (Word Error Rate)

Usage:
    python -m text_corruptions.validate_corruptions
    # or
    python text_corruptions/validate_corruptions.py
"""

import csv
import os
import sys
import warnings

warnings.filterwarnings("ignore")

# Ensure project root is on path when run directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from text_corruptions import corrupt_text, ALL_CORRUPTION_TYPES, SURFACE_CORRUPTION_TYPES, SEMANTIC_CORRUPTION_TYPES

# ---------------------------------------------------------------------------
# 100 hardcoded COCO-style captions
# ---------------------------------------------------------------------------
CAPTIONS = [
    "A dog is running across the green field.",
    "Two people sitting on a bench near the lake.",
    "A red bicycle parked against a stone wall.",
    "A woman holding an umbrella in the rain.",
    "A cat sleeping on top of a wooden shelf.",
    "Several children playing on a playground.",
    "A man riding a horse through the forest.",
    "A large ship sailing on the open ocean.",
    "A group of friends eating at a restaurant.",
    "A black and white dog fetching a ball.",
    "A tall building reflected in the water.",
    "A young girl blowing out birthday candles.",
    "A pizza on a wooden cutting board.",
    "An airplane flying over the mountains.",
    "A street musician playing the guitar.",
    "A crowd of people walking on a busy street.",
    "A white cat sitting on a window sill.",
    "A boy jumping over a puddle of water.",
    "A couple walking along the beach at sunset.",
    "A bowl of fresh fruit on a kitchen counter.",
    "A dog lying under a park bench.",
    "A man in a suit reading a newspaper.",
    "A colorful kite flying in the blue sky.",
    "A child feeding ducks at a pond.",
    "A woman jogging through the park.",
    "Two cyclists riding along a mountain trail.",
    "A fire truck parked outside a building.",
    "A chef preparing food in a kitchen.",
    "A group of birds perched on a wire.",
    "A red and white boat docked at the pier.",
    "A dog playing with a yellow frisbee.",
    "An elderly man sitting on a park bench.",
    "A cat chasing a mouse in the garden.",
    "A blue motorcycle parked on the street.",
    "A woman watering plants in a greenhouse.",
    "A boy playing soccer in the backyard.",
    "A train passing through a mountain tunnel.",
    "Two dogs running on the beach.",
    "A girl painting a picture in the park.",
    "A man fishing from a wooden dock.",
    "A family having a picnic in the meadow.",
    "A red sports car driving on the highway.",
    "A woman reading a book under a tree.",
    "A group of penguins standing on the ice.",
    "A child building a sandcastle on the beach.",
    "A horse grazing in a green pasture.",
    "A man climbing a rocky mountain.",
    "Two women chatting over cups of coffee.",
    "A yellow taxi cab driving through the city.",
    "A dog sitting beside its owner on a couch.",
    "A baby playing with colorful plastic blocks.",
    "A surfer riding a large wave.",
    "A bird perched on a branch near the water.",
    "A woman cooking vegetables in a wok.",
    "A man pushing a shopping cart in a store.",
    "A child riding a bicycle with training wheels.",
    "A cat lying in a patch of sunlight.",
    "Two men playing chess in the park.",
    "A woman carrying a large bag on her shoulder.",
    "A deer standing at the edge of the forest.",
    "A group of tourists photographing a monument.",
    "A boy splashing in a swimming pool.",
    "A woman dancing in a colorful dress.",
    "A man mowing the lawn in the backyard.",
    "A dog jumping over a wooden fence.",
    "A girl feeding a giraffe at the zoo.",
    "Two people kayaking on a calm river.",
    "A man playing a violin on the street.",
    "A cat climbing a tall tree.",
    "A worker repairing a road with equipment.",
    "A woman walking her dog in the park.",
    "A group of students studying in a library.",
    "A red double-decker bus on a city street.",
    "A man hammering nails into a wooden board.",
    "A child looking through a telescope.",
    "Two birds fighting over a piece of bread.",
    "A woman picking flowers in a garden.",
    "A man carrying boxes up a flight of stairs.",
    "A dog splashing in a shallow stream.",
    "A teenager playing a video game.",
    "A couple dancing at an outdoor wedding.",
    "A woman sorting through clothes at a market.",
    "A man repairing a bicycle in the garage.",
    "A child drawing on the pavement with chalk.",
    "A dog waiting patiently by the front door.",
    "A man serving a tennis ball on a court.",
    "A woman photographing flowers in a field.",
    "A group of people watching a street performance.",
    "A cat drinking water from a bowl.",
    "A man rowing a boat on a mountain lake.",
    "A child petting a small rabbit.",
    "A woman working at a computer in an office.",
    "A group of cows grazing on a hillside.",
    "A man painting the exterior of a house.",
    "A dog catching a treat in mid-air.",
    "A woman swimming in an outdoor pool.",
    "A child laughing while riding a swing.",
    "A man grilling burgers at a backyard barbecue.",
    "A cat watching birds through a glass window.",
    "A man playing basketball alone in the driveway.",
]

assert len(CAPTIONS) == 100, f"Expected 100 captions, got {len(CAPTIONS)}"

SEVERITIES = [1, 2, 3, 4, 5]
OUTPUT_CSV = os.path.join(os.path.dirname(__file__), "..", "validation_output.csv")


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def _cer(original: str, corrupted: str) -> float:
    """Character Error Rate via edit distance."""
    orig_chars = list(original)
    corr_chars = list(corrupted)
    if not orig_chars:
        return 0.0
    dist = _edit_distance(orig_chars, corr_chars)
    return dist / len(orig_chars)


def _wer(original: str, corrupted: str) -> float:
    """Word Error Rate via edit distance on word tokens."""
    orig_words = original.split()
    corr_words = corrupted.split()
    if not orig_words:
        return 0.0
    dist = _edit_distance(orig_words, corr_words)
    return dist / len(orig_words)


def _edit_distance(a: list, b: list) -> int:
    """Standard dynamic-programming Levenshtein distance."""
    m, n = len(a), len(b)
    # Use two-row DP to save memory
    prev = list(range(n + 1))
    curr = [0] * (n + 1)
    for i in range(1, m + 1):
        curr[0] = i
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                curr[j] = prev[j - 1]
            else:
                curr[j] = 1 + min(prev[j], curr[j - 1], prev[j - 1])
        prev, curr = curr, prev
    return prev[n]


# ---------------------------------------------------------------------------
# Main validation loop
# ---------------------------------------------------------------------------

def run_validation(seed: int = 123) -> list[dict]:
    rows = []
    total = len(ALL_CORRUPTION_TYPES) * len(SEVERITIES) * len(CAPTIONS)
    done = 0

    for corruption_type in ALL_CORRUPTION_TYPES:
        for severity in SEVERITIES:
            cer_sum = wer_sum = 0.0
            for idx, original in enumerate(CAPTIONS):
                corrupted = corrupt_text(original, corruption_type, severity, seed=seed + idx)
                cer = _cer(original, corrupted)
                wer = _wer(original, corrupted)
                rows.append({
                    "caption_id": idx,
                    "corruption_type": corruption_type,
                    "severity": severity,
                    "original": original,
                    "corrupted": corrupted,
                    "CER": round(cer, 4),
                    "WER": round(wer, 4),
                })
                cer_sum += cer
                wer_sum += wer
                done += 1
                if done % 500 == 0:
                    pct = 100 * done / total
                    print(f"  [{pct:5.1f}%] {done}/{total} processed...", flush=True)

    return rows


def print_summary(rows: list[dict]) -> None:
    """Print a summary table: corruption_type × severity → mean CER, mean WER."""
    from collections import defaultdict

    stats: dict[tuple, list] = defaultdict(list)
    for r in rows:
        key = (r["corruption_type"], r["severity"])
        stats[key].append((r["CER"], r["WER"]))

    col_w = 24
    sev_w = 8

    header = f"{'Corruption Type':<{col_w}}"
    for sev in SEVERITIES:
        header += f"  sev={sev} CER/WER"
    print("\n" + "=" * (col_w + len(SEVERITIES) * 18))
    print("Validation Summary — mean CER / mean WER per (type, severity)")
    print("=" * (col_w + len(SEVERITIES) * 18))
    print(header)
    print("-" * (col_w + len(SEVERITIES) * 18))

    surface_types = set(SURFACE_CORRUPTION_TYPES)
    for group_label, group in [("SURFACE", SURFACE_CORRUPTION_TYPES), ("SEMANTIC", SEMANTIC_CORRUPTION_TYPES)]:
        print(f"\n  [{group_label}]")
        for ct in group:
            row_str = f"  {ct:<{col_w - 2}}"
            for sev in SEVERITIES:
                pairs = stats[(ct, sev)]
                mean_cer = sum(p[0] for p in pairs) / len(pairs)
                mean_wer = sum(p[1] for p in pairs) / len(pairs)
                row_str += f"  {mean_cer:.3f}/{mean_wer:.3f}  "
            print(row_str)

    print("=" * (col_w + len(SEVERITIES) * 18))

    # Sanity checks
    print("\nSanity checks:")
    all_pass = True
    for ct in ALL_CORRUPTION_TYPES:
        # CER at sev=5 should be > CER at sev=1 for most types
        sev1 = sum(r["CER"] for r in rows if r["corruption_type"] == ct and r["severity"] == 1) / 100
        sev5 = sum(r["CER"] for r in rows if r["corruption_type"] == ct and r["severity"] == 5) / 100
        ok = sev5 >= sev1
        status = "PASS" if ok else "WARN"
        if not ok:
            all_pass = False
        print(f"  [{status}] {ct}: CER sev1={sev1:.3f} <= sev5={sev5:.3f}")

    print()
    if all_pass:
        print("All sanity checks passed.")
    else:
        print("Some checks flagged — review WARN rows above.")


def main():
    print(f"Running validation over {len(CAPTIONS)} captions × "
          f"{len(ALL_CORRUPTION_TYPES)} corruption types × "
          f"{len(SEVERITIES)} severities = "
          f"{len(CAPTIONS) * len(ALL_CORRUPTION_TYPES) * len(SEVERITIES)} rows...")
    print(f"Seed: 123\n")

    rows = run_validation(seed=123)

    # Write CSV
    out_path = os.path.abspath(OUTPUT_CSV)
    fieldnames = ["caption_id", "corruption_type", "severity", "original", "corrupted", "CER", "WER"]
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nWrote {len(rows)} rows to: {out_path}")
    print_summary(rows)


if __name__ == "__main__":
    main()
