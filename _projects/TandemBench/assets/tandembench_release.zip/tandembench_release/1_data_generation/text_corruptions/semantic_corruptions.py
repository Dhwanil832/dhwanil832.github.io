"""
Semantic text corruptions.

5 types, severity 1–5:
  negation_insertion, attribute_swap, relation_swap,
  object_substitution, sentence_shuffle

Requires: spacy (en_core_web_sm), nltk (wordnet)
Install:
  pip install spacy nltk
  python -m spacy download en_core_web_sm
  python -c "import nltk; nltk.download('wordnet'); nltk.download('omw-1.4')"
"""

from __future__ import annotations

import random
import re

# ---------------------------------------------------------------------------
# Lazy imports — only load heavy deps when a function is called
# ---------------------------------------------------------------------------

_nlp = None


def _get_nlp():
    global _nlp
    if _nlp is None:
        try:
            import spacy
            _nlp = spacy.load('en_core_web_sm')
        except OSError:
            raise RuntimeError(
                "spaCy model not found. Run: python -m spacy download en_core_web_sm"
            )
    return _nlp


_wordnet = None


def _get_wordnet():
    global _wordnet
    if _wordnet is None:
        try:
            from nltk.corpus import wordnet
            _wordnet = wordnet
        except LookupError:
            import nltk
            nltk.download('wordnet', quiet=True)
            nltk.download('omw-1.4', quiet=True)
            from nltk.corpus import wordnet
            _wordnet = wordnet
    return _wordnet


# ---------------------------------------------------------------------------
# Word lists
# ---------------------------------------------------------------------------

COLOR_ATTRIBUTES = [
    'red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink',
    'black', 'white', 'gray', 'brown', 'silver', 'golden',
]

SIZE_ATTRIBUTES = [
    'large', 'small', 'tiny', 'huge', 'big', 'little', 'tall', 'short',
    'narrow', 'wide', 'thick', 'thin',
]

SPATIAL_RELATIONS = [
    'on', 'under', 'above', 'below', 'beside', 'near', 'next to',
    'in front of', 'behind', 'inside', 'outside', 'between', 'around',
    'across', 'against', 'along', 'through', 'over',
]

ALL_ATTRIBUTES = COLOR_ATTRIBUTES + SIZE_ATTRIBUTES

# Common nouns for object substitution fallback
COMMON_NOUNS = [
    'dog', 'cat', 'car', 'bike', 'tree', 'chair', 'table', 'bag',
    'hat', 'ball', 'bird', 'fish', 'boat', 'cup', 'box', 'book',
    'phone', 'lamp', 'flower', 'rock',
]

# Negation adverbs to insert
NEGATION_WORDS = ['not', 'never', "n't"]


# ---------------------------------------------------------------------------
# Severity → rate helpers
# ---------------------------------------------------------------------------

def _token_rate(severity: int) -> float:
    """Fraction of eligible tokens to corrupt."""
    return {1: 0.10, 2: 0.25, 3: 0.40, 4: 0.60, 5: 0.80}[severity]


def _sent_rate(severity: int) -> float:
    """Fraction of sentences to shuffle (sentence_shuffle)."""
    return {1: 0.20, 2: 0.35, 3: 0.50, 4: 0.65, 5: 0.80}[severity]


# ---------------------------------------------------------------------------
# Individual corruption functions
# ---------------------------------------------------------------------------

def _negation_insertion(text: str, severity: int, rng: random.Random) -> str:
    """Insert negation words after auxiliary/modal verbs."""
    nlp = _get_nlp()
    doc = nlp(text)
    rate = _token_rate(severity)
    tokens = [tok.text_with_ws for tok in doc]

    aux_tags = {'AUX', 'VERB'}
    aux_deps = {'aux', 'auxpass', 'ROOT'}

    inserted = []
    for tok in doc:
        inserted.append(tok.text_with_ws)
        if (
            tok.pos_ in aux_tags
            and tok.dep_ in aux_deps
            and rng.random() < rate
        ):
            neg = rng.choice(NEGATION_WORDS)
            ws = ' ' if not tok.whitespace_ else ''
            inserted[-1] = tok.text + ' ' + neg + tok.whitespace_

    result = ''.join(inserted)
    return result.strip()


def _attribute_swap(text: str, severity: int, rng: random.Random) -> str:
    """Replace color/size adjectives with different ones."""
    nlp = _get_nlp()
    doc = nlp(text)
    rate = _token_rate(severity)
    tokens = list(doc)
    result = [tok.text_with_ws for tok in tokens]

    for i, tok in enumerate(tokens):
        if tok.pos_ == 'ADJ' and rng.random() < rate:
            lower = tok.text.lower()
            if lower in COLOR_ATTRIBUTES:
                pool = [c for c in COLOR_ATTRIBUTES if c != lower]
            elif lower in SIZE_ATTRIBUTES:
                pool = [s for s in SIZE_ATTRIBUTES if s != lower]
            else:
                pool = ALL_ATTRIBUTES
            replacement = rng.choice(pool)
            # Preserve capitalisation
            if tok.text[0].isupper():
                replacement = replacement.capitalize()
            result[i] = replacement + tok.whitespace_

    return ''.join(result).strip()


def _relation_swap(text: str, severity: int, rng: random.Random) -> str:
    """Replace spatial prepositions with different ones."""
    rate = _token_rate(severity)
    # Match multi-word relations first, then single words
    sorted_relations = sorted(SPATIAL_RELATIONS, key=len, reverse=True)
    pattern = re.compile(
        r'\b(' + '|'.join(re.escape(r) for r in sorted_relations) + r')\b',
        flags=re.IGNORECASE,
    )

    def replacer(m: re.Match) -> str:
        if rng.random() < rate:
            original = m.group(0).lower()
            pool = [r for r in SPATIAL_RELATIONS if r != original]
            replacement = rng.choice(pool)
            if m.group(0)[0].isupper():
                replacement = replacement.capitalize()
            return replacement
        return m.group(0)

    return pattern.sub(replacer, text)


def _object_substitution(text: str, severity: int, rng: random.Random) -> str:
    """Replace common nouns using WordNet synonyms or a fallback list."""
    nlp = _get_nlp()
    wn = _get_wordnet()
    doc = nlp(text)
    rate = _token_rate(severity)
    result = [tok.text_with_ws for tok in doc]

    for i, tok in enumerate(doc):
        if tok.pos_ == 'NOUN' and rng.random() < rate:
            synsets = wn.synsets(tok.lemma_, pos=wn.NOUN)
            candidates: list[str] = []
            for syn in synsets:
                for lemma in syn.lemmas():
                    name = lemma.name().replace('_', ' ')
                    if name.lower() != tok.text.lower():
                        candidates.append(name)
            if not candidates:
                candidates = [n for n in COMMON_NOUNS if n != tok.text.lower()]

            if candidates:
                replacement = rng.choice(candidates)
                if tok.text[0].isupper():
                    replacement = replacement.capitalize()
                result[i] = replacement + tok.whitespace_

    return ''.join(result).strip()


def _sentence_shuffle(text: str, severity: int, rng: random.Random) -> str:
    """Shuffle sentence order within the caption."""
    # Split on sentence-ending punctuation
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    if len(sentences) < 2:
        # Fall back to phrase shuffling by comma/semicolon
        phrases = re.split(r'(?<=[,;])\s+', text.strip())
        if len(phrases) < 2:
            return text
        sentences = phrases

    rate = _sent_rate(severity)
    n_shuffle = max(1, int(len(sentences) * rate))
    indices = rng.sample(range(len(sentences)), min(n_shuffle * 2, len(sentences)))
    for i in range(0, len(indices) - 1, 2):
        sentences[indices[i]], sentences[indices[i + 1]] = (
            sentences[indices[i + 1]], sentences[indices[i]]
        )
    return ' '.join(sentences)


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_SEMANTIC_FUNCS = {
    'negation_insertion': _negation_insertion,
    'attribute_swap': _attribute_swap,
    'relation_swap': _relation_swap,
    'object_substitution': _object_substitution,
    'sentence_shuffle': _sentence_shuffle,
}

SEMANTIC_CORRUPTION_TYPES = list(_SEMANTIC_FUNCS.keys())


def corrupt_semantic(text: str, corruption_type: str, severity: int, seed: int = 42) -> str:
    """Apply a single semantic corruption to text."""
    if corruption_type not in _SEMANTIC_FUNCS:
        raise ValueError(
            f"Unknown semantic corruption: '{corruption_type}'. "
            f"Choose from: {SEMANTIC_CORRUPTION_TYPES}"
        )
    if severity not in range(1, 6):
        raise ValueError(f"Severity must be 1–5, got {severity}")
    rng = random.Random(seed)
    return _SEMANTIC_FUNCS[corruption_type](text, severity, rng)


def corrupt_semantic_batch(
    texts: list[str], corruption_type: str, severity: int, seed: int = 42
) -> list[str]:
    """Apply a semantic corruption to a list of texts."""
    if corruption_type not in _SEMANTIC_FUNCS:
        raise ValueError(
            f"Unknown semantic corruption: '{corruption_type}'. "
            f"Choose from: {SEMANTIC_CORRUPTION_TYPES}"
        )
    if severity not in range(1, 6):
        raise ValueError(f"Severity must be 1–5, got {severity}")
    fn = _SEMANTIC_FUNCS[corruption_type]
    return [fn(text, severity, random.Random(seed + i)) for i, text in enumerate(texts)]


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    samples = [
        "A dog is running on the green field.",
        "A red car parked beside a large tree.",
        "Two people sitting under a blue umbrella near the lake.",
    ]
    for ctype in SEMANTIC_CORRUPTION_TYPES:
        print(f"\n=== {ctype} ===")
        for sev in [1, 3, 5]:
            result = corrupt_semantic(samples[0], ctype, sev, seed=123)
            print(f"  sev={sev}: {result}")
