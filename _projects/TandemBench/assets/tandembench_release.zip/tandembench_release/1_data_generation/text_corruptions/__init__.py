"""
text_corruptions — surface and semantic text corruption module.

Public API (non-negotiable interface from collaborator spec):

    corrupt_text(text, corruption_type, severity, seed=42) -> str
    corrupt_batch(texts, corruption_type, severity, seed=42) -> list[str]

All 12 corruption types:
    Surface (7): keyboard_typo, ocr_error, char_swap, char_delete,
                 word_delete, word_shuffle, punctuation_noise
    Semantic (5): negation_insertion, attribute_swap, relation_swap,
                  object_substitution, sentence_shuffle
"""

from text_corruptions.surface_corruptions import (
    corrupt_surface,
    corrupt_surface_batch,
    SURFACE_CORRUPTION_TYPES,
)
from text_corruptions.semantic_corruptions import (
    corrupt_semantic,
    corrupt_semantic_batch,
    SEMANTIC_CORRUPTION_TYPES,
)

ALL_CORRUPTION_TYPES = SURFACE_CORRUPTION_TYPES + SEMANTIC_CORRUPTION_TYPES

_SURFACE_SET = set(SURFACE_CORRUPTION_TYPES)
_SEMANTIC_SET = set(SEMANTIC_CORRUPTION_TYPES)


def corrupt_text(text: str, corruption_type: str, severity: int, seed: int = 42) -> str:
    """
    Apply a single corruption to one text string.

    Args:
        text:            Input caption/sentence.
        corruption_type: One of the 12 corruption types.
        severity:        Integer 1–5 (1 = mildest, 5 = most aggressive).
        seed:            Random seed for reproducibility.

    Returns:
        Corrupted text string.
    """
    if corruption_type in _SURFACE_SET:
        return corrupt_surface(text, corruption_type, severity, seed)
    if corruption_type in _SEMANTIC_SET:
        return corrupt_semantic(text, corruption_type, severity, seed)
    raise ValueError(
        f"Unknown corruption type: '{corruption_type}'. "
        f"Choose from: {ALL_CORRUPTION_TYPES}"
    )


def corrupt_batch(
    texts: list[str], corruption_type: str, severity: int, seed: int = 42
) -> list[str]:
    """
    Apply a single corruption to a list of text strings.

    Each element gets an independently seeded RNG derived from seed+index,
    ensuring per-item reproducibility without inter-item correlation.

    Args:
        texts:           List of input captions/sentences.
        corruption_type: One of the 12 corruption types.
        severity:        Integer 1–5.
        seed:            Base random seed.

    Returns:
        List of corrupted text strings (same length as input).
    """
    if corruption_type in _SURFACE_SET:
        return corrupt_surface_batch(texts, corruption_type, severity, seed)
    if corruption_type in _SEMANTIC_SET:
        return corrupt_semantic_batch(texts, corruption_type, severity, seed)
    raise ValueError(
        f"Unknown corruption type: '{corruption_type}'. "
        f"Choose from: {ALL_CORRUPTION_TYPES}"
    )


__all__ = [
    'corrupt_text',
    'corrupt_batch',
    'ALL_CORRUPTION_TYPES',
    'SURFACE_CORRUPTION_TYPES',
    'SEMANTIC_CORRUPTION_TYPES',
]
