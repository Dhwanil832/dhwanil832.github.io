"""
Surface-level text corruptions.

7 types, severity 1–5:
  keyboard_typo, ocr_error, char_swap, char_delete,
  word_delete, word_shuffle, punctuation_noise
"""

import random
import string

# ---------------------------------------------------------------------------
# Keyboard adjacency map (QWERTY)
# ---------------------------------------------------------------------------
KEYBOARD_ADJACENT: dict[str, list[str]] = {
    'q': ['w', 'a', 's'], 'w': ['q', 'e', 'a', 's', 'd'],
    'e': ['w', 'r', 's', 'd', 'f'], 'r': ['e', 't', 'd', 'f', 'g'],
    't': ['r', 'y', 'f', 'g', 'h'], 'y': ['t', 'u', 'g', 'h', 'j'],
    'u': ['y', 'i', 'h', 'j', 'k'], 'i': ['u', 'o', 'j', 'k', 'l'],
    'o': ['i', 'p', 'k', 'l'], 'p': ['o', 'l'],
    'a': ['q', 'w', 's', 'z', 'x'], 's': ['a', 'w', 'e', 'd', 'x', 'z'],
    'd': ['s', 'e', 'r', 'f', 'c', 'x'], 'f': ['d', 'r', 't', 'g', 'v', 'c'],
    'g': ['f', 't', 'y', 'h', 'b', 'v'], 'h': ['g', 'y', 'u', 'j', 'n', 'b'],
    'j': ['h', 'u', 'i', 'k', 'm', 'n'], 'k': ['j', 'i', 'o', 'l', 'm'],
    'l': ['k', 'o', 'p'], 'z': ['a', 's', 'x'], 'x': ['z', 's', 'd', 'c'],
    'c': ['x', 'd', 'f', 'v'], 'v': ['c', 'f', 'g', 'b'],
    'b': ['v', 'g', 'h', 'n'], 'n': ['b', 'h', 'j', 'm'],
    'm': ['n', 'j', 'k'],
}

# ---------------------------------------------------------------------------
# OCR confusion pairs
# ---------------------------------------------------------------------------
OCR_SUBSTITUTIONS: dict[str, list[str]] = {
    'o': ['0', 'O'], '0': ['o', 'O'], 'l': ['1', 'I', '|'],
    '1': ['l', 'I', '|'], 'I': ['l', '1', '|'], 'i': ['!', '1'],
    'e': ['3'], '3': ['e'], 'a': ['@'], 's': ['5', '$'],
    '5': ['s', 'S'], 'S': ['5', '$'], 'g': ['9', 'q'],
    '9': ['g'], 'b': ['6'], '6': ['b'], 'z': ['2'], '2': ['z'],
    'h': ['n'], 'n': ['h', 'm'], 'm': ['n'], 'u': ['v'], 'v': ['u'],
    'c': ['e'], 'rn': ['m'], 'cl': ['d'],
}

PUNCTUATION_CHARS = list('.,;:!?-–—\'\"()')


def _char_rate(severity: int) -> float:
    """Map severity 1–5 to a character-level corruption rate."""
    return {1: 0.01, 2: 0.03, 3: 0.05, 4: 0.07, 5: 0.10}[severity]


def _word_rate(severity: int) -> float:
    """Map severity 1–5 to a word-level corruption rate."""
    return {1: 0.05, 2: 0.10, 3: 0.20, 4: 0.30, 5: 0.40}[severity]


def _shuffle_rate(severity: int) -> float:
    return {1: 0.10, 2: 0.20, 3: 0.35, 4: 0.50, 5: 0.60}[severity]


def _punct_rate(severity: int) -> float:
    return {1: 0.05, 2: 0.10, 3: 0.20, 4: 0.30, 5: 0.40}[severity]


# ---------------------------------------------------------------------------
# Individual corruption functions
# ---------------------------------------------------------------------------

def _keyboard_typo(text: str, severity: int, rng: random.Random) -> str:
    rate = _char_rate(severity)
    chars = list(text)
    for i, ch in enumerate(chars):
        if rng.random() < rate:
            lower = ch.lower()
            if lower in KEYBOARD_ADJACENT:
                replacement = rng.choice(KEYBOARD_ADJACENT[lower])
                chars[i] = replacement.upper() if ch.isupper() else replacement
    return ''.join(chars)


def _ocr_error(text: str, severity: int, rng: random.Random) -> str:
    rate = _char_rate(severity)
    # Multi-char substitutions first (e.g. 'rn' -> 'm')
    multi = {k: v for k, v in OCR_SUBSTITUTIONS.items() if len(k) > 1}
    single = {k: v for k, v in OCR_SUBSTITUTIONS.items() if len(k) == 1}
    for src, targets in multi.items():
        if src in text and rng.random() < rate:
            text = text.replace(src, rng.choice(targets), 1)
    chars = list(text)
    for i, ch in enumerate(chars):
        if rng.random() < rate and ch in single:
            chars[i] = rng.choice(single[ch])
    return ''.join(chars)


def _char_swap(text: str, severity: int, rng: random.Random) -> str:
    rate = _char_rate(severity)
    chars = list(text)
    i = 0
    while i < len(chars) - 1:
        if rng.random() < rate:
            chars[i], chars[i + 1] = chars[i + 1], chars[i]
            i += 2  # skip the swapped pair
        else:
            i += 1
    return ''.join(chars)


def _char_delete(text: str, severity: int, rng: random.Random) -> str:
    rate = _char_rate(severity)
    return ''.join(ch for ch in text if rng.random() >= rate)


def _word_delete(text: str, severity: int, rng: random.Random) -> str:
    rate = _word_rate(severity)
    words = text.split()
    kept = [w for w in words if rng.random() >= rate]
    # Always keep at least one word
    if not kept and words:
        kept = [rng.choice(words)]
    return ' '.join(kept)


def _word_shuffle(text: str, severity: int, rng: random.Random) -> str:
    rate = _shuffle_rate(severity)
    words = text.split()
    if len(words) < 2:
        return text
    n_shuffle = max(1, int(len(words) * rate))
    indices = rng.sample(range(len(words)), min(n_shuffle * 2, len(words)))
    # Swap pairs of sampled indices
    for i in range(0, len(indices) - 1, 2):
        words[indices[i]], words[indices[i + 1]] = (
            words[indices[i + 1]], words[indices[i]]
        )
    return ' '.join(words)


def _punctuation_noise(text: str, severity: int, rng: random.Random) -> str:
    rate = _punct_rate(severity)
    words = text.split()
    result = []
    for word in words:
        if rng.random() < rate:
            action = rng.choice(['add', 'remove'])
            if action == 'add':
                punct = rng.choice(PUNCTUATION_CHARS)
                if rng.random() < 0.5:
                    word = punct + word
                else:
                    word = word + punct
            else:
                # Remove trailing/leading punctuation if present
                word = word.strip(''.join(PUNCTUATION_CHARS))
        result.append(word)
    return ' '.join(result)


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_SURFACE_FUNCS = {
    'keyboard_typo': _keyboard_typo,
    'ocr_error': _ocr_error,
    'char_swap': _char_swap,
    'char_delete': _char_delete,
    'word_delete': _word_delete,
    'word_shuffle': _word_shuffle,
    'punctuation_noise': _punctuation_noise,
}

SURFACE_CORRUPTION_TYPES = list(_SURFACE_FUNCS.keys())


def corrupt_surface(text: str, corruption_type: str, severity: int, seed: int = 42) -> str:
    """Apply a single surface corruption to text."""
    if corruption_type not in _SURFACE_FUNCS:
        raise ValueError(
            f"Unknown surface corruption: '{corruption_type}'. "
            f"Choose from: {SURFACE_CORRUPTION_TYPES}"
        )
    if severity not in range(1, 6):
        raise ValueError(f"Severity must be 1–5, got {severity}")
    rng = random.Random(seed)
    return _SURFACE_FUNCS[corruption_type](text, severity, rng)


def corrupt_surface_batch(
    texts: list[str], corruption_type: str, severity: int, seed: int = 42
) -> list[str]:
    """Apply a surface corruption to a list of texts."""
    if corruption_type not in _SURFACE_FUNCS:
        raise ValueError(
            f"Unknown surface corruption: '{corruption_type}'. "
            f"Choose from: {SURFACE_CORRUPTION_TYPES}"
        )
    if severity not in range(1, 6):
        raise ValueError(f"Severity must be 1–5, got {severity}")
    fn = _SURFACE_FUNCS[corruption_type]
    return [fn(text, severity, random.Random(seed + i)) for i, text in enumerate(texts)]


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    samples = [
        "A dog is running across the green field.",
        "Two people sitting on a bench near the lake.",
        "A red bicycle parked against a stone wall.",
    ]
    for ctype in SURFACE_CORRUPTION_TYPES:
        print(f"\n=== {ctype} ===")
        for sev in [1, 3, 5]:
            result = corrupt_surface(samples[0], ctype, sev, seed=123)
            print(f"  sev={sev}: {result}")
