# Stage 3 — Adaptation and restoration

Two families of intervention applied to jointly corrupted inputs: test-time adaptation,
which modifies the model or its representations, and input restoration, which repairs
the inputs before retrieval.

## Test-time adaptation

The eight general-suite methods live in the harness at
[`../2_evaluation/evaluate/tta.py`](../2_evaluation/evaluate/tta.py) and are selected
per run:

```bash
python ../2_evaluation/evaluate.py --model evaclip_vit_l14 --dataset coco --path 3 --tta TENT
```

| Method | What it modifies |
|---|---|
| Tandem-Aug (internal ID: `TTA-Aug`) | nothing — augment and average image embeddings |
| QueryExpansion | nothing — refines the query from its neighbours |
| FeatureWhitening | nothing — closed-form whitening of gallery features |
| Tandem-Align (internal ID: `PromptAlign`) | nothing — closed-form feature-statistic alignment |
| TENT | LayerNorm affine parameters |
| MEMO | all parameters, per image |
| TPT / DiffTPT | prompt embeddings |

`TTA-Aug` and `PromptAlign` are retained as legacy internal identifiers in the
evaluation records and command-line dispatch so that the released records remain
reproducible. In the paper, these study procedures are named **Tandem-Aug** and
**Tandem-Align**, respectively.

Tandem-Align is a closed-form feature-statistic alignment procedure. Text features
are shifted and scaled to match the image-feature mean and standard deviation, then
re-normalized. It performs no prompt optimization and no parameter updates.

Exact hyperparameters for every method are tabulated in
`4_analysis/tables/impl.csv`, generated from the implementations so they cannot drift.

**Coverage differs by method, and the pooled results are not a leaderboard.** The four
gradient-based methods were run on a single checkpoint; the closed-form methods on
seven. Effects must be read within a method against that method's own no-adaptation
control, never across methods. `4_analysis/tables/coverage.csv` states the coverage of
every experiment, and `tables/tta_controlled.csv` gives the like-for-like comparison of
all eight methods on one backbone.

Rows in which a method returns output bit-identical to its own control are recorded as
no-ops and excluded, so a method is never credited with an effect on a model it did not
modify.

## Input restoration

```bash
cd restoration
python runner.py            # full queue
python runner.py --smoke    # one configuration, quick check
```

Four arms per condition: no restoration, restore the image, restore the caption,
restore both. Image restorers are classical and per-corruption — non-local means for
gaussian noise, unsharp masking for motion blur, dark-channel-prior dehazing for fog,
edge-preserving smoothing for JPEG artifacts. Text restoration is SymSpell compound
correction.

The restorers are deliberately classical rather than learned. They establish how much
joint-corruption loss is recoverable by off-the-shelf preprocessing before any
restoration model is trained; they do not bound what a learned restorer could achieve.
Semantic corruptions pass through the spelling corrector unchanged, which is why that
arm *loses* accuracy on object substitution and word deletion.

Restored images are cached to disk and shared across models, so the expensive pass runs
once.

## External methods

TCR is used at its authors' released parameter scope and defaults. It is not
redistributed here; the release records the upstream source and the settings applied.
