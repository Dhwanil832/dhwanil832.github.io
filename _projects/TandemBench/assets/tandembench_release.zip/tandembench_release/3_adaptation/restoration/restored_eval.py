"""
Restoration Evaluation — does input repair beat model adaptation?

For each joint-corruption config (img_corr × txt_corr × severity), four arms:

    none         corrupted image  + corrupted text     (reference)
    RestoreImg   restored  image  + corrupted text
    RestoreTxt   corrupted image  + corrected text
    RestoreBoth  restored  image  + corrected text

The four arms mirror the modality-recovery analysis (which predicted
fix-image ≈ 8.9pp vs fix-text ≈ 6.8pp with oracle-clean inputs); this
experiment measures how much of that oracle recovery real restorers achieve.

Grid matches tcr_bench: 4 image × 3 text corruptions × severities {1,3,5}.
Restored images are cached under restored_data/ (one-time, shared by models).

CSV: model, dataset, path, corruption_type, severity, direction,
     R@1, R@5, R@10, TTA_method, seed          (path = "restore_eval",
     TTA_method = arm name)

Usage:
    python restored_eval.py --model clip_vitl14 --dataset coco
    python restored_eval.py --model clip_vitl14 --smoke
    python runner.py                                    # default model set
"""

import argparse
import csv
import os
import sys
import time
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch

from evaluate.dataset import load_dataset, check_corrupted_images_exist, flatten_captions, DATA_DIR
from evaluate.models import load_model, get_device, ALL_MODEL_KEYS
from evaluate.retrieval import load_images_from_paths, recall_at_k
from restore import restore_image_dir, correct_texts
from text_corruptions import corrupt_batch

SEED = 123

IMG_SUBSET = ["gaussian_noise", "motion_blur", "fog", "jpeg_compression"]
TXT_SUBSET = ["keyboard_typo", "word_delete", "object_substitution"]
SEVERITIES = [1, 3, 5]
ARMS = ["none", "RestoreImg", "RestoreTxt", "RestoreBoth"]

BASE = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = os.path.join(BASE, "results")
RESTORED_DIR = os.path.join(BASE, "restored_data")

CSV_FIELDS = ["model", "dataset", "path", "corruption_type", "severity",
              "direction", "R@1", "R@5", "R@10", "TTA_method", "seed"]


def _result_path(model_key, dataset):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    return os.path.join(RESULTS_DIR, f"restore_{model_key}_{dataset}.csv")


def _load_done(csv_path):
    done = set()
    if not os.path.exists(csv_path):
        return done
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            done.add((row["corruption_type"], int(row["severity"]),
                      row["direction"], row["TTA_method"]))
    return done


def _append(csv_path, rows):
    header = not os.path.exists(csv_path) or os.path.getsize(csv_path) == 0
    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if header:
            w.writeheader()
        w.writerows(rows)


def _rows(model_key, dataset, label, sev, recall, arm):
    return [{"model": model_key, "dataset": dataset, "path": "restore_eval",
             "corruption_type": label, "severity": sev, "direction": d,
             "R@1": recall[d]["R@1"], "R@5": recall[d]["R@5"], "R@10": recall[d]["R@10"],
             "TTA_method": arm, "seed": SEED} for d in ("I2T", "T2I")]


def get_restored_paths(dataset, img_corr, sev, image_paths, verbose=True):
    """Restore the corrupted image dir (cached) and remap paths into it."""
    sub = "coco_c" if dataset == "coco" else "flickr30k_c"
    src_dir = os.path.join(DATA_DIR, sub, img_corr, f"severity_{sev}")
    dst_dir = os.path.join(RESTORED_DIR, dataset, img_corr, f"severity_{sev}")
    if verbose:
        print(f"  restoring {img_corr} sev={sev} (cached after first run)...", flush=True)
    t0 = time.time()
    restore_image_dir(src_dir, dst_dir, img_corr, verbose=verbose)
    if verbose:
        print(f"  restoration ready in {time.time()-t0:.0f}s", flush=True)
    return [os.path.join(dst_dir, os.path.basename(p)) for p in image_paths]


def run_model(model_key, dataset, smoke=False, device=None, verbose=True):
    csv_path = _result_path(model_key, dataset)
    done = _load_done(csv_path)

    device = torch.device(device) if device else get_device()
    if verbose:
        print(f"\n{'='*60}\nModel: {model_key} | Dataset: {dataset} | Device: {device}"
              f"\nResults: {csv_path}\n{'='*60}", flush=True)

    wrapper = load_model(model_key, device)

    img_list = IMG_SUBSET[:1] if smoke else IMG_SUBSET
    txt_list = TXT_SUBSET[:1] if smoke else TXT_SUBSET
    sev_list = [3] if smoke else SEVERITIES

    for img_corr in img_list:
        for sev in sev_list:
            if not check_corrupted_images_exist(dataset, img_corr, sev):
                if verbose:
                    print(f"  SKIP (images missing): {img_corr} sev={sev}")
                continue

            labels = [f"{img_corr}+{t}" for t in txt_list]
            if all((lbl, sev, d, a) in done
                   for lbl in labels for d in ("I2T", "T2I") for a in ARMS):
                if verbose:
                    print(f"  SKIP (done): {img_corr} sev={sev}")
                continue

            if verbose:
                print(f"\n[{img_corr} sev={sev}]", flush=True)

            # Corrupted images → features
            image_paths, captions, _ = load_dataset(dataset, img_corr, sev)
            pil_corr, missing = load_images_from_paths(image_paths, wrapper.preprocess, verbose=False)
            if len(missing) > len(image_paths) * 0.5:
                print("  WARN: >50% images missing, skipping.")
                continue
            flat_clean, caption_to_img = flatten_captions(captions)

            # Restored images → features (restoration cached on disk)
            restored_paths = get_restored_paths(dataset, img_corr, sev, image_paths, verbose)
            pil_rest, _ = load_images_from_paths(restored_paths, wrapper.preprocess, verbose=False)

            with torch.no_grad():
                feats_img_corr = wrapper.encode_images(pil_corr)
                feats_img_rest = wrapper.encode_images(pil_rest)

            for txt_corr in txt_list:
                label = f"{img_corr}+{txt_corr}"
                if all((label, sev, d, a) in done for d in ("I2T", "T2I") for a in ARMS):
                    continue

                caps_corr = corrupt_batch(flat_clean, txt_corr, sev, seed=SEED + sev)
                caps_fixed = correct_texts(caps_corr)

                with torch.no_grad():
                    feats_txt_corr = wrapper.encode_texts(caps_corr)
                    feats_txt_fixed = wrapper.encode_texts(caps_fixed)

                arm_feats = {
                    "none":        (feats_img_corr, feats_txt_corr),
                    "RestoreImg":  (feats_img_rest, feats_txt_corr),
                    "RestoreTxt":  (feats_img_corr, feats_txt_fixed),
                    "RestoreBoth": (feats_img_rest, feats_txt_fixed),
                }

                if verbose:
                    print(f"  {label}", flush=True)
                for arm, (fi, ft) in arm_feats.items():
                    if all((label, sev, d, arm) in done for d in ("I2T", "T2I")):
                        continue
                    rec = recall_at_k(fi, ft, caption_to_img)
                    _append(csv_path, _rows(model_key, dataset, label, sev, rec, arm))
                    done.update((label, sev, d, arm) for d in ("I2T", "T2I"))
                    if verbose:
                        print(f"    {arm:<12} I2T R@1={rec['I2T']['R@1']:.2f}  "
                              f"T2I R@1={rec['T2I']['R@1']:.2f}", flush=True)

    if verbose:
        print(f"\nDone: {model_key} / {dataset}", flush=True)


def main():
    p = argparse.ArgumentParser(description="Restoration evaluation — input repair vs model adaptation")
    p.add_argument("--model",   default="clip_vitl14", choices=ALL_MODEL_KEYS)
    p.add_argument("--dataset", default="coco", choices=["coco", "flickr30k"])
    p.add_argument("--smoke",   action="store_true")
    p.add_argument("--device",  default=None)
    args = p.parse_args()
    run_model(args.model, args.dataset, smoke=args.smoke, device=args.device)


if __name__ == "__main__":
    main()
