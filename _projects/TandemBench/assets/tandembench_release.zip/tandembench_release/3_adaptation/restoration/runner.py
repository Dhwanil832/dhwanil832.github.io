#!/usr/bin/env python3
"""
Restoration Runner — 5 representative models spanning the coupling range.

Usage:
    python runner.py            # full queue
    python runner.py --smoke    # 1 config on the first model (~10 min)
"""

import argparse
import subprocess
import sys
import os
import time

MODELS = [
    "clip_vitb32",       # small, subadditive
    "clip_vitl14",       # subadditive
    "metaclip_vitl14",   # ≈ additive
    "evaclip_vitl14",    # mildly superadditive
    "siglip_so400m14",   # superadditive
]

DATASETS = ["coco"]


def run(model, dataset, smoke=False):
    print(f"\n{'='*60}\n  {model} / {dataset}  started {time.strftime('%H:%M:%S')}\n{'='*60}", flush=True)
    cmd = [sys.executable, "restored_eval.py", "--model", model, "--dataset", dataset]
    if smoke:
        cmd.append("--smoke")
    result = subprocess.run(cmd, cwd=os.path.dirname(os.path.abspath(__file__)))
    print(f"\n  {model} / {dataset} — {'DONE' if result.returncode == 0 else f'FAILED ({result.returncode})'}", flush=True)
    return result.returncode


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--smoke", action="store_true")
    args = p.parse_args()

    if args.smoke:
        run(MODELS[0], DATASETS[0], smoke=True)
        sys.exit(0)

    failed = []
    for model in MODELS:
        for dataset in DATASETS:
            if run(model, dataset) != 0:
                failed.append(f"{model}/{dataset}")

    print(f"\n{'='*60}\nALL DONE — {len(MODELS)*len(DATASETS)-len(failed)}/{len(MODELS)*len(DATASETS)} succeeded")
    if failed:
        print(f"Failed: {failed}")
    print("=" * 60)
