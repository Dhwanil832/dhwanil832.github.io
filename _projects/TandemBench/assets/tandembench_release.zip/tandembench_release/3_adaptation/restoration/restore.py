"""
Input restoration for the corruption benchmark.

Image side — per-corruption classical restorers (run out of the box):
    gaussian_noise    → non-local means denoising
    motion_blur       → unsharp masking (documented-weak blind-deblur baseline)
    fog               → dark-channel-prior dehazing
    jpeg_compression  → edge-preserving artifact smoothing

A learned all-in-one model (PromptIR / AirNet class) can be plugged in by
implementing `LearnedRestorer.restore` and passing --learned; the classical
functions then serve as the ablation baseline.

Text side — SymSpell compound spelling correction (surface corruptions).
Semantic corruptions (object_substitution etc.) are NOT correctable by a
spellchecker; corrected text for those passes through unchanged, which is
itself an informative arm (restoration has a text-side ceiling).

Restored images are cached to disk under restored_data/ so the expensive
pass happens once and is shared across all models.
"""

import os

import cv2
import numpy as np
from PIL import Image

# ── Image restorers (classical, per-corruption) ──────────────────────────────

def _denoise(img: np.ndarray) -> np.ndarray:
    return cv2.fastNlMeansDenoisingColored(img, None, h=8, hColor=8,
                                           templateWindowSize=7, searchWindowSize=21)


def _sharpen(img: np.ndarray) -> np.ndarray:
    blur = cv2.GaussianBlur(img, (0, 0), sigmaX=2.0)
    return cv2.addWeighted(img, 1.6, blur, -0.6, 0)


def _dehaze(img: np.ndarray, omega=0.85, t_min=0.15, radius=7) -> np.ndarray:
    """Dark-channel-prior dehazing (He et al., simplified)."""
    f = img.astype(np.float32) / 255.0
    dark = cv2.erode(f.min(axis=2), np.ones((2 * radius + 1, 2 * radius + 1)))
    # Atmospheric light: mean of the brightest 0.1% dark-channel pixels
    n = max(1, int(dark.size * 0.001))
    idx = np.unravel_index(np.argsort(dark.ravel())[-n:], dark.shape)
    A = f[idx].max(axis=0).clip(0.5, 1.0)
    t = 1.0 - omega * cv2.erode((f / A).min(axis=2),
                                np.ones((2 * radius + 1, 2 * radius + 1)))
    t = cv2.GaussianBlur(t, (0, 0), sigmaX=radius).clip(t_min, 1.0)[..., None]
    out = (f - A) / t + A
    return (out.clip(0, 1) * 255).astype(np.uint8)


def _deartifact(img: np.ndarray) -> np.ndarray:
    return cv2.edgePreservingFilter(img, flags=cv2.RECURS_FILTER,
                                    sigma_s=12, sigma_r=0.08)


CLASSICAL_RESTORERS = {
    "gaussian_noise":   _denoise,
    "motion_blur":      _sharpen,
    "fog":              _dehaze,
    "jpeg_compression": _deartifact,
}


class LearnedRestorer:
    """Integration point for a learned all-in-one restoration model.

    Implement restore(img_bgr: np.ndarray) -> np.ndarray and load weights in
    __init__; then pass --learned to restored_eval.py / runner.py.
    """

    def __init__(self, device="cuda"):
        raise NotImplementedError(
            "Plug in PromptIR/AirNet weights here; classical restorers run by default."
        )

    def restore(self, img_bgr: np.ndarray) -> np.ndarray:
        raise NotImplementedError


def restore_image_dir(
    src_dir: str,
    dst_dir: str,
    corruption: str,
    learned=None,
    verbose: bool = True,
) -> str:
    """Restore every image in src_dir into dst_dir (cached: skips if complete)."""
    os.makedirs(dst_dir, exist_ok=True)
    src_files = sorted(f for f in os.listdir(src_dir) if f.lower().endswith((".jpg", ".png", ".jpeg")))
    done_files = set(os.listdir(dst_dir))
    todo = [f for f in src_files if f not in done_files]
    if not todo:
        return dst_dir

    fn = (learned.restore if learned is not None
          else CLASSICAL_RESTORERS.get(corruption))
    if fn is None:
        raise ValueError(f"No restorer for corruption {corruption!r}")

    for i, fname in enumerate(todo):
        img = cv2.imread(os.path.join(src_dir, fname), cv2.IMREAD_COLOR)
        if img is None:
            continue
        out = fn(img)
        cv2.imwrite(os.path.join(dst_dir, fname), out, [cv2.IMWRITE_JPEG_QUALITY, 95])
        if verbose and (i + 1) % 1000 == 0:
            print(f"    restored {i+1}/{len(todo)}", flush=True)
    return dst_dir


# ── Text correction ──────────────────────────────────────────────────────────

_SYM = None


def _get_symspell():
    global _SYM
    if _SYM is None:
        from symspellpy import SymSpell
        import importlib.resources
        _SYM = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)
        with importlib.resources.path(
            "symspellpy", "frequency_dictionary_en_82_765.txt"
        ) as dict_path:
            _SYM.load_dictionary(str(dict_path), term_index=0, count_index=1)
    return _SYM


def correct_texts(texts: list[str]) -> list[str]:
    """SymSpell compound correction. Surface typos get fixed; semantic
    corruptions pass through mostly unchanged (documented ceiling)."""
    sym = _get_symspell()
    out = []
    for t in texts:
        suggestions = sym.lookup_compound(t, max_edit_distance=2,
                                          transfer_casing=True)
        out.append(suggestions[0].term if suggestions else t)
    return out
