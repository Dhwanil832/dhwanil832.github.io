"""
Dataset loaders for COCO and Flickr30k.

COCO:      uses captions_index.json + val2017 (5000 images) — matches coco_c
Flickr30k: uses Karpathy test split (1000 images) — matches flickr30k_c

Returns image paths and aligned caption lists for retrieval evaluation.
For Path 3: images come from coco_c / flickr30k_c corrupted folders.
            captions are corrupted on-the-fly by the text_corruptions module.
"""

import json
import os
from typing import Optional

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")


def _load_coco_val2017() -> tuple[list[int], list[list[str]]]:
    """
    Load COCO val2017 image IDs and captions from captions_index.json.

    Returns:
        image_ids: list of N unique image IDs (order matches captions_index insertion order)
        captions:  list of N lists, each with all captions for that image
    """
    ann_path = os.path.join(DATA_DIR, "coco", "annotations", "captions_index.json")
    with open(ann_path) as f:
        raw = json.load(f)  # list of {image_id, caption}

    seen = {}  # image_id -> index
    image_ids = []
    captions = []
    for item in raw:
        iid = item["image_id"]
        if iid not in seen:
            seen[iid] = len(image_ids)
            image_ids.append(iid)
            captions.append([])
        captions[seen[iid]].append(item["caption"])

    return image_ids, captions


def _load_karpathy_flickr30k() -> tuple[list[str], list[list[str]]]:
    """
    Load Flickr30k Karpathy test split (1000 images).

    Returns:
        filenames: list of N image filenames
        captions:  list of N lists of caption strings
    """
    path = os.path.join(DATA_DIR, "flickr30k", "annotations", "karpathy_flickr30k_test.json")
    with open(path) as f:
        data = json.load(f)
    filenames = []
    captions = []
    for img in data["images"]:
        filenames.append(img["filename"])
        sents = img.get("sentences", [])
        caps = [s["raw"] if isinstance(s, dict) else s for s in sents]
        captions.append(caps)
    return filenames, captions


def load_dataset(
    dataset: str,
    img_corruption: Optional[str] = None,
    severity: Optional[int] = None,
) -> tuple[list[str], list[list[str]], list[int]]:
    """
    Load image paths and captions for retrieval evaluation.

    Args:
        dataset:        'coco' or 'flickr30k'
        img_corruption: image corruption type (e.g. 'gaussian_noise'), or None for clean
        severity:       severity level 1–5, or None for clean

    Returns:
        image_paths:  list of N image file paths
        captions:     list of N lists, each with caption strings for that image
        image_ids:    list of N integer image indices (0-based position, used for GT matching)
    """
    if dataset == "coco":
        image_ids_raw, captions = _load_coco_val2017()

        if img_corruption is None or severity is None:
            img_dir = os.path.join(DATA_DIR, "coco", "images", "val2017")
        else:
            img_dir = os.path.join(DATA_DIR, "coco_c", img_corruption, f"severity_{severity}")

        image_paths = [os.path.join(img_dir, f"{iid:012d}.jpg") for iid in image_ids_raw]
        image_ids = list(range(len(image_ids_raw)))  # 0-based positional index for GT

    elif dataset == "flickr30k":
        filenames, captions = _load_karpathy_flickr30k()

        if img_corruption is None or severity is None:
            img_dir = os.path.join(DATA_DIR, "flickr30k", "images", "flickr30k-images")
        else:
            img_dir = os.path.join(DATA_DIR, "flickr30k_c", img_corruption, f"severity_{severity}")

        image_paths = [os.path.join(img_dir, fname) for fname in filenames]
        image_ids = list(range(len(filenames)))

    else:
        raise ValueError(f"Unknown dataset: {dataset!r}. Choose 'coco' or 'flickr30k'.")

    return image_paths, captions, image_ids


def flatten_captions(captions: list[list[str]]) -> tuple[list[str], list[int]]:
    """
    Flatten N × K captions into a flat list with image index mapping.

    Returns:
        flat_captions:  flat list of all captions
        caption_to_img: flat_captions[i] belongs to image caption_to_img[i]
    """
    flat = []
    mapping = []
    for img_idx, caps in enumerate(captions):
        for cap in caps:
            flat.append(cap)
            mapping.append(img_idx)
    return flat, mapping


def check_corrupted_images_exist(dataset: str, img_corruption: str, severity: int) -> bool:
    """Return True if the corrupted image folder exists and is non-empty."""
    if dataset == "coco":
        d = os.path.join(DATA_DIR, "coco_c", img_corruption, f"severity_{severity}")
    else:
        d = os.path.join(DATA_DIR, "flickr30k_c", img_corruption, f"severity_{severity}")
    return os.path.isdir(d) and len(os.listdir(d)) > 0
