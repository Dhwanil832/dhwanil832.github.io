"""
Path 3 Evaluation — Joint Image+Text Corruption

Iterates over all (image_corruption × severity × text_corruption × TTA) combinations
for a given model and dataset, saves results in the standard CSV schema.

Loop structure (cache-aware):
  for img_corr × severity:               # 16 × 5 = 80 combos
      load images from disk once
      encode image features once          # 5K forward passes
      run TTA-Aug once (image-only)       # 45K forward passes — NOT repeated per text
      for txt_corr:                       # 12 text types
          corrupt + encode text
          for each TTA method:
              - TTA-Aug: use cached aug features
              - tensor TTAs: use cached image_features
              - grad TTAs (TENT/MEMO/TPT): re-encode with updated params

CSV schema:
  model, dataset, path, corruption_type, severity, direction, R@1, R@5, R@10, TTA_method, seed

Usage:
    # Smoke test — single combo, single TTA:
    python -m evaluate.path3_eval --model clip_vitl14_336 --dataset coco \\
        --img-corruption zoom_blur --txt-corruption keyboard_typo --severity 3 --tta TTA-Aug

    # Full run for one model:
    python -m evaluate.path3_eval --model clip_vitl14_336 --dataset coco

    # All 8 TTA models, both datasets:
    python -m evaluate.path3_eval --all-models --all-datasets
"""

import argparse
import csv
import os
import sys
import time
import warnings
from typing import Optional

warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch

from evaluate.dataset import load_dataset, check_corrupted_images_exist, flatten_captions
from evaluate.models import load_model, get_device, ALL_MODEL_KEYS
from evaluate.retrieval import load_images_from_paths, recall_at_k
from evaluate.tta import apply_tta, TTA_METHODS, NEEDS_PIL
from text_corruptions import corrupt_batch, ALL_CORRUPTION_TYPES

# ── Constants ────────────────────────────────────────────────────────────────

SEED = 123
DATASETS = ["coco", "flickr30k"]

IMAGE_CORRUPTION_TYPES = [
    "gaussian_noise", "shot_noise", "impulse_noise", "speckle_noise",
    "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",
    "snow", "frost", "fog", "brightness",
    "contrast", "elastic_transform", "pixelate", "jpeg_compression",
]

TEXT_CORRUPTION_TYPES = ALL_CORRUPTION_TYPES  # 12 types

SEVERITIES = [1, 2, 3, 4, 5]

ALL_TTA_METHODS = list(TTA_METHODS.keys())

# TTA-Aug is image-only — its adapted features can be cached across text corruptions
_IMAGE_ONLY_TTA = {"TTA-Aug"}

RESULTS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")

# ── CSV helpers ──────────────────────────────────────────────────────────────

CSV_FIELDS = ["model", "dataset", "path", "corruption_type", "severity",
              "direction", "R@1", "R@5", "R@10", "TTA_method", "seed"]


def _result_path(model_key: str, dataset: str) -> str:
    os.makedirs(RESULTS_DIR, exist_ok=True)
    return os.path.join(RESULTS_DIR, f"path3_{model_key}_{dataset}.csv")


def _load_existing_results(csv_path: str) -> set[tuple]:
    """Return set of (corruption_type, severity, direction, TTA_method) already done."""
    done = set()
    if not os.path.exists(csv_path):
        return done
    with open(csv_path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            done.add((row["corruption_type"], int(row["severity"]),
                      row["direction"], row["TTA_method"]))
    return done


def _append_rows(csv_path: str, rows: list[dict]):
    write_header = not os.path.exists(csv_path) or os.path.getsize(csv_path) == 0
    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if write_header:
            writer.writeheader()
        writer.writerows(rows)


def _make_rows(
    model_key: str, dataset: str,
    corruption_type: str, severity: int,
    recall: dict, tta_method: str,
) -> list[dict]:
    rows = []
    for direction in ("I2T", "T2I"):
        r = recall[direction]
        rows.append({
            "model":           model_key,
            "dataset":         dataset,
            "path":            "path3",
            "corruption_type": corruption_type,
            "severity":        severity,
            "direction":       direction,
            "R@1":             r["R@1"],
            "R@5":             r["R@5"],
            "R@10":            r["R@10"],
            "TTA_method":      tta_method,
            "seed":            SEED,
        })
    return rows


def _all_done(done: set, corruption_label: str, severity: int, tta_methods: list) -> bool:
    return all(
        (corruption_label, severity, d, tta) in done
        for d in ("I2T", "T2I")
        for tta in tta_methods
    )


# ── Core evaluation loop ─────────────────────────────────────────────────────

def run_path3(
    model_key: str,
    dataset: str,
    img_corruptions: Optional[list] = None,
    txt_corruptions: Optional[list] = None,
    severities: Optional[list] = None,
    tta_methods: Optional[list] = None,
    clean_only: bool = False,
    verbose: bool = True,
    device: Optional[str] = None,
):
    """
    Run Path 3 TTA evaluation for one model × one dataset.

    Loop is structured as img_corr → severity → [encode images + TTA-Aug once]
    → txt_corr → [encode text + remaining TTAs], so each set of corrupted images
    is loaded and TTA-Aug'd once regardless of how many text corruptions are run.
    """
    img_corruptions = img_corruptions or IMAGE_CORRUPTION_TYPES
    txt_corruptions = txt_corruptions or TEXT_CORRUPTION_TYPES
    severities      = severities      or SEVERITIES
    tta_methods     = tta_methods     or ALL_TTA_METHODS

    csv_path = _result_path(model_key, dataset)
    done = _load_existing_results(csv_path)

    device = torch.device(device) if device else get_device()
    if verbose:
        print(f"\n{'='*60}")
        print(f"Model:   {model_key}")
        print(f"Dataset: {dataset}")
        print(f"Device:  {device}")
        print(f"Results: {csv_path}")
        print(f"{'='*60}\n")

    wrapper = load_model(model_key, device)

    # ── Clean baseline ───────────────────────────────────────────────────────
    _run_clean_baseline(wrapper, model_key, dataset, tta_methods, csv_path, done, verbose)

    if clean_only:
        if verbose:
            print("\n[--clean-only] Stopping after clean baseline.")
        return

    # ── Corrupted evaluations (cache-aware loop) ──────────────────────────────
    n_img = len(img_corruptions)
    n_sev = len(severities)

    for img_idx, img_corr in enumerate(img_corruptions):
        for sev in severities:

            if not check_corrupted_images_exist(dataset, img_corr, sev):
                if verbose:
                    print(f"  SKIP (images missing): {img_corr} sev={sev}")
                continue

            # Check if all (img_corr, sev) × txt_corr × tta combos are already done
            all_labels = [f"{img_corr}+{tc}" for tc in txt_corruptions]
            if all(_all_done(done, lbl, sev, tta_methods) for lbl in all_labels):
                if verbose:
                    print(f"  SKIP (all done): {img_corr} sev={sev}")
                continue

            if verbose:
                print(f"\n[{img_idx+1}/{n_img}] {img_corr}  sev={sev}", flush=True)

            # ── Load images once for this (img_corr, sev) ────────────────────
            t0 = time.time()
            image_paths, captions, _ = load_dataset(dataset, img_corr, sev)
            pil_images, missing = load_images_from_paths(
                image_paths, wrapper.preprocess, verbose=False
            )

            if len(missing) > len(image_paths) * 0.5:
                if verbose:
                    print(f"  WARN: >50% images missing ({len(missing)}/{len(image_paths)}), skipping.")
                continue

            flat_caps_clean, caption_to_img = flatten_captions(captions)

            # ── Encode base image features once ──────────────────────────────
            image_features = wrapper.encode_images(pil_images)
            if verbose:
                print(f"  Images encoded in {time.time()-t0:.1f}s", flush=True)

            # ── Pre-compute TTA-Aug image features (image-only, text-independent) ──
            cached_img_features: dict[str, torch.Tensor] = {"none": image_features}

            for tta in tta_methods:
                if tta in _IMAGE_ONLY_TTA:
                    t1 = time.time()
                    # Dummy text — TTA-Aug never uses text_features
                    dummy_txt = torch.zeros(1, image_features.shape[-1])
                    aug_img, _ = apply_tta(tta, wrapper, image_features, dummy_txt, pil_images)
                    cached_img_features[tta] = aug_img
                    if verbose:
                        print(f"  {tta} cached in {time.time()-t1:.1f}s", flush=True)

            # ── Inner loop: text corruptions ──────────────────────────────────
            for txt_corr in txt_corruptions:
                corruption_label = f"{img_corr}+{txt_corr}"

                if _all_done(done, corruption_label, sev, tta_methods):
                    continue

                # Corrupt and encode text
                flat_caps_corrupted = corrupt_batch(
                    flat_caps_clean, txt_corr, sev, seed=SEED + sev
                )
                text_features = wrapper.encode_texts(flat_caps_corrupted)

                if verbose:
                    print(f"  {corruption_label}", flush=True)

                for tta in tta_methods:
                    if all((corruption_label, sev, d, tta) in done
                           for d in ("I2T", "T2I")):
                        continue

                    if tta in cached_img_features:
                        # Use precomputed image features (TTA-Aug or none)
                        img_f = cached_img_features[tta]
                        txt_f = text_features
                    else:
                        # Grad-based or text-dependent TTAs: run now
                        pil_arg = pil_images if tta in NEEDS_PIL else None
                        img_f, txt_f = apply_tta(
                            tta, wrapper, image_features, text_features, pil_arg
                        )

                    recall = recall_at_k(img_f, txt_f, caption_to_img)
                    rows = _make_rows(model_key, dataset, corruption_label, sev, recall, tta)
                    _append_rows(csv_path, rows)
                    done.update(
                        (r["corruption_type"], int(r["severity"]), r["direction"], r["TTA_method"])
                        for r in rows
                    )
                    if verbose:
                        r1 = recall["I2T"]["R@1"]
                        print(f"    {tta:<20} I2T R@1={r1:.2f}", flush=True)

    if verbose:
        print(f"\nDone. Results saved to {csv_path}")


def _run_clean_baseline(wrapper, model_key, dataset, tta_methods, csv_path, done, verbose):
    """Evaluate clean (no corruption) baseline with all TTA methods."""
    if all(("clean", 0, d, t) in done for d in ("I2T", "T2I") for t in tta_methods):
        if verbose:
            print("  [SKIP] Clean baseline already done.")
        return

    if verbose:
        print("  Running clean baseline...", flush=True)

    image_paths, captions, _ = load_dataset(dataset)
    pil_images, _ = load_images_from_paths(image_paths, wrapper.preprocess, verbose=False)
    flat_caps, caption_to_img = flatten_captions(captions)

    t0 = time.time()
    image_features = wrapper.encode_images(pil_images)
    text_features  = wrapper.encode_texts(flat_caps)
    if verbose:
        print(f"  Clean encoded in {time.time()-t0:.1f}s", flush=True)

    # Pre-compute TTA-Aug on clean images
    cached_clean: dict[str, torch.Tensor] = {}
    for tta in tta_methods:
        if tta in _IMAGE_ONLY_TTA:
            dummy_txt = torch.zeros(1, image_features.shape[-1])
            aug_img, _ = apply_tta(tta, wrapper, image_features, dummy_txt, pil_images)
            cached_clean[tta] = aug_img

    for tta in tta_methods:
        if ("clean", 0, "I2T", tta) in done and ("clean", 0, "T2I", tta) in done:
            continue

        if tta in cached_clean:
            img_f, txt_f = cached_clean[tta], text_features
        else:
            pil_arg = pil_images if tta in NEEDS_PIL else None
            img_f, txt_f = apply_tta(tta, wrapper, image_features, text_features, pil_arg)

        recall = recall_at_k(img_f, txt_f, caption_to_img)
        rows = _make_rows(model_key, dataset, "clean", 0, recall, tta)
        _append_rows(csv_path, rows)
        done.update(
            (r["corruption_type"], r["severity"], r["direction"], r["TTA_method"])
            for r in rows
        )
        if verbose:
            r1 = recall["I2T"]["R@1"]
            print(f"    clean | {tta:<20} I2T R@1={r1:.2f}", flush=True)


# ── CLI ──────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="Path 3 TTA evaluation — joint image+text corruption")
    p.add_argument("--model",          default="clip_vitl14_336", choices=ALL_MODEL_KEYS)
    p.add_argument("--dataset",        default="coco",            choices=DATASETS)
    p.add_argument("--all-models",     action="store_true",       help="Run all 20 models")
    p.add_argument("--all-datasets",   action="store_true",       help="Run both datasets")
    p.add_argument("--clean-only",     action="store_true",       help="Only run clean baseline")
    p.add_argument("--img-corruption", default=None,              help="Single image corruption")
    p.add_argument("--txt-corruption", default=None,              help="Single text corruption")
    p.add_argument("--severity",       type=int, default=None,    help="Single severity level")
    p.add_argument("--tta",            default=None,              help="Single TTA method")
    p.add_argument("--quiet",          action="store_true",       help="Suppress verbose output")
    p.add_argument("--device",         default=None,              help="Force device (e.g. cpu, mps, cuda)")
    return p.parse_args()


def main():
    args = parse_args()
    verbose = not args.quiet

    models   = ALL_MODEL_KEYS if args.all_models   else [args.model]
    datasets = DATASETS        if args.all_datasets else [args.dataset]

    img_corruptions = [args.img_corruption] if args.img_corruption else None
    txt_corruptions = [args.txt_corruption] if args.txt_corruption else None
    severities      = [args.severity]       if args.severity      else None
    tta_methods     = [args.tta]            if args.tta           else None

    for model_key in models:
        for dataset in datasets:
            run_path3(
                model_key=model_key,
                dataset=dataset,
                img_corruptions=img_corruptions,
                txt_corruptions=txt_corruptions,
                severities=severities,
                tta_methods=tta_methods,
                clean_only=args.clean_only,
                verbose=verbose,
                device=args.device,
            )


if __name__ == "__main__":
    main()
