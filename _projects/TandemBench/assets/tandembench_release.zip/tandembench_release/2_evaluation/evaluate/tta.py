"""
Test-Time Adaptation (TTA) methods for retrieval.

8 methods + no-TTA baseline:
  none            — no adaptation (baseline)
  TTA-Aug         — Tandem-Aug internal ID; augment images K times, average embeddings
  TENT            — entropy minimisation on LayerNorm parameters
  MEMO            — marginal entropy minimisation over augmented views
  TPT             — test-time prompt tuning (CLIP family only)
  DiffTPT         — TPT with stronger augmentation (diffusion proxy)
  PromptAlign     — Tandem-Align internal ID; closed-form feature-statistic alignment
  FeatureWhitening — ZCA whitening of gallery features
  QueryExpansion  — refine query from top-K retrieved features

CLIP-specific methods (TPT, DiffTPT, and the internally named PromptAlign /
paper-named Tandem-Align) fall back to the no-TTA baseline for incompatible models.
"""

import copy
import math
from typing import Optional  # noqa: F401 — used in function signatures below

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as T
import torchvision.transforms.functional as TF

from evaluate.models import VLMWrapper, CLIP_FAMILY_KEYS

# ── Augmentation transforms ──────────────────────────────────────────────────

_STANDARD_AUGS = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomResizedCrop(224, scale=(0.7, 1.0)),
    T.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.1, hue=0.05),
])

_STRONG_AUGS = T.Compose([
    T.RandomHorizontalFlip(),
    T.RandomResizedCrop(224, scale=(0.5, 1.0)),
    T.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.2, hue=0.1),
    T.RandomGrayscale(p=0.1),
    T.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0)),
])


def _augment_pil(pil_img, aug_transform, k: int) -> list:
    """Return k augmented versions of a PIL image."""
    return [aug_transform(pil_img) for _ in range(k)]


# ── Entropy helpers ─────────────────────────────────────────────────────────

def _entropy(logits: torch.Tensor) -> torch.Tensor:
    """Softmax entropy of logit vector."""
    p = torch.softmax(logits, dim=-1)
    return -(p * (p + 1e-8).log()).sum(dim=-1)


def _marginal_entropy(probs: torch.Tensor) -> torch.Tensor:
    """Marginal entropy over a batch of probability vectors."""
    marginal = probs.mean(dim=0)
    return -(marginal * (marginal + 1e-8).log()).sum()


# ── 1. No TTA (baseline) ────────────────────────────────────────────────────

def apply_none(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    return image_features, text_features


# ── 2. TTA-Aug ──────────────────────────────────────────────────────────────

def apply_tta_aug(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    pil_images: Optional[list] = None,
    k: int = 8,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Augment each image K times, average the resulting embeddings.
    Text features are unchanged.

    Processes one image at a time with a single encode_image call for k+1 views.
    Larger batches cause MPS deadlocks on ViT-L-14-336 (attention matrix too large).
    """
    if pil_images is None:
        return image_features, text_features

    aug_feats_list = []
    for pil_img in pil_images:
        aug_imgs = _augment_pil(pil_img, _STANDARD_AUGS, k)
        # Include original
        all_imgs = [pil_img] + aug_imgs
        tensors = torch.stack([wrapper.preprocess(img) for img in all_imgs]).to(wrapper.device)
        with torch.no_grad():
            feats = wrapper.model.encode_image(tensors)
            feats = F.normalize(feats.float(), dim=-1)
            avg = feats.mean(dim=0)
            avg = F.normalize(avg.unsqueeze(0), dim=-1).cpu()
        aug_feats_list.append(avg)

    aug_image_features = torch.cat(aug_feats_list, dim=0)
    return aug_image_features, text_features


# ── 3. TENT ─────────────────────────────────────────────────────────────────

def _encode_batched(model, pil_images: list, preprocess, device, batch_size: int = 64) -> torch.Tensor:
    """Encode pil_images in mini-batches to avoid MPS OOM."""
    all_feats = []
    for i in range(0, len(pil_images), batch_size):
        batch = pil_images[i:i + batch_size]
        tensors = torch.stack([preprocess(img) for img in batch]).to(device)
        feats = model.encode_image(tensors)
        all_feats.append(feats)
    return torch.cat(all_feats, dim=0)


def _grad_device(wrapper: VLMWrapper) -> torch.device:
    """
    Return the device to use for gradient-enabled (deepcopy) operations.
    MPS does not have enough memory to hold two copies of a large model
    (original + deepcopy) simultaneously with gradients enabled, so we
    run gradient steps on CPU and return results as CPU tensors.
    """
    if str(wrapper.device) == "mps":
        return torch.device("cpu")
    return wrapper.device


def apply_tent(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    pil_images: Optional[list] = None,
    steps: int = 3,
    lr: float = 1e-3,
    batch_size: int = 64,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    TENT: minimise entropy by updating LayerNorm affine parameters.

    Skipped on MPS: gradient + activation storage for 5 000-image COCO batches
    exhausts Apple Silicon unified memory even with reduced batch sizes, and the
    per-combo runtime (960 combos × ~1 h) is infeasible.  Run on a CUDA server.
    """
    if pil_images is None or wrapper.model_key not in CLIP_FAMILY_KEYS:
        return image_features, text_features

    if str(wrapper.device) == "mps":
        print("  [TENT] Skipped on MPS (infeasible memory/time). "
              "Re-run on a CUDA server for TENT results.", flush=True)
        return image_features, text_features

    gdev = _grad_device(wrapper)
    # Use a small gradient batch to avoid activation OOM on 16 GB VRAM GPUs.
    # Inference (final encode) still uses the full batch_size.
    grad_batch = 8 if str(gdev) in ("cuda", "cpu") else batch_size

    # Clone model onto grad device, set only LayerNorm params trainable.
    # IMPORTANT: on MPS, deepcopy allocates on the source device first.
    # We must move the model to CPU *before* deepcopy to avoid OOM, then restore.
    if str(gdev) != str(wrapper.device):
        orig_device = wrapper.device
        wrapper.model.to("cpu")
        if hasattr(torch, "mps") and hasattr(torch.mps, "empty_cache"):
            torch.mps.empty_cache()
        model_copy = copy.deepcopy(wrapper.model)   # copy made entirely on CPU
        wrapper.model.to(orig_device)               # restore original to MPS
    else:
        model_copy = copy.deepcopy(wrapper.model).to(gdev)
    ln_params = []
    for module in model_copy.modules():
        if isinstance(module, nn.LayerNorm) and module.weight is not None:
            module.weight.requires_grad_(True)
            module.bias.requires_grad_(True)
            ln_params.extend([module.weight, module.bias])
        else:
            for p in module.parameters(recurse=False):
                p.requires_grad_(False)

    if not ln_params:
        del model_copy
        return image_features, text_features

    optimizer = torch.optim.Adam(ln_params, lr=lr)
    txt_f = text_features.to(gdev)
    n_batches = math.ceil(len(pil_images) / grad_batch)

    for _ in range(steps):
        optimizer.zero_grad()
        for i in range(0, len(pil_images), grad_batch):
            batch = pil_images[i:i + grad_batch]
            tensors = torch.stack([wrapper.preprocess(img) for img in batch]).to(gdev)
            feats = model_copy.encode_image(tensors)
            feats = F.normalize(feats.float(), dim=-1)
            logits = feats @ txt_f.T * 100.0
            loss = _entropy(logits).mean() / n_batches
            loss.backward()
        optimizer.step()

    with torch.no_grad():
        new_img_feats = _encode_batched(
            model_copy, pil_images, wrapper.preprocess, gdev, batch_size
        )
        new_img_feats = F.normalize(new_img_feats.float(), dim=-1).cpu()

    del model_copy
    return new_img_feats, text_features


# ── 4. MEMO ─────────────────────────────────────────────────────────────────

def apply_memo(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    pil_images: Optional[list] = None,
    k: int = 8,
    steps: int = 3,
    lr: float = 1e-4,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    MEMO: minimise marginal entropy over K augmented views per image.
    Updates model weights per image independently.

    Skipped on MPS: requires one full model deepcopy *per image* (5 000 copies on
    COCO), which is infeasible both in memory and time on Apple Silicon.
    Run on a CUDA server for MEMO results.
    """
    if pil_images is None or wrapper.model_key not in CLIP_FAMILY_KEYS:
        return image_features, text_features

    if str(wrapper.device) in ("mps",):
        print("  [MEMO] Skipped on MPS (per-image deepcopy infeasible). "
              "Re-run on a CUDA server for MEMO results.", flush=True)
        return image_features, text_features

    gdev = _grad_device(wrapper)
    txt_f = text_features.to(gdev)
    adapted_feats = []

    # Pre-move model to grad device once before the per-image loop.
    # This lets deepcopy work entirely on gdev without touching MPS.
    _memo_orig_device = wrapper.device
    if str(gdev) != str(wrapper.device):
        wrapper.model.to("cpu")
        if hasattr(torch, "mps") and hasattr(torch.mps, "empty_cache"):
            torch.mps.empty_cache()

    for pil_img in pil_images:
        model_copy = copy.deepcopy(wrapper.model)  # model already on gdev
        params = [p for p in model_copy.parameters() if p.requires_grad]
        if not params:
            adapted_feats.append(
                F.normalize(model_copy.encode_image(
                    wrapper.preprocess(pil_img).unsqueeze(0).to(gdev)
                ).float(), dim=-1).cpu()
            )
            del model_copy
            continue

        optimizer = torch.optim.Adam(params, lr=lr)
        aug_imgs = _augment_pil(pil_img, _STANDARD_AUGS, k)
        tensors = torch.stack([wrapper.preprocess(img) for img in aug_imgs]).to(gdev)

        for _ in range(steps):
            optimizer.zero_grad()
            feats = model_copy.encode_image(tensors)
            feats = F.normalize(feats.float(), dim=-1)
            logits = feats @ txt_f.T * 100.0
            probs = torch.softmax(logits, dim=-1)
            loss = _marginal_entropy(probs)
            loss.backward()
            optimizer.step()

        with torch.no_grad():
            t = wrapper.preprocess(pil_img).unsqueeze(0).to(gdev)
            feat = model_copy.encode_image(t)
            feat = F.normalize(feat.float(), dim=-1).cpu()
        adapted_feats.append(feat)
        del model_copy

    # Restore original model device after per-image adaptation loop
    if str(gdev) != str(_memo_orig_device):
        wrapper.model.to(_memo_orig_device)

    return torch.cat(adapted_feats, dim=0), text_features


# ── 5. TPT (CLIP-specific) ───────────────────────────────────────────────────

def apply_tpt(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    pil_images: Optional[list] = None,
    k: int = 8,
    steps: int = 3,
    lr: float = 5e-3,
    top_frac: float = 0.1,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    TPT: test-time prompt tuning.
    Learns a shared additive prompt offset on text features to minimise
    entropy of the top-confidence augmented views.
    Falls back to no-TTA for non-CLIP models.

    Skipped on MPS: model must move to CPU for gradient steps; 120 K forward
    passes per (img_corr, sev, txt_corr) × 960 combos ≈ weeks of CPU time.
    Run on a CUDA server for TPT results.
    """
    if pil_images is None or wrapper.model_key not in CLIP_FAMILY_KEYS:
        return image_features, text_features

    if str(wrapper.device) == "mps":
        print("  [TPT] Skipped on MPS (infeasible runtime). "
              "Re-run on a CUDA server for TPT results.", flush=True)
        return image_features, text_features

    gdev = _grad_device(wrapper)
    D = text_features.shape[-1]
    prompt_delta = nn.Parameter(torch.zeros(1, D, device=gdev))
    optimizer = torch.optim.Adam([prompt_delta], lr=lr)

    n = len(pil_images)
    for _ in range(steps):
        optimizer.zero_grad()
        for pil_img in pil_images:
            aug_imgs = _augment_pil(pil_img, _STANDARD_AUGS, k)
            tensors = torch.stack([wrapper.preprocess(img) for img in aug_imgs]).to(gdev)
            with torch.no_grad():
                img_f = wrapper.model.to(gdev).encode_image(tensors)
                img_f = F.normalize(img_f.float(), dim=-1)

            txt_f = F.normalize(text_features.to(gdev) + prompt_delta, dim=-1)
            logits = img_f @ txt_f.T * 100.0
            ent = _entropy(logits)
            top_k = max(1, int(k * top_frac))
            _, idx = ent.topk(top_k, largest=False)
            # Divide by n before backward so gradient scale matches the original
            # mean-over-images formulation, but graph is freed after each image.
            (ent[idx].mean() / n).backward()

        optimizer.step()

    # Restore model to original device after TPT
    wrapper.model.to(wrapper.device)
    with torch.no_grad():
        adapted_txt = F.normalize(text_features + prompt_delta.cpu().detach(), dim=-1)

    return image_features, adapted_txt


# ── 6. DiffTPT ──────────────────────────────────────────────────────────────

def apply_difftpt(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    pil_images: Optional[list] = None,
    k: int = 8,
    steps: int = 3,
    lr: float = 5e-3,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    DiffTPT: TPT with diffusion-inspired augmentation.
    Approximated here with strong photometric + geometric augmentations
    (full diffusion model not assumed available at test time).

    Skipped on MPS: same constraint as TPT (model CPU migration + runtime).
    Run on a CUDA server for DiffTPT results.
    """
    if pil_images is None or wrapper.model_key not in CLIP_FAMILY_KEYS:
        return image_features, text_features

    if str(wrapper.device) == "mps":
        print("  [DiffTPT] Skipped on MPS (infeasible runtime). "
              "Re-run on a CUDA server for DiffTPT results.", flush=True)
        return image_features, text_features

    gdev = _grad_device(wrapper)
    D = text_features.shape[-1]
    prompt_delta = nn.Parameter(torch.zeros(1, D, device=gdev))
    optimizer = torch.optim.Adam([prompt_delta], lr=lr)

    n = len(pil_images)
    for _ in range(steps):
        optimizer.zero_grad()
        for pil_img in pil_images:
            aug_imgs = _augment_pil(pil_img, _STRONG_AUGS, k)
            tensors = torch.stack([wrapper.preprocess(img) for img in aug_imgs]).to(gdev)
            with torch.no_grad():
                img_f = wrapper.model.to(gdev).encode_image(tensors)
                img_f = F.normalize(img_f.float(), dim=-1)

            txt_f = F.normalize(text_features.to(gdev) + prompt_delta, dim=-1)
            logits = img_f @ txt_f.T * 100.0
            ent = _entropy(logits)
            (ent.mean() / n).backward()

        optimizer.step()

    wrapper.model.to(wrapper.device)
    with torch.no_grad():
        adapted_txt = F.normalize(text_features + prompt_delta.cpu().detach(), dim=-1)

    return image_features, adapted_txt


# ── 7. Tandem-Align (legacy internal ID: PromptAlign) ───────────────────────

def apply_prompt_align(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Tandem-Align (legacy internal ID: PromptAlign).

    Closed-form feature-statistic alignment: text features are shifted and scaled
    to match the image-feature mean and standard deviation, then re-normalized.
    No prompt optimization or parameter updates are performed.
    CLIP-family only; falls back to no-TTA otherwise.
    """
    if wrapper.model_key not in CLIP_FAMILY_KEYS:
        return image_features, text_features

    img_mean = image_features.mean(dim=0, keepdim=True)
    img_std  = image_features.std(dim=0, keepdim=True).clamp(min=1e-6)
    txt_mean = text_features.mean(dim=0, keepdim=True)
    txt_std  = text_features.std(dim=0, keepdim=True).clamp(min=1e-6)

    # Shift and scale text features to match image distribution
    aligned = (text_features - txt_mean) / txt_std * img_std + img_mean
    aligned = F.normalize(aligned, dim=-1)
    return image_features, aligned


# ── 8. Feature Whitening ────────────────────────────────────────────────────

def apply_feature_whitening(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    eps: float = 1e-5,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    ZCA whitening of gallery (image) features.
    Decorrelates the feature dimensions to improve retrieval.
    """
    # Compute ZCA on image features
    mu = image_features.mean(dim=0)
    X = image_features - mu
    cov = (X.T @ X) / (X.shape[0] - 1)
    # Eigendecomposition for ZCA
    try:
        eigvals, eigvecs = torch.linalg.eigh(cov)
        eigvals = eigvals.clamp(min=eps)
        W = eigvecs @ torch.diag(eigvals ** -0.5) @ eigvecs.T
        img_white = F.normalize((X @ W), dim=-1)

        txt_mu = text_features.mean(dim=0)
        txt_X = text_features - txt_mu
        txt_white = F.normalize((txt_X @ W), dim=-1)

        return img_white, txt_white
    except Exception:
        # Fallback if eigendecomposition fails
        return image_features, text_features


# ── 9. Query Expansion ──────────────────────────────────────────────────────

def apply_query_expansion(
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    top_k: int = 10,
    alpha: float = 0.5,
    **kwargs,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Average Query Expansion (AQE): refine each text query by averaging
    it with the top-K retrieved image features.
    """
    # For each text query, retrieve top-K images and blend
    sim = text_features @ image_features.T  # (N_txt, N_img)
    _, topk_idx = sim.topk(top_k, dim=1)    # (N_txt, top_k)

    expanded = []
    for i in range(text_features.shape[0]):
        neighbors = image_features[topk_idx[i]]  # (top_k, D)
        neighbor_mean = neighbors.mean(dim=0)
        refined = alpha * text_features[i] + (1 - alpha) * neighbor_mean
        expanded.append(F.normalize(refined.unsqueeze(0), dim=-1))

    expanded_txt = torch.cat(expanded, dim=0)
    return image_features, expanded_txt


# ── Dispatch ─────────────────────────────────────────────────────────────────

TTA_METHODS = {
    "none":             apply_none,
    "TTA-Aug":          apply_tta_aug,
    "TENT":             apply_tent,
    "MEMO":             apply_memo,
    "TPT":              apply_tpt,
    "DiffTPT":          apply_difftpt,
    "PromptAlign":      apply_prompt_align,
    "FeatureWhitening": apply_feature_whitening,
    "QueryExpansion":   apply_query_expansion,
}

# Methods that require gradient computation (slower per-image adaptation)
GRAD_BASED_METHODS = {"TENT", "MEMO", "TPT", "DiffTPT"}

# Methods that need PIL images passed in
NEEDS_PIL = {"TTA-Aug", "TENT", "MEMO", "TPT", "DiffTPT"}


def apply_tta(
    method: str,
    wrapper: VLMWrapper,
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    pil_images: Optional[list] = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Apply a TTA method by name.

    Args:
        method:         one of TTA_METHODS keys
        wrapper:        VLMWrapper
        image_features: (N_img, D) clean/corrupted image features
        text_features:  (N_txt, D) clean/corrupted text features
        pil_images:     list of PIL images (required for NEEDS_PIL methods)

    Returns:
        (adapted_image_features, adapted_text_features)
    """
    if method not in TTA_METHODS:
        raise ValueError(f"Unknown TTA method: {method!r}. Choose from: {list(TTA_METHODS)}")
    fn = TTA_METHODS[method]
    return fn(wrapper=wrapper, image_features=image_features,
              text_features=text_features, pil_images=pil_images)
