"""
Core retrieval evaluation.

Computes R@1, R@5, R@10 for Image→Text and Text→Image retrieval.

For N images × 5 captions each:
  I2T: 1000 image queries → 5000 caption gallery
  T2I: 5000 caption queries → 1000 image gallery
"""

import os
import time
from typing import Optional

import torch
import torch.nn.functional as F
from PIL import Image


def load_images_from_paths(
    image_paths: list[str],
    preprocess,
    verbose: bool = False,
) -> tuple[list[Image.Image], list[int]]:
    """
    Load PIL images from paths. Returns loaded images and indices of missing files.

    Missing image files are skipped and reported; their indices are returned
    so callers can align captions accordingly.
    """
    pil_images = []
    missing = []
    for i, path in enumerate(image_paths):
        if os.path.exists(path):
            try:
                img = Image.open(path).convert("RGB")
                pil_images.append(img)
            except Exception as e:
                if verbose:
                    print(f"    [WARN] Failed to open {path}: {e}")
                missing.append(i)
                pil_images.append(None)
        else:
            if verbose:
                print(f"    [WARN] Missing: {path}")
            missing.append(i)
            pil_images.append(None)

    # Replace None with a black placeholder so list stays aligned
    placeholder = Image.new("RGB", (224, 224), color=0)
    pil_images = [img if img is not None else placeholder for img in pil_images]
    return pil_images, missing


def recall_at_k(
    image_features: torch.Tensor,
    text_features: torch.Tensor,
    caption_to_img: list[int],
    k_values: tuple[int, ...] = (1, 5, 10),
) -> dict[str, dict[str, float]]:
    """
    Compute R@k for I→T and T→I retrieval.

    Args:
        image_features:  (N_img, D) L2-normalised image embeddings
        text_features:   (N_txt, D) L2-normalised text embeddings
        caption_to_img:  caption_to_img[j] = image index for caption j
        k_values:        tuple of k values to compute recall at

    Returns:
        {
          "I2T": {"R@1": ..., "R@5": ..., "R@10": ...},
          "T2I": {"R@1": ..., "R@5": ..., "R@10": ...},
        }
    """
    N_img = image_features.shape[0]
    N_txt = text_features.shape[0]

    # Similarity matrix (N_img × N_txt) — do on CPU to avoid MPS OOM for large matrices
    sim = image_features @ text_features.T  # (N_img, N_txt)

    # Ground-truth: for each image i, which caption indices belong to it?
    img_to_caps: list[list[int]] = [[] for _ in range(N_img)]
    for cap_idx, img_idx in enumerate(caption_to_img):
        img_to_caps[img_idx].append(cap_idx)

    results = {"I2T": {}, "T2I": {}}

    # ── Image → Text ──────────────────────────────────────────────────────
    i2t_ranks = []
    for img_idx in range(N_img):
        scores = sim[img_idx]  # (N_txt,)
        ranking = torch.argsort(scores, descending=True).tolist()
        gt_caps = set(img_to_caps[img_idx])
        # Rank of best-matching ground-truth caption
        for rank, cap_idx in enumerate(ranking):
            if cap_idx in gt_caps:
                i2t_ranks.append(rank)
                break

    for k in k_values:
        results["I2T"][f"R@{k}"] = round(
            100.0 * sum(1 for r in i2t_ranks if r < k) / len(i2t_ranks), 2
        )

    # ── Text → Image ──────────────────────────────────────────────────────
    sim_T = sim.T  # (N_txt, N_img)
    t2i_ranks = []
    for cap_idx in range(N_txt):
        scores = sim_T[cap_idx]  # (N_img,)
        ranking = torch.argsort(scores, descending=True).tolist()
        gt_img = caption_to_img[cap_idx]
        rank = ranking.index(gt_img)
        t2i_ranks.append(rank)

    for k in k_values:
        results["T2I"][f"R@{k}"] = round(
            100.0 * sum(1 for r in t2i_ranks if r < k) / len(t2i_ranks), 2
        )

    return results


def encode_dataset(
    wrapper,
    image_paths: list[str],
    captions: list[list[str]],
    verbose: bool = False,
) -> tuple[torch.Tensor, torch.Tensor, list[int]]:
    """
    Encode all images and flattened captions for a dataset.

    Returns:
        image_features:  (N_img, D)
        text_features:   (N_txt, D)
        caption_to_img:  flat caption → image index mapping
    """
    from evaluate.dataset import flatten_captions

    if verbose:
        print(f"    Encoding {len(image_paths)} images...", flush=True)
    t0 = time.time()
    pil_images, missing = load_images_from_paths(image_paths, wrapper.preprocess, verbose=verbose)
    image_features = wrapper.encode_images(pil_images)
    if verbose:
        print(f"    Images encoded in {time.time()-t0:.1f}s", flush=True)

    flat_caps, caption_to_img = flatten_captions(captions)
    if verbose:
        print(f"    Encoding {len(flat_caps)} captions...", flush=True)
    t0 = time.time()
    text_features = wrapper.encode_texts(flat_caps)
    if verbose:
        print(f"    Captions encoded in {time.time()-t0:.1f}s", flush=True)

    return image_features, text_features, caption_to_img


def evaluate_retrieval(
    wrapper,
    image_paths: list[str],
    captions: list[list[str]],
    verbose: bool = False,
) -> dict[str, dict[str, float]]:
    """
    Full encode + recall computation.

    Returns:
        {"I2T": {"R@1": ..., "R@5": ..., "R@10": ...},
         "T2I": {"R@1": ..., "R@5": ..., "R@10": ...}}
    """
    image_features, text_features, caption_to_img = encode_dataset(
        wrapper, image_paths, captions, verbose=verbose
    )
    return recall_at_k(image_features, text_features, caption_to_img)
