"""
Model registry and loader for all 20 VLMs.

All models expose a common interface:
    encode_images(pil_images) -> torch.Tensor  (N, D), L2-normalised
    encode_texts(strings)     -> torch.Tensor  (N, D), L2-normalised

Device: MPS if available, else CPU (no CUDA assumed — Apple Silicon).
"""

import torch
import torch.nn.functional as F
from PIL import Image
from typing import Callable, Optional

# ── Device ─────────────────────────────────────────────────────────────────
def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


# ── Model registry ──────────────────────────────────────────────────────────
# Each entry: (loader_type, model_name, pretrained_or_hf_id)
MODEL_REGISTRY: dict[str, tuple[str, str, str]] = {
    # OpenAI CLIP (via open_clip)
    "clip_vitb32":       ("openai_clip", "ViT-B-32",           "openai"),
    "clip_vitb16":       ("openai_clip", "ViT-B-16",           "openai"),
    "clip_vitl14":       ("openai_clip", "ViT-L-14",           "openai"),
    "clip_vitl14_336":   ("openai_clip", "ViT-L-14-336",       "openai"),
    # OpenCLIP / LAION
    "openclip_vitb32":   ("open_clip",   "ViT-B-32",           "laion2b_s34b_b79k"),
    "openclip_vitb16":   ("open_clip",   "ViT-B-16",           "laion2b_s34b_b88k"),
    "openclip_vitl14":   ("open_clip",   "ViT-L-14",           "laion2b_s32b_b82k"),
    "openclip_vith14":   ("open_clip",   "ViT-H-14",           "laion2b_s32b_b79k"),
    "openclip_vitbigg14":("open_clip",   "ViT-bigG-14",        "laion2b_s39b_b160k"),
    # Google SigLIP (via open_clip)
    "siglip_vitb16":     ("open_clip",   "ViT-B-16-SigLIP",    "webli"),
    "siglip_vitl16":     ("open_clip",   "ViT-L-16-SigLIP",    "webli"),
    "siglip_so400m14":   ("open_clip",   "ViT-SO400M-14-SigLIP", "webli"),
    # BAAI EVA-CLIP (via open_clip)
    "evaclip_vitb16":    ("open_clip",   "EVA02-B-16",         "merged2b_s8b_b131k"),
    "evaclip_vitl14":    ("open_clip",   "EVA02-L-14",         "merged2b_s4b_b131k"),
    # Meta MetaCLIP (via open_clip)
    "metaclip_vitb16":   ("open_clip",   "ViT-B-16-quickgelu", "metaclip_400m"),
    "metaclip_vitl14":   ("open_clip",   "ViT-L-14-quickgelu", "metaclip_fullcc"),
    # Apple DFN (via open_clip)
    "dfn_vith14":        ("open_clip",   "ViT-H-14-quickgelu", "dfn5b"),
    # Salesforce BLIP-Large retrieval (HuggingFace)
    "blip_large":        ("blip_large",  "Salesforce/blip-itm-large-coco", ""),
    # OpenCLIP CoCa
    "coca_vitl":         ("open_clip",   "coca_ViT-L-14",      "mscoco_finetuned_laion2b_s13b_b90k"),
    # Shanghai AI Lab InternVL-C (HuggingFace)
    "internvl_vitb":     ("internvl",    "OpenGVLab/InternVL-C-13B", ""),
}

ALL_MODEL_KEYS = list(MODEL_REGISTRY.keys())

# CLIP-specific TTA methods only apply to these families
CLIP_FAMILY_KEYS = [
    k for k in ALL_MODEL_KEYS
    if any(k.startswith(p) for p in
           ("clip_", "openclip_", "siglip_", "evaclip_", "metaclip_", "dfn_"))
]


# ── Wrapper class ───────────────────────────────────────────────────────────

class VLMWrapper:
    """Unified interface for all 20 models."""

    def __init__(self, model_key: str, model, preprocess, tokenizer, device: torch.device):
        self.model_key = model_key
        self.model = model
        self.preprocess = preprocess
        self.tokenizer = tokenizer
        self.device = device
        self._model_type = MODEL_REGISTRY[model_key][0]

    @torch.no_grad()
    def encode_images(self, pil_images: list[Image.Image], batch_size: int = 64) -> torch.Tensor:
        """Encode PIL images → L2-normalised features (N, D)."""
        all_feats = []
        for i in range(0, len(pil_images), batch_size):
            batch = pil_images[i:i + batch_size]
            tensors = torch.stack([self.preprocess(img) for img in batch]).to(self.device)
            if self._model_type == "blip_large":
                feats = self._blip_large_encode_images(tensors)
            elif self._model_type == "internvl":
                feats = self._internvl_encode_images(tensors)
            else:
                feats = self.model.encode_image(tensors)
            all_feats.append(F.normalize(feats.float(), dim=-1).cpu())
        return torch.cat(all_feats, dim=0)

    @torch.no_grad()
    def encode_texts(self, texts: list[str], batch_size: int = 256) -> torch.Tensor:
        """Encode text strings → L2-normalised features (N, D)."""
        all_feats = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            if self._model_type == "blip_large":
                feats = self._blip_large_encode_texts(batch)
            elif self._model_type == "internvl":
                feats = self._internvl_encode_texts(batch)
            else:
                tokens = self.tokenizer(batch).to(self.device)
                feats = self.model.encode_text(tokens)
            all_feats.append(F.normalize(feats.float(), dim=-1).cpu())
        return torch.cat(all_feats, dim=0)

    def _blip_large_encode_images(self, tensors):
        """BLIP-Large: vision_model CLS → vision_proj."""
        vision_out = self.model.vision_model(pixel_values=tensors)
        cls = vision_out.last_hidden_state[:, 0, :]
        return self.model.vision_proj(cls)

    def _blip_large_encode_texts(self, texts):
        """BLIP-Large: text_encoder CLS → text_proj."""
        inputs = self.tokenizer(
            text=texts, return_tensors="pt", padding=True, truncation=True, max_length=77
        ).to(self.device)
        text_out = self.model.text_encoder(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
        )
        cls = text_out.last_hidden_state[:, 0, :]
        return self.model.text_proj(cls)

    def _internvl_encode_images(self, tensors):
        return self.model.encode_image(tensors)

    def _internvl_encode_texts(self, texts):
        tokens = self.tokenizer(
            texts, return_tensors="pt", padding=True, truncation=True, max_length=77
        ).to(self.device)
        return self.model.encode_text(tokens["input_ids"])


# ── Loaders ─────────────────────────────────────────────────────────────────

def _load_openai_or_openclip(model_key: str, model_name: str, pretrained: str, device: torch.device) -> VLMWrapper:
    import open_clip
    model, _, preprocess = open_clip.create_model_and_transforms(
        model_name, pretrained=pretrained, device=device
    )
    model.eval()
    tokenizer = open_clip.get_tokenizer(model_name)
    return VLMWrapper(model_key, model, preprocess, tokenizer, device)


def _load_blip_large(model_key: str, hf_id: str, device: torch.device) -> VLMWrapper:
    """Load Salesforce/blip-itm-large-coco for dual-encoder retrieval."""
    from transformers import BlipForImageTextRetrieval, BlipProcessor

    processor = BlipProcessor.from_pretrained(hf_id)
    model = BlipForImageTextRetrieval.from_pretrained(
        hf_id, torch_dtype=torch.float32
    ).to(device)
    model.eval()

    # Wrap processor so encode_images works with single PIL images
    class _Preprocess:
        def __init__(self, proc): self.proc = proc
        def __call__(self, img):
            return self.proc(images=img, return_tensors="pt")["pixel_values"][0]

    return VLMWrapper(model_key, model, _Preprocess(processor), processor, device)


def _load_internvl(model_key: str, hf_id: str, device: torch.device) -> VLMWrapper:
    from transformers import AutoModel, AutoTokenizer
    import torchvision.transforms as T

    model = AutoModel.from_pretrained(hf_id, trust_remote_code=True, torch_dtype=torch.float32).to(device)
    model.eval()
    tokenizer = AutoTokenizer.from_pretrained(hf_id, trust_remote_code=True)

    preprocess = T.Compose([
        T.Resize((224, 224)),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    return VLMWrapper(model_key, model, preprocess, tokenizer, device)


def load_model(model_key: str, device: Optional[torch.device] = None) -> VLMWrapper:
    """
    Load a model by its registry key.

    Args:
        model_key: one of ALL_MODEL_KEYS
        device:    torch.device (defaults to MPS if available, else CPU)

    Returns:
        VLMWrapper with .encode_images() and .encode_texts()
    """
    if model_key not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model: {model_key!r}. Choose from: {ALL_MODEL_KEYS}")

    if device is None:
        device = get_device()

    loader_type, model_name, pretrained = MODEL_REGISTRY[model_key]

    print(f"  Loading {model_key} ({model_name}) on {device}...", flush=True)

    if loader_type in ("openai_clip", "open_clip"):
        return _load_openai_or_openclip(model_key, model_name, pretrained, device)
    elif loader_type == "blip_large":
        return _load_blip_large(model_key, model_name, device)
    elif loader_type == "internvl":
        return _load_internvl(model_key, model_name, device)
    else:
        raise ValueError(f"Unknown loader type: {loader_type!r}")
