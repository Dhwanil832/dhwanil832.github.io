# Stage 2 — Evaluation

Runs the retrieval harness and produces the evaluation records: Recall@1/5/10 for every
model, dataset, corruption condition, severity and retrieval direction. Requires
[stage 1](../1_data_generation/) to have generated the corrupted images.

## Running

```bash
python evaluate.py --model clip_vit_l14 --dataset coco --path 3
```

| Flag | Meaning |
|---|---|
| `--path 1` | image corrupted, caption clean |
| `--path 2` | caption corrupted, image clean |
| `--path 3` | both corrupted, same sample, same severity |
| `--model` | a key from `MODEL_REGISTRY` in `evaluate.py` |
| `--dataset` | `coco` or `flickr30k` |

Model weights download on first use. Output is appended as CSV rows, one per
condition, and runs are resumable — existing rows are skipped.

## The three paths

Every joint condition is evaluated alongside its two matched marginals on the *same*
samples at the *same* severity. That matching is the point of the benchmark: it is what
makes δ₁, δ₂ and δ₃ directly comparable, and it is what a benchmark perturbing one
modality at a time cannot provide.

The joint design traces the **matched-severity diagonal**, not the full cross product.
For one model and dataset that is 960 joint conditions (16 image × 12 text × 5
severities, both directions). Evaluating every severity pair would give 4,800, but the
marginals would no longer be measured at the joint condition's severity.

## Models

All 19 are dual encoders evaluated zero-shot with frozen weights, producing independent
image and text embeddings compared by cosine similarity. That independence is what
makes the marginal–joint decomposition well defined, and it is why cross-attention
rerankers and multimodal LLMs are out of scope.

`MODEL_REGISTRY` in `evaluate.py` gives the architecture and pretrained tag for each.
The generated `4_analysis/tables/checkpoints.csv` additionally records the **resolved
weight source**, which matters for reproduction: a tag such as `metaclip_fullcc` is
mapped to specific weights by `open_clip`'s registry, and that mapping can differ
between library versions. The resolved column identifies the weights directly.

## Device

CUDA if available, else MPS, else CPU — the harness auto-detects. Evaluation is
inference only. Reproducing the reported tables from the released records requires none
of this; see [stage 4](../4_analysis/).
