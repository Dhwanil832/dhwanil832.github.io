#!/usr/bin/env python3
"""
evaluate.py — Unified VLM Retrieval Robustness Benchmark (Path 1)

Evaluates vision-language models on image-text retrieval under image corruptions.
Results are appended to results.csv. Already-evaluated combinations are skipped.

Usage:
    # Single model
    python3 evaluate.py --model clip_vit_b32 --dataset coco --seed 42

    # Multiple specific models
    python3 evaluate.py --model clip_vit_b32 openclip_vit_l14 --dataset coco --seed 42

    # All models
    python3 evaluate.py --model all --dataset both --seed 42

    # Single corruption (useful for debugging)
    python3 evaluate.py --model clip_vit_b32 --dataset coco --corruption gaussian_noise

    # List all available models
    python3 evaluate.py --list-models
"""

# ── SSL certificate configuration (must precede any network imports) ────────
import ssl
import certifi
ssl._create_default_https_context = lambda: ssl.create_default_context(cafile=certifi.where())
# ──────────────────────────────────────────────────────────────────────────────

import argparse
import csv
import gc
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
from PIL import Image
from tqdm import tqdm

# ─── Paths ────────────────────────────────────────────────────────────────────

BASE_DIR    = Path(__file__).parent
RESULTS_CSV = BASE_DIR / "results.csv"

DATASET_CONFIG = {
    "coco": {
        "clean_images": BASE_DIR / "data/coco/images/val2017",
        "corrupted":    BASE_DIR / "data/coco_c",
        "annotations":  BASE_DIR / "data/coco/annotations/captions_index.json",
    },
    "flickr30k": {
        "clean_images": BASE_DIR / "data/flickr30k/images/flickr30k-images",
        "corrupted":    BASE_DIR / "data/flickr30k_c",
        "annotations":  BASE_DIR / "data/flickr30k/annotations/dataset_flickr30k.json",
    },
}

# ─── Benchmark spec ───────────────────────────────────────────────────────────

CORRUPTION_TYPES = [
    "brightness", "contrast", "defocus_blur", "elastic_transform",
    "fog", "frost", "gaussian_noise", "glass_blur", "impulse_noise",
    "jpeg_compression", "motion_blur", "pixelate", "shot_noise",
    "snow", "speckle_noise", "zoom_blur",
]
SEVERITIES   = [1, 2, 3, 4, 5]
CSV_FIELDS   = [
    "model", "dataset", "path", "corruption_type", "severity",
    "direction", "R@1", "R@5", "R@10", "TTA_method", "seed",
]

# ─── Model registry ───────────────────────────────────────────────────────────

MODEL_REGISTRY = {
    # OpenAI CLIP
    "clip_vit_b32":         {"family": "clip",      "name": "ViT-B/32"},
    "clip_vit_b16":         {"family": "clip",      "name": "ViT-B/16"},
    "clip_vit_l14":         {"family": "clip",      "name": "ViT-L/14"},
    "clip_vit_l14_336":     {"family": "clip",      "name": "ViT-L/14@336px"},
    # OpenCLIP — LAION
    "openclip_vit_b32":     {"family": "openclip",  "name": "ViT-B-32",             "pretrained": "laion2b_s34b_b79k"},
    "openclip_vit_b16":     {"family": "openclip",  "name": "ViT-B-16",             "pretrained": "laion400m_e32"},
    "openclip_vit_l14":     {"family": "openclip",  "name": "ViT-L-14",             "pretrained": "laion2b_s32b_b82k"},
    "openclip_vit_h14":     {"family": "openclip",  "name": "ViT-H-14",             "pretrained": "laion2b_s32b_b79k"},
    "openclip_vit_bigg14":  {"family": "openclip",  "name": "ViT-bigG-14",          "pretrained": "laion2b_s39b_b160k"},
    # SigLIP — Google (via HuggingFace)
    "siglip_vit_b16":       {"family": "siglip",    "name": "google/siglip-base-patch16-224"},
    "siglip_vit_l16":       {"family": "siglip",    "name": "google/siglip-large-patch16-256"},
    "siglip_so400m":        {"family": "siglip",    "name": "google/siglip-so400m-patch14-384"},
    # EVA-CLIP — BAAI (via OpenCLIP)
    "evaclip_vit_b16":      {"family": "openclip",  "name": "EVA02-B-16",            "pretrained": "merged2b_s8b_b131k"},
    "evaclip_vit_l14":      {"family": "openclip",  "name": "EVA02-L-14",            "pretrained": "merged2b_s4b_b131k"},
    # MetaCLIP — Meta (via OpenCLIP)
    "metaclip_vit_b16":     {"family": "openclip",  "name": "ViT-B-16-quickgelu",   "pretrained": "metaclip_fullcc"},
    "metaclip_vit_l14":     {"family": "openclip",  "name": "ViT-L-14-quickgelu",   "pretrained": "metaclip_fullcc"},
    # DFN — Apple (via OpenCLIP)
    "dfn_vit_h14":          {"family": "openclip",  "name": "ViT-H-14-quickgelu",   "pretrained": "dfn5b"},
    # BLIP — Salesforce (via HuggingFace)
    "blip_large":           {"family": "blip",      "name": "Salesforce/blip-itm-large-coco"},
    # BLIP-2 — Salesforce (via HuggingFace)
    "blip2":                {"family": "blip2",     "name": "Salesforce/blip2-opt-2.7b"},
    # CoCa — via OpenCLIP
    "coca_vit_l":           {"family": "openclip",  "name": "coca_ViT-L-14",        "pretrained": "mscoco_finetuned_laion2B-s13B-b90k"},
}

ALL_MODELS = list(MODEL_REGISTRY.keys())


# ─── Device ───────────────────────────────────────────────────────────────────

def get_device() -> torch.device:
    if torch.backends.mps.is_available():
        return torch.device("mps")
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


# ─── Model wrappers ───────────────────────────────────────────────────────────

class CLIPWrapper:
    """OpenAI CLIP — uses the `clip` library."""

    def __init__(self, model_name: str, device: torch.device):
        import clip
        self.model, self.preprocess = clip.load(model_name, device=device)
        self.model.eval()
        self.device = device
        self._tokenize = clip.tokenize

    @torch.no_grad()
    def encode_images(self, paths: List[Path], batch_size: int = 64) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(paths), batch_size), desc="  img", leave=False):
            imgs = torch.stack([
                self.preprocess(Image.open(p).convert("RGB"))
                for p in paths[i:i + batch_size]
            ]).to(self.device)
            e = self.model.encode_image(imgs)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def encode_texts(self, texts: List[str], batch_size: int = 256) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(texts), batch_size), desc="  txt", leave=False):
            tok = self._tokenize(texts[i:i + batch_size], truncate=True).to(self.device)
            e = self.model.encode_text(tok)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)


class OpenCLIPWrapper:
    """OpenCLIP — covers OpenCLIP, EVA-CLIP, MetaCLIP, DFN, CoCa."""

    def __init__(self, model_name: str, pretrained: str, device: torch.device):
        import open_clip
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained, device=device
        )
        self.model.eval()
        self.device = device
        self.tokenizer = open_clip.get_tokenizer(model_name)

    @torch.no_grad()
    def encode_images(self, paths: List[Path], batch_size: int = 64) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(paths), batch_size), desc="  img", leave=False):
            imgs = torch.stack([
                self.preprocess(Image.open(p).convert("RGB"))
                for p in paths[i:i + batch_size]
            ]).to(self.device)
            e = self.model.encode_image(imgs)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def encode_texts(self, texts: List[str], batch_size: int = 256) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(texts), batch_size), desc="  txt", leave=False):
            tok = self.tokenizer(texts[i:i + batch_size]).to(self.device)
            e = self.model.encode_text(tok)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)


class SigLIPWrapper:
    """SigLIP — uses HuggingFace transformers."""

    def __init__(self, model_name: str, device: torch.device):
        from transformers import SiglipModel, SiglipProcessor
        self.model     = SiglipModel.from_pretrained(model_name).to(device)
        self.processor = SiglipProcessor.from_pretrained(model_name)
        self.model.eval()
        self.device = device

    @staticmethod
    def _to_tensor(e):
        """Extract tensor from model output object if needed."""
        if isinstance(e, torch.Tensor):
            return e
        if hasattr(e, 'pooler_output') and e.pooler_output is not None:
            return e.pooler_output
        if hasattr(e, 'last_hidden_state'):
            return e.last_hidden_state[:, 0]
        raise ValueError(f"Cannot extract tensor from {type(e)}")

    @torch.no_grad()
    def encode_images(self, paths: List[Path], batch_size: int = 32) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(paths), batch_size), desc="  img", leave=False):
            imgs   = [Image.open(p).convert("RGB") for p in paths[i:i + batch_size]]
            inputs = self.processor(images=imgs, return_tensors="pt", padding=True)
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            e = self._to_tensor(self.model.get_image_features(**inputs))
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def encode_texts(self, texts: List[str], batch_size: int = 256) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(texts), batch_size), desc="  txt", leave=False):
            inputs = self.processor(
                text=texts[i:i + batch_size],
                return_tensors="pt", padding="max_length", truncation=True,
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            e = self._to_tensor(self.model.get_text_features(**inputs))
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)


class BLIPWrapper:
    """BLIP — uses BlipForImageTextRetrieval for proper dual-encoder retrieval.

    Must use Salesforce/blip-itm-large-coco (retrieval checkpoint).
    Encodes image via vision_model + vision_proj,
    text via text_encoder + text_proj, both L2-normalised.
    """

    def __init__(self, model_name: str, device: torch.device):
        from transformers import BlipForImageTextRetrieval, BlipProcessor
        self.model     = BlipForImageTextRetrieval.from_pretrained(model_name).to(device)
        self.processor = BlipProcessor.from_pretrained(model_name)
        self.model.eval()
        self.device = device

    @torch.no_grad()
    def encode_images(self, paths: List[Path], batch_size: int = 32) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(paths), batch_size), desc="  img", leave=False):
            imgs   = [Image.open(p).convert("RGB") for p in paths[i:i + batch_size]]
            inputs = self.processor(images=imgs, return_tensors="pt", padding=True)
            pixel_values = inputs["pixel_values"].to(self.device)
            vision_out   = self.model.vision_model(pixel_values=pixel_values)
            # CLS token → projection → normalise
            cls = vision_out.last_hidden_state[:, 0, :]
            e   = self.model.vision_proj(cls)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def encode_texts(self, texts: List[str], batch_size: int = 256) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(texts), batch_size), desc="  txt", leave=False):
            inputs = self.processor(
                text=texts[i:i + batch_size],
                return_tensors="pt", padding=True, truncation=True,
            )
            input_ids      = inputs["input_ids"].to(self.device)
            attention_mask = inputs["attention_mask"].to(self.device)
            text_out = self.model.text_encoder(
                input_ids=input_ids,
                attention_mask=attention_mask,
            )
            cls = text_out.last_hidden_state[:, 0, :]
            e   = self.model.text_proj(cls)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)


class Blip2Wrapper:
    """BLIP-2 (Salesforce/blip2-opt-2.7b) — Q-Former dual-encoder for retrieval.

    Image features: vision_model → Q-Former cross-attention → mean-pool 32 queries → 768-dim
    Text  features: BERT tokenizer → Q-Former self-attention → CLS token → 768-dim

    Both live in the Q-Former's 768-dim ITC-trained space (no language_projection applied).
    """

    def __init__(self, model_name: str, device: torch.device):
        from transformers import Blip2Model, Blip2Processor, BertTokenizer
        self.model          = Blip2Model.from_pretrained(model_name, torch_dtype=torch.float32).to(device)
        self.image_processor = Blip2Processor.from_pretrained(model_name)
        # Q-Former text encoder expects BERT-style tokens
        self.text_tokenizer  = BertTokenizer.from_pretrained("bert-base-uncased")
        self.model.eval()
        self.device = device

    @torch.no_grad()
    def encode_images(self, paths: List[Path], batch_size: int = 16) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(paths), batch_size), desc="  img", leave=False):
            imgs         = [Image.open(p).convert("RGB") for p in paths[i:i + batch_size]]
            pixel_values = self.image_processor(images=imgs, return_tensors="pt")["pixel_values"].to(self.device)

            vision_out   = self.model.vision_model(pixel_values=pixel_values)
            image_embeds = vision_out.last_hidden_state                          # (B, N, 1408)
            image_mask   = torch.ones(image_embeds.size()[:-1], dtype=torch.long, device=self.device)

            query_tokens = self.model.query_tokens.expand(image_embeds.shape[0], -1, -1)
            query_out    = self.model.qformer(
                query_embeds=query_tokens,
                encoder_hidden_states=image_embeds,
                encoder_attention_mask=image_mask,
                return_dict=True,
            )
            e = query_out.last_hidden_state.mean(dim=1)   # mean-pool 32 queries → (B, 768)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)

    @torch.no_grad()
    def encode_texts(self, texts: List[str], batch_size: int = 256) -> np.ndarray:
        out = []
        for i in tqdm(range(0, len(texts), batch_size), desc="  txt", leave=False):
            tok = self.text_tokenizer(
                texts[i:i + batch_size],
                return_tensors="pt", padding=True, truncation=True, max_length=77,
            )
            input_ids      = tok["input_ids"].to(self.device)
            attention_mask = tok["attention_mask"].to(self.device)
            text_out = self.model.qformer(
                input_ids=input_ids,
                attention_mask=attention_mask,
                return_dict=True,
            )
            e = text_out.last_hidden_state[:, 0, :]   # CLS → (B, 768)
            out.append((e / e.norm(dim=-1, keepdim=True)).cpu().float().numpy())
        return np.concatenate(out)


def load_model(model_key: str, device: torch.device):
    cfg = MODEL_REGISTRY[model_key]
    family = cfg["family"]
    if family == "clip":
        return CLIPWrapper(cfg["name"], device)
    elif family == "openclip":
        return OpenCLIPWrapper(cfg["name"], cfg["pretrained"], device)
    elif family == "siglip":
        return SigLIPWrapper(cfg["name"], device)
    elif family == "blip":
        return BLIPWrapper(cfg["name"], device)
    elif family == "blip2":
        return Blip2Wrapper(cfg["name"], device)
    else:
        raise ValueError(f"Unknown family: {family}")


# ─── Data loading ─────────────────────────────────────────────────────────────

def load_coco(cfg: dict) -> Tuple[List[Path], List[str], Dict, List[int]]:
    """
    Returns:
        image_paths : list of 5000 Path objects (val2017 clean images)
        captions    : list of all captions (25014)
        img2txt     : {image_index → [caption_indices]}
        txt2img     : [image_index for each caption]
    """
    with open(cfg["annotations"]) as f:
        raw = json.load(f)  # list of {image_id, caption}

    # Build ordered unique image list (preserve order from annotations)
    seen, image_ids = set(), []
    for item in raw:
        if item["image_id"] not in seen:
            seen.add(item["image_id"])
            image_ids.append(item["image_id"])

    img_id_to_idx = {img_id: i for i, img_id in enumerate(image_ids)}
    image_paths   = [cfg["clean_images"] / f"{img_id:012d}.jpg" for img_id in image_ids]

    captions, txt2img, img2txt = [], [], {i: [] for i in range(len(image_ids))}
    for item in raw:
        cap_idx = len(captions)
        img_idx = img_id_to_idx[item["image_id"]]
        captions.append(item["caption"])
        txt2img.append(img_idx)
        img2txt[img_idx].append(cap_idx)

    # Sanity check
    missing = [p for p in image_paths if not p.exists()]
    if missing:
        print(f"  WARNING: {len(missing)} COCO images not found on disk")

    return image_paths, captions, img2txt, txt2img


def load_flickr30k(cfg: dict) -> Tuple[List[Path], List[str], Dict, List[int]]:
    """Same structure as load_coco but for Flickr30k test split."""
    with open(cfg["annotations"]) as f:
        data = json.load(f)

    test_images = [img for img in data["images"] if img["split"] == "test"]

    image_paths, captions, txt2img = [], [], []
    img2txt = {}

    for img_idx, img in enumerate(test_images):
        image_paths.append(cfg["clean_images"] / img["filename"])
        img2txt[img_idx] = []
        for sent in img["sentences"]:
            cap_idx = len(captions)
            captions.append(sent["raw"])
            txt2img.append(img_idx)
            img2txt[img_idx].append(cap_idx)

    missing = [p for p in image_paths if not p.exists()]
    if missing:
        print(f"  WARNING: {len(missing)} Flickr30k images not found on disk")

    return image_paths, captions, img2txt, txt2img


def get_corrupted_paths(
    clean_paths: List[Path],
    corrupted_root: Path,
    corruption: str,
    severity: int,
) -> List[Path]:
    """Swap clean image dir for corrupted dir, keeping filenames."""
    sev_dir = corrupted_root / corruption / f"severity_{severity}"
    return [sev_dir / p.name for p in clean_paths]


# ─── Retrieval metrics ────────────────────────────────────────────────────────

def recall_at_k(
    img_embs: np.ndarray,         # [N, D]
    txt_embs: np.ndarray,         # [M, D]
    img2txt:  Dict[int, List[int]],
    txt2img:  List[int],
    chunk:    int = 256,
) -> Dict[str, Dict[str, float]]:
    """
    Computes R@1, R@5, R@10 for both I→T and T→I directions.
    Uses chunked matrix multiply to stay memory-safe on MacBook.
    """
    N, M = len(img_embs), len(txt_embs)

    # ── I→T ──────────────────────────────────────────────────────────────────
    i2t = {1: 0, 5: 0, 10: 0}
    for start in range(0, N, chunk):
        sims = img_embs[start:start + chunk] @ txt_embs.T  # [chunk, M]
        for j, row in enumerate(sims):
            gt = set(img2txt[start + j])
            ranked = np.argsort(-row)
            for rank, idx in enumerate(ranked):
                if idx in gt:
                    if rank < 1:  i2t[1]  += 1
                    if rank < 5:  i2t[5]  += 1
                    if rank < 10: i2t[10] += 1
                    break  # only the first GT hit counts per image

    # ── T→I ──────────────────────────────────────────────────────────────────
    t2i = {1: 0, 5: 0, 10: 0}
    for start in range(0, M, chunk):
        sims = txt_embs[start:start + chunk] @ img_embs.T  # [chunk, N]
        for j, row in enumerate(sims):
            gt_img = txt2img[start + j]
            rank   = int(np.where(np.argsort(-row) == gt_img)[0][0])
            if rank < 1:  t2i[1]  += 1
            if rank < 5:  t2i[5]  += 1
            if rank < 10: t2i[10] += 1

    return {
        "I2T": {f"R@{k}": round(v / N * 100, 4) for k, v in i2t.items()},
        "T2I": {f"R@{k}": round(v / M * 100, 4) for k, v in t2i.items()},
    }


# ─── Results management ───────────────────────────────────────────────────────

def load_done_set() -> set:
    """
    Loads existing results.csv and returns a set of completed
    (model, dataset, path, corruption_type, severity, direction, TTA_method, seed) tuples.
    """
    if not RESULTS_CSV.exists():
        return set()
    done = set()
    with open(RESULTS_CSV, newline="") as f:
        for row in csv.DictReader(f):
            done.add((
                row["model"], row["dataset"], row["path"],
                row["corruption_type"], row["severity"],
                row["direction"], row["TTA_method"], row["seed"],
            ))
    return done


def append_result(row: dict) -> None:
    """Appends a single result row to results.csv, creating the file if needed."""
    write_header = not RESULTS_CSV.exists()
    with open(RESULTS_CSV, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def is_done(done: set, model: str, dataset: str, corruption: str, severity: int,
            direction: str, seed: int) -> bool:
    return (model, dataset, "1", corruption, str(severity), direction, "none", str(seed)) in done


# ─── Core evaluation ─────────────────────────────────────────────────────────

def evaluate_model(
    model_key:    str,
    datasets:     List[str],
    corruptions:  List[str],
    seed:         int,
    device:       torch.device,
    done:         set,
    batch_size:   int,
) -> None:
    # ── Check if everything for this model is already done ──────────────────
    all_combos = [
        (ds, c, s, d)
        for ds in datasets
        for c  in (["clean"] + corruptions)
        for s  in ([0] if c == "clean" else SEVERITIES)
        for d  in ["I2T", "T2I"]
    ]
    remaining = [
        (ds, c, s, d) for ds, c, s, d in all_combos
        if not is_done(done, model_key, ds, c, s, d, seed)
    ]
    if not remaining:
        print(f"  [SKIP] {model_key} — all results already in CSV")
        return

    print(f"\n{'─'*64}")
    print(f"  Model : {model_key}")
    print(f"  Device: {device}")
    print(f"  Remaining combos: {len(remaining)}")
    print(f"{'─'*64}")

    # ── Load model once ──────────────────────────────────────────────────────
    print("  Loading model...")
    wrapper = load_model(model_key, device)

    for dataset in datasets:
        cfg = DATASET_CONFIG[dataset]

        print(f"\n  Dataset: {dataset.upper()}")
        if dataset == "coco":
            image_paths, captions, img2txt, txt2img = load_coco(cfg)
        else:
            image_paths, captions, img2txt, txt2img = load_flickr30k(cfg)

        # ── Encode clean texts once (shared across all corruptions) ─────────
        print("  Encoding clean captions...")
        txt_embs = wrapper.encode_texts(captions, batch_size=batch_size * 4)

        # ── Evaluate clean ──────────────────────────────────────────────────
        i2t_done = is_done(done, model_key, dataset, "clean", 0, "I2T", seed)
        t2i_done = is_done(done, model_key, dataset, "clean", 0, "T2I", seed)
        if not (i2t_done and t2i_done):
            print("  Encoding clean images...")
            img_embs = wrapper.encode_images(image_paths, batch_size=batch_size)
            print("  Computing clean metrics...")
            metrics  = recall_at_k(img_embs, txt_embs, img2txt, txt2img)
            for direction, m in metrics.items():
                if not is_done(done, model_key, dataset, "clean", 0, direction, seed):
                    row = {
                        "model": model_key, "dataset": dataset, "path": "1",
                        "corruption_type": "clean", "severity": 0,
                        "direction": direction,
                        "R@1": m["R@1"], "R@5": m["R@5"], "R@10": m["R@10"],
                        "TTA_method": "none", "seed": seed,
                    }
                    append_result(row)
                    done.add((model_key, dataset, "1", "clean", "0", direction, "none", str(seed)))
                    print(f"    clean | {direction} | R@1={m['R@1']:.2f}  R@5={m['R@5']:.2f}  R@10={m['R@10']:.2f}")

        # ── Evaluate corruptions ─────────────────────────────────────────────
        for corruption in tqdm(corruptions, desc=f"  Corruptions ({dataset})", leave=False):
            for severity in SEVERITIES:
                i2t_done = is_done(done, model_key, dataset, corruption, severity, "I2T", seed)
                t2i_done = is_done(done, model_key, dataset, corruption, severity, "T2I", seed)
                if i2t_done and t2i_done:
                    continue

                corr_paths = get_corrupted_paths(
                    image_paths, cfg["corrupted"], corruption, severity
                )
                img_embs = wrapper.encode_images(corr_paths, batch_size=batch_size)
                metrics  = recall_at_k(img_embs, txt_embs, img2txt, txt2img)

                for direction, m in metrics.items():
                    if not is_done(done, model_key, dataset, corruption, severity, direction, seed):
                        row = {
                            "model": model_key, "dataset": dataset, "path": "1",
                            "corruption_type": corruption, "severity": severity,
                            "direction": direction,
                            "R@1": m["R@1"], "R@5": m["R@5"], "R@10": m["R@10"],
                            "TTA_method": "none", "seed": seed,
                        }
                        append_result(row)
                        done.add((model_key, dataset, "1", corruption, str(severity),
                                  direction, "none", str(seed)))

    # ── Unload model to free memory ──────────────────────────────────────────
    del wrapper
    gc.collect()
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()
    elif torch.cuda.is_available():
        torch.cuda.empty_cache()


# ─── CLI ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="VLM retrieval robustness benchmark — Path 1 (image corruptions)"
    )
    parser.add_argument(
        "--model", nargs="+", default=["all"],
        help="Model key(s) to evaluate, or 'all'. See --list-models.",
    )
    parser.add_argument(
        "--dataset", choices=["coco", "flickr30k", "both"], default="both",
    )
    parser.add_argument(
        "--corruption", nargs="+", default=["all"],
        help="Specific corruption(s) to run, or 'all'.",
    )
    parser.add_argument("--seed",       type=int, default=42)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--device",     type=str, default=None,
                        help="Force device: 'cpu', 'mps', or 'cuda'. Default: auto-detect.")
    parser.add_argument("--list-models", action="store_true",
                        help="Print all available model keys and exit.")
    args = parser.parse_args()

    if args.list_models:
        print("\nAvailable models:")
        for key, cfg in MODEL_REGISTRY.items():
            print(f"  {key:<28} [{cfg['family']}]  {cfg['name']}")
        sys.exit(0)

    # Resolve models
    if args.model == ["all"]:
        models = ALL_MODELS
    else:
        invalid = [m for m in args.model if m not in MODEL_REGISTRY]
        if invalid:
            print(f"ERROR: Unknown model(s): {invalid}")
            print("Run with --list-models to see valid options.")
            sys.exit(1)
        models = args.model

    # Resolve datasets
    datasets = ["coco", "flickr30k"] if args.dataset == "both" else [args.dataset]

    # Resolve corruptions
    if args.corruption == ["all"]:
        corruptions = CORRUPTION_TYPES
    else:
        invalid = [c for c in args.corruption if c not in CORRUPTION_TYPES]
        if invalid:
            print(f"ERROR: Unknown corruption(s): {invalid}")
            sys.exit(1)
        corruptions = args.corruption

    device = torch.device(args.device) if args.device else get_device()
    done   = load_done_set()

    print(f"\n{'='*64}")
    print(f"  VLM Retrieval Robustness Benchmark — Path 1")
    print(f"  Device     : {device}")
    print(f"  Models     : {len(models)}")
    print(f"  Datasets   : {datasets}")
    print(f"  Corruptions: {len(corruptions)} types × {len(SEVERITIES)} severities")
    print(f"  Seed       : {args.seed}")
    print(f"  Results CSV: {RESULTS_CSV}")
    print(f"  Done so far: {len(done)} rows already in CSV")
    print(f"{'='*64}")

    for model_key in models:
        evaluate_model(
            model_key   = model_key,
            datasets    = datasets,
            corruptions = corruptions,
            seed        = args.seed,
            device      = device,
            done        = done,
            batch_size  = args.batch_size,
        )

    print(f"\n✓ Done. Results saved to {RESULTS_CSV}")


if __name__ == "__main__":
    main()
